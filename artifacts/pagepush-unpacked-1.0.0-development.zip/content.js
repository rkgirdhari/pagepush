"use strict";
(() => {
  // src/sha256.ts
  var K = new Uint32Array([
    1116352408,
    1899447441,
    3049323471,
    3921009573,
    961987163,
    1508970993,
    2453635748,
    2870763221,
    3624381080,
    310598401,
    607225278,
    1426881987,
    1925078388,
    2162078206,
    2614888103,
    3248222580,
    3835390401,
    4022224774,
    264347078,
    604807628,
    770255983,
    1249150122,
    1555081692,
    1996064986,
    2554220882,
    2821834349,
    2952996808,
    3210313671,
    3336571891,
    3584528711,
    113926993,
    338241895,
    666307205,
    773529912,
    1294757372,
    1396182291,
    1695183700,
    1986661051,
    2177026350,
    2456956037,
    2730485921,
    2820302411,
    3259730800,
    3345764771,
    3516065817,
    3600352804,
    4094571909,
    275423344,
    430227734,
    506948616,
    659060556,
    883997877,
    958139571,
    1322822218,
    1537002063,
    1747873779,
    1955562222,
    2024104815,
    2227730452,
    2361852424,
    2428436474,
    2756734187,
    3204031479,
    3329325298
  ]);
  var INITIAL = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225];
  var encoder = new TextEncoder();
  function sha256Hex(input) {
    const bytes = typeof input === "string" ? encoder.encode(input) : input;
    const bitLength = bytes.length * 8;
    const padded = new Uint8Array(Math.ceil((bytes.length + 9) / 64) * 64);
    padded.set(bytes);
    padded[bytes.length] = 128;
    const view = new DataView(padded.buffer);
    view.setUint32(padded.length - 8, Math.floor(bitLength / 4294967296), false);
    view.setUint32(padded.length - 4, bitLength >>> 0, false);
    const h = Uint32Array.from(INITIAL);
    const w = new Uint32Array(64);
    for (let offset = 0; offset < padded.length; offset += 64) {
      for (let i = 0; i < 16; i += 1) w[i] = view.getUint32(offset + i * 4, false);
      for (let i = 16; i < 64; i += 1) {
        const a2 = w[i - 15];
        const b2 = w[i - 2];
        const s0 = rotr(a2, 7) ^ rotr(a2, 18) ^ a2 >>> 3;
        const s1 = rotr(b2, 17) ^ rotr(b2, 19) ^ b2 >>> 10;
        w[i] = w[i - 16] + s0 + w[i - 7] + s1 >>> 0;
      }
      let a = h[0], b = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], k = h[7];
      for (let i = 0; i < 64; i += 1) {
        const t1 = k + (rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)) + (e & f ^ ~e & g) + K[i] + w[i] >>> 0;
        const t2 = (rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)) + (a & b ^ a & c ^ b & c) >>> 0;
        k = g;
        g = f;
        f = e;
        e = d + t1 >>> 0;
        d = c;
        c = b;
        b = a;
        a = t1 + t2 >>> 0;
      }
      h[0] = h[0] + a >>> 0;
      h[1] = h[1] + b >>> 0;
      h[2] = h[2] + c >>> 0;
      h[3] = h[3] + d >>> 0;
      h[4] = h[4] + e >>> 0;
      h[5] = h[5] + f >>> 0;
      h[6] = h[6] + g >>> 0;
      h[7] = h[7] + k >>> 0;
    }
    let hex = "";
    for (const word of h) hex += word.toString(16).padStart(8, "0");
    return hex;
  }
  function rotr(value, bits) {
    return value >>> bits | value << 32 - bits;
  }

  // src/util.ts
  function issue(level, fieldId, code, message) {
    return { level, fieldId, code, message };
  }
  function normalize(value) {
    return value.replace(/\s+/g, " ").trim().toLowerCase();
  }
  function labelKey(value) {
    return normalize(value).replace(/[*]\s*$/, "").replace(/\s*\(required\)$/, "").trim();
  }
  function wordsOf(value) {
    return labelKey(value).split(/[^a-z0-9+]+/).filter(Boolean);
  }
  function charLength(value) {
    return Array.from(value).length;
  }
  function wordCount(value) {
    return value.trim().split(/\s+/).filter(Boolean).length;
  }
  function clip(value, max = 80) {
    const flat = value.replace(/\s+/g, " ").trim();
    if (Array.from(flat).length <= max) return flat;
    return `${Array.from(flat).slice(0, max - 1).join("")}…`;
  }
  function getPath(root, path) {
    let current = root;
    for (const key of path.split(".")) {
      if (current == null || typeof current !== "object") return void 0;
      current = current[key];
    }
    return current;
  }
  function isHttpUrl(value) {
    try {
      const url = new URL(value);
      return url.protocol === "https:" || url.protocol === "http:";
    } catch {
      return false;
    }
  }
  function isEmail(value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  }
  function isFullDay(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const [year, month, day] = value.split("-").map(Number);
    if (year == null || month == null || day == null) return false;
    const date = new Date(Date.UTC(year, month - 1, day));
    return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
  }
  var VIDEO_HOSTS = ["youtube.com", "youtu.be", "vimeo.com", "youku.com"];
  function isDevpostVideo(value) {
    if (!isHttpUrl(value)) return false;
    const url = new URL(value);
    if (url.protocol !== "https:") return false;
    const host = url.hostname.toLowerCase().replace(/^www\./, "").replace(/^m\./, "");
    return VIDEO_HOSTS.some((allowed) => host === allowed || host.endsWith(`.${allowed}`));
  }
  function stableStringify(value) {
    if (value === null || typeof value !== "object") return JSON.stringify(value);
    if (Array.isArray(value)) return `[${value.map((item) => stableStringify(item)).join(",")}]`;
    const record = value;
    return `{${Object.keys(record).sort().map((key) => `${JSON.stringify(key)}:${stableStringify(record[key])}`).join(",")}}`;
  }
  function sha256(value) {
    return sha256Hex(stableStringify(value));
  }
  function dedupe(values) {
    const seen = /* @__PURE__ */ new Set();
    const result = [];
    for (const value of values) {
      const key = value.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      result.push(value);
    }
    return result;
  }

  // src/settle.ts
  var DEFAULT_SETTLE_MS = 2500;
  var POLL_MS = 40;
  async function settle(doc, check, options = {}) {
    if ((options.timeoutMs ?? DEFAULT_SETTLE_MS) > 0) await nextTask();
    return await settleFind(doc, () => safe(check) ? true : void 0, options) === true;
  }
  function nextTask() {
    return new Promise((resolve) => setTimeout(resolve, 0));
  }
  function settleFind(doc, find, options = {}) {
    const first = safeFind(find);
    const timeoutMs = Math.max(0, options.timeoutMs ?? DEFAULT_SETTLE_MS);
    if (first !== void 0 || timeoutMs === 0) return Promise.resolve(first);
    return new Promise((resolve) => {
      let done = false;
      const view = doc.defaultView;
      const Observer = view?.MutationObserver ?? globalThis.MutationObserver;
      let observer = null;
      const finish2 = (value) => {
        if (done) return;
        done = true;
        observer?.disconnect();
        clearInterval(poll);
        clearTimeout(limit);
        resolve(value);
      };
      const attempt = () => {
        const found = safeFind(find);
        if (found !== void 0) finish2(found);
      };
      if (typeof Observer === "function") {
        observer = new Observer(attempt);
        observer.observe(doc.documentElement, { childList: true, subtree: true, attributes: true, characterData: true });
      }
      const poll = setInterval(attempt, POLL_MS);
      const limit = setTimeout(() => finish2(safeFind(find)), timeoutMs);
    });
  }
  function safe(check) {
    try {
      return check();
    } catch {
      return false;
    }
  }
  function safeFind(find) {
    try {
      return find();
    } catch {
      return void 0;
    }
  }

  // src/bind.ts
  var CONTROL_SELECTOR = "input, textarea, select, button, [role='button'], [contenteditable='true'], [role='combobox']";
  var CAPTCHA_RESPONSES = ["g-recaptcha-response", "h-captcha-response", "cf-turnstile-response"];
  function bindPage(doc) {
    const controls = [];
    let generated = 0;
    doc.querySelectorAll(CONTROL_SELECTOR).forEach((node) => {
      const el = node;
      const type = (el.getAttribute("type") ?? "").toLowerCase();
      const name = el.getAttribute("name") ?? "";
      if (type === "hidden") return;
      if (CAPTCHA_RESPONSES.includes(name)) return;
      if (!el.id) ensureId(el, `pp-${++generated}`);
      const rawLabels = readRawLabels(doc, el);
      const labels = rawLabels.map((label) => labelKey(label));
      controls.push({
        id: el.id,
        element: el,
        labels,
        rawLabels,
        required: isRequired(el, rawLabels),
        maxLength: readMaxLength(el),
        tag: el.tagName,
        type,
        role: el.getAttribute("role") ?? "",
        disabled: el.hasAttribute("disabled") || el.getAttribute("aria-disabled") === "true",
        editable: el.getAttribute("contenteditable") === "true"
      });
    });
    return {
      document: doc,
      controls,
      captcha: captchaPresent(doc),
      password: Boolean(doc.querySelector("input[type='password']"))
    };
  }
  function captchaPresent(doc) {
    return Boolean(
      doc.querySelector(
        [
          ".g-recaptcha",
          "iframe[src*='recaptcha']",
          "iframe[src*='hcaptcha']",
          ".h-captcha",
          ".cf-turnstile",
          "iframe[src*='challenges.cloudflare.com']",
          "[data-sitekey]",
          ...CAPTCHA_RESPONSES.map((name) => `[name='${name}']`)
        ].join(", ")
      )
    );
  }
  function captchaCleared(doc) {
    if (!captchaPresent(doc)) return true;
    const boxes = Array.from(doc.querySelectorAll(CAPTCHA_RESPONSES.map((name) => `[name='${name}']`).join(", ")));
    if (!boxes.length || boxes.some((box) => !("value" in box) || !String(box.value).trim())) return false;
    const markers = Array.from(doc.querySelectorAll(
      ".g-recaptcha, iframe[src*='recaptcha'], iframe[src*='hcaptcha'], .h-captcha, .cf-turnstile, iframe[src*='challenges.cloudflare.com'], [data-sitekey]"
    ));
    const roots = markers.filter((marker) => !markers.some((other) => other !== marker && other.contains(marker)));
    if (boxes.length < roots.length) return false;
    const providers = [
      { selector: ".g-recaptcha, iframe[src*='recaptcha']", name: "g-recaptcha-response" },
      { selector: ".h-captcha, iframe[src*='hcaptcha']", name: "h-captcha-response" },
      { selector: ".cf-turnstile, iframe[src*='challenges.cloudflare.com']", name: "cf-turnstile-response" }
    ];
    return providers.every(({ selector, name }) => {
      const widgets = roots.filter((root) => root.matches(selector) || root.querySelector(selector));
      const responses = boxes.filter((box) => box.getAttribute("name") === name);
      if (responses.length < widgets.length) return false;
      if (widgets.length < 2) return true;
      const unmatched = widgets.filter((root) => !responses.some((box) => root.contains(box)));
      const external = responses.filter((box) => !widgets.some((root) => root.contains(box)));
      return unmatched.length === 0 || unmatched.length === 1 && external.length === 1;
    });
  }
  function locate(doc, id) {
    const first = doc.getElementById(id);
    if (!first) return null;
    const found = Array.from(doc.querySelectorAll("[id]")).filter((el) => el.id === id);
    return found.length === 1 && found[0] === first ? first : null;
  }
  function ensureId(el, fallback) {
    if (!el.id) {
      const doc = el.ownerDocument;
      let id = fallback;
      let suffix = 0;
      while (doc?.getElementById(id)) id = `${fallback}-${++suffix}`;
      el.id = id;
    }
    return el.id;
  }
  function visibleText(el) {
    const clone = el.cloneNode(true);
    clone.querySelectorAll("input, textarea, select, button").forEach((node) => node.remove());
    return (clone.textContent ?? "").replace(/\s+/g, " ").trim();
  }
  function isButtonControl(control) {
    return control.tag === "BUTTON" || control.role === "button";
  }
  function readRawLabels(doc, el) {
    if (el.tagName === "BUTTON") {
      const text = visibleText(el);
      return text ? [text] : [];
    }
    if (el.getAttribute("role") === "button") {
      const text = visibleText(el) || (el.getAttribute("aria-label") ?? "").trim();
      return text ? [text] : [];
    }
    const raw = [];
    if (el.id) {
      doc.querySelectorAll("label").forEach((label) => {
        if (label.getAttribute("for") === el.id) raw.push(visibleText(label));
      });
    }
    const wrapping = el.closest("label");
    if (wrapping) raw.push(visibleText(wrapping));
    const aria = el.getAttribute("aria-label");
    if (aria) raw.push(aria.trim());
    const labelledBy = el.getAttribute("aria-labelledby");
    if (labelledBy) {
      for (const ref of labelledBy.split(/\s+/)) {
        const node = doc.getElementById(ref);
        if (node) raw.push((node.textContent ?? "").replace(/\s+/g, " ").trim());
      }
    }
    const found = raw.filter(Boolean);
    if (!found.length) {
      const placeholder = (el.getAttribute("placeholder") ?? "").trim();
      if (placeholder) found.push(placeholder);
    }
    return found;
  }
  function isRequired(el, rawLabels) {
    if (el.hasAttribute("required") || el.getAttribute("aria-required") === "true") return true;
    return rawLabels.some((label) => /\*\s*$/.test(label));
  }
  function readMaxLength(el) {
    const attr = el.getAttribute("maxlength");
    if (!attr) return null;
    const parsed = Number(attr);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
  }
  function labelMatches(control, labels, match, words) {
    const wanted = labels.map((label) => labelKey(label));
    if (control.labels.some((label) => wanted.includes(label))) return true;
    if (match !== "all-words" || !words?.length) return false;
    return control.labels.some((label) => {
      const tokens = new Set(wordsOf(label));
      return words.every((word) => tokens.has(labelKey(word)));
    });
  }
  function ownerDocument(root) {
    if (root.nodeType === 9) return root;
    return root.ownerDocument;
  }
  function inputsByLabel(root, label) {
    return controlsByLabel(root, label, ["input", "textarea", "select"], (type) => {
      return type !== "hidden" && type !== "radio" && type !== "checkbox" && type !== "file";
    });
  }
  function checkboxesByLabel(root, label) {
    return controlsByLabel(root, label, ["input"], (type) => type === "checkbox");
  }
  function radiosIn(root) {
    const found = [];
    root.querySelectorAll("input[type='radio'], [role='radio']").forEach((node) => {
      if (node.parentElement?.closest("[role='radio']")) return;
      found.push(node);
    });
    return found;
  }
  function radioText(radio) {
    const wrapping = radio.closest("label");
    if (wrapping) return visibleText(wrapping);
    const own = ariaName(radio);
    if (own) return own;
    const inner = radio.querySelector("[role='radio']");
    const innerName = inner ? ariaName(inner) : "";
    if (innerName) return innerName;
    const doc = radio.ownerDocument;
    if (radio.id && doc) {
      for (const label of doc.querySelectorAll("label")) {
        if (label.getAttribute("for") === radio.id) return visibleText(label);
      }
    }
    return (radio.textContent ?? "").replace(/\s+/g, " ").trim();
  }
  function ariaName(el) {
    const aria = el.getAttribute("aria-label");
    if (aria?.trim()) return aria.trim();
    const doc = el.ownerDocument;
    const ids = (el.getAttribute("aria-labelledby") ?? "").split(/\s+/).filter(Boolean);
    if (!doc || !ids.length) return "";
    return ids.map((id) => (doc.getElementById(id)?.textContent ?? "").replace(/\s+/g, " ").trim()).filter(Boolean).join(" ");
  }
  function radioChecked(radio) {
    if (radio.getAttribute("role") === "radio") return radio.getAttribute("aria-checked") === "true";
    return radio.checked === true;
  }
  function controlsByLabel(root, label, selectors, acceptType) {
    const doc = ownerDocument(root);
    if (!doc) return [];
    const want = labelKey(label);
    const found = [];
    root.querySelectorAll(selectors.join(", ")).forEach((node) => {
      const el = node;
      const type = (el.getAttribute("type") ?? "").toLowerCase();
      if (!acceptType(type)) return;
      const labels = readRawLabels(doc, el).map((item) => labelKey(item));
      if (labels.includes(want)) found.push(el);
    });
    return found;
  }
  var SECTION_SELECTOR = "section, fieldset, [role='group'], [role='dialog'], [role='radiogroup'], [role='region'], [role='main'], [role='form']";
  var TITLED_BY_FIRST_TEXT = /* @__PURE__ */ new Set(["main", "dialog"]);
  function findSection(doc, names, within) {
    const wanted = names.map((name) => labelKey(name));
    const inside = (el) => !within || within !== el && within.contains(el);
    for (const el of doc.querySelectorAll(SECTION_SELECTOR)) {
      if (!inside(el)) continue;
      const texts = sectionTexts(doc, el);
      if (texts.some((text) => wanted.includes(labelKey(text)))) return el;
    }
    for (const heading of doc.querySelectorAll("h1, h2, h3, legend")) {
      if (!wanted.includes(labelKey(heading.textContent ?? ""))) continue;
      const section = heading.closest(SECTION_SELECTOR) ?? heading.parentElement;
      if (section && (inside(section) || section === within)) return section;
    }
    return null;
  }
  function sectionTexts(doc, el) {
    const texts = [];
    const aria = el.getAttribute("aria-label");
    if (aria) texts.push(aria);
    const labelledBy = el.getAttribute("aria-labelledby");
    if (labelledBy) {
      for (const ref of labelledBy.split(/\s+/)) {
        const node = doc.getElementById(ref);
        if (node) texts.push(node.textContent ?? "");
      }
    }
    const heading = Array.from(el.children).find((child) => /^(H1|H2|H3|LEGEND)$/.test(child.tagName));
    if (heading) texts.push(heading.textContent ?? "");
    if (!texts.length && TITLED_BY_FIRST_TEXT.has(el.getAttribute("role") ?? "")) {
      const first = firstText(el);
      if (first) texts.push(first);
    }
    return texts;
  }
  function firstText(el) {
    const doc = el.ownerDocument;
    if (!doc) return "";
    const walker = doc.createTreeWalker(
      el,
      4
      /* NodeFilter.SHOW_TEXT */
    );
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      const parent = node.parentElement;
      if (parent?.closest("input, textarea, select, [contenteditable='true'], [role='button']")) continue;
      const text = (node.textContent ?? "").replace(/\s+/g, " ").trim();
      if (text) return text;
    }
    return "";
  }
  function rowOf(input) {
    return input.closest("[data-feature], [data-tier], [data-story], [data-faq], tr, fieldset, li") ?? input.parentElement ?? input;
  }
  function widgetOf(input) {
    return input.closest("[data-widget], fieldset, section") ?? input.parentElement ?? input;
  }
  function clickElement(el) {
    const view = el.ownerDocument?.defaultView;
    if (view && typeof view.MouseEvent === "function") {
      el.dispatchEvent(new view.MouseEvent("click", { bubbles: true, cancelable: true }));
      return;
    }
    el.dispatchEvent(new Event("click", { bubbles: true, cancelable: true }));
  }
  function clickAdd(root, addLabel, guard) {
    const want = labelKey(addLabel);
    for (const button of root.querySelectorAll("button")) {
      if (labelKey(button.textContent ?? "") === want) {
        guard?.(button);
        clickElement(button);
        return true;
      }
    }
    return false;
  }
  async function ensureCount(root, label, count, addLabel, settleMs = DEFAULT_SETTLE_MS, guard) {
    let inputs = inputsByLabel(root, label);
    let attempts = 0;
    const doc = root.ownerDocument;
    while (inputs.length < count && addLabel && doc && attempts < count + 1) {
      const before = inputs.length;
      if (!clickAdd(root, addLabel, guard)) break;
      const grew = await settle(doc, () => inputsByLabel(root, label).length > before, { timeoutMs: settleMs });
      inputs = inputsByLabel(root, label);
      if (!grew) break;
      attempts += 1;
    }
    return inputs;
  }
  function fileCount(el) {
    if (!el || !("files" in el)) return 0;
    const files = el.files;
    return files?.length ?? 0;
  }
  function tokenLanded(widget, token, option) {
    const want = labelKey(token);
    const label = labelKey(option?.textContent ?? "");
    for (const chip of widget.querySelectorAll("[data-tag], [role='option'][aria-selected='true']")) {
      const tag = labelKey(chip.getAttribute("data-tag") ?? chip.getAttribute("data-slug") ?? chip.getAttribute("value") ?? "");
      const text = labelKey(chip.textContent ?? "");
      if (tag === want || text === want || label && text === label) return true;
    }
    const names = new Set([want, label].filter(Boolean));
    for (const remove of widget.querySelectorAll("[role='button'][aria-label]")) {
      const aria = labelKey(remove.getAttribute("aria-label") ?? "");
      if (aria.startsWith("remove ") && names.has(aria.slice("remove ".length))) return true;
    }
    for (const list of widget.querySelectorAll("[role='list'][aria-label]")) {
      if (labelKey(list.getAttribute("aria-label") ?? "") !== "selected values") continue;
      for (const item of list.children) {
        if (names.has(labelKey(visibleText(item)))) return true;
      }
    }
    return false;
  }

  // src/apply.ts
  async function writeAction(doc, action2, settleMs = DEFAULT_SETTLE_MS, guard = () => {
  }) {
    const ctx = { doc, settleMs, guard };
    guard();
    switch (action2.kind) {
      case "text":
      case "textarea":
      case "url":
      case "email":
      case "date":
        return writeText(ctx, action2);
      case "tags":
        return writeTags(ctx, action2);
      case "tokens":
        return writeTokens(ctx, action2);
      case "lines":
        return writeLines(ctx, action2);
      case "select":
        return writeSelect(ctx, action2);
      case "checkbox":
        return writeCheck(ctx, action2);
      case "button":
        return writeButton(ctx, action2);
      case "choice":
        return writeChoice(ctx, action2);
      case "invites":
        return writeInvites(ctx, action2);
      case "pricing":
        return writePricing(ctx, action2);
      case "features":
        return writeFeatures(ctx, action2);
      case "faq":
        return writeFaq(ctx, action2);
      default:
        return false;
    }
  }
  function until(ctx, check) {
    return settle(ctx.doc, check, { timeoutMs: ctx.settleMs });
  }
  function matchesAction(doc, action2) {
    switch (action2.kind) {
      case "text":
      case "textarea":
      case "url":
      case "email":
      case "date":
        return readText(doc, action2) === action2.value;
      case "tags":
        return landedAll(widgetOf(locate(doc, action2.controlId) ?? doc.documentElement), stringList(action2.value));
      case "tokens":
        return tokensMatch(doc, action2);
      case "lines":
        return linesMatch(doc, action2);
      case "select":
        return selectMatches(doc, action2);
      case "choice":
        return choiceMatches(doc, action2);
      case "pricing":
        return pricingMatches(doc, action2);
      case "features":
        return featuresMatch(doc, action2);
      case "faq":
        return faqMatches(doc, action2);
      default:
        return false;
    }
  }
  async function writeText(ctx, action2) {
    const el = locate(ctx.doc, action2.controlId);
    if (!el || typeof action2.value !== "string") return false;
    setValue(ctx, el, action2.value);
    return until(ctx, () => readText(ctx.doc, action2) === action2.value);
  }
  function readText(doc, action2) {
    const el = locate(doc, action2.controlId);
    return el ? readValue(el) : "";
  }
  async function writeTags(ctx, action2) {
    const el = locate(ctx.doc, action2.controlId);
    const tags = stringList(action2.value);
    if (!el) return false;
    const widget = widgetOf(el);
    for (const tag of tags) {
      if (chipLanded(widget, tag)) continue;
      setValue(ctx, el, tag);
      dispatchKey(ctx, el, "keydown", "Enter");
      if (!await until(ctx, () => chipLanded(widget, tag))) {
        setValue(ctx, el, "");
        return false;
      }
    }
    return landedAll(widget, tags);
  }
  async function writeTokens(ctx, action2) {
    const el = locate(ctx.doc, action2.controlId);
    const tokens = stringList(action2.value);
    if (!el) return false;
    const widget = widgetOf(el);
    for (const token of tokens) {
      if (tokenLanded(widget, token)) continue;
      setValue(ctx, el, token);
      const option = await settleFind(ctx.doc, () => optionsOf(el).find((candidate) => optionMatches(candidate, token)), { timeoutMs: ctx.settleMs });
      if (!option) {
        setValue(ctx, el, "");
        return false;
      }
      ctx.guard(option);
      clickElement(option);
      if (!await until(ctx, () => tokenLanded(widget, token, option))) return false;
    }
    return tokens.every((token) => tokenLanded(widget, token));
  }
  function tokensMatch(doc, action2) {
    const el = locate(doc, action2.controlId);
    if (!el) return false;
    const widget = widgetOf(el);
    return stringList(action2.value).every((token) => tokenLanded(widget, token));
  }
  async function writeLines(ctx, action2) {
    const payload = linePayload(action2.value);
    if (!payload) return false;
    const root = scope(ctx.doc, action2);
    const inputs = await ensureCount(root, payload.label, payload.lines.length, payload.addLabel, ctx.settleMs, ctx.guard);
    if (inputs.length === 1 && payload.lines.length > 1 && inputs[0].tagName === "TEXTAREA") {
      setValue(ctx, inputs[0], payload.lines.join("\n"));
      return until(ctx, () => linesMatch(ctx.doc, action2));
    }
    if (inputs.length < payload.lines.length) return false;
    payload.lines.forEach((line, index) => setValue(ctx, inputs[index], line));
    return until(ctx, () => linesMatch(ctx.doc, action2));
  }
  function linesMatch(doc, action2) {
    const payload = linePayload(action2.value);
    if (!payload) return false;
    const inputs = inputsByLabel(scope(doc, action2), payload.label);
    if (inputs.length === 1 && payload.lines.length > 1 && inputs[0].tagName === "TEXTAREA") {
      return readValue(inputs[0]) === payload.lines.join("\n");
    }
    return payload.lines.every((line, index) => inputs[index] != null && readValue(inputs[index]) === line);
  }
  async function writeSelect(ctx, action2) {
    const el = locate(ctx.doc, action2.controlId);
    if (!el || typeof action2.value !== "string") return false;
    const option = optionElements(el).find((candidate) => optionMatches(candidate, action2.value));
    if (!option) return false;
    const optionValue = option.getAttribute("value") ?? (option.textContent ?? "").trim();
    setValue(ctx, el, optionValue);
    return until(ctx, () => selectMatches(ctx.doc, action2));
  }
  function selectMatches(doc, action2) {
    const el = locate(doc, action2.controlId);
    if (!el || typeof action2.value !== "string") return false;
    const expected = labelKey(action2.value);
    if (labelKey(readValue(el)) === expected) return true;
    const option = optionElements(el)[el.selectedIndex];
    if (!option) return false;
    const text = (option.textContent ?? "").trim();
    return labelKey(text) === expected || labelKey(option.getAttribute("value") ?? "") === expected;
  }
  async function writeCheck(ctx, action2) {
    const el = locate(ctx.doc, action2.controlId);
    if (!el) return false;
    return setChecked(ctx, el, true);
  }
  async function writeChoice(ctx, action2) {
    const group = locate(ctx.doc, action2.controlId);
    if (!group || typeof action2.value !== "string") return false;
    const radio = radiosIn(group).find((candidate) => radioIs(candidate, action2.value));
    if (!radio) return false;
    if (!radioChecked(radio)) activate(ctx, radio);
    return until(ctx, () => choiceMatches(ctx.doc, action2));
  }
  function choiceMatches(doc, action2) {
    const group = locate(doc, action2.controlId);
    if (!group || typeof action2.value !== "string") return false;
    const selected = radiosIn(group).filter((radio) => radioChecked(radio));
    return selected.length === 1 && radioIs(selected[0], action2.value);
  }
  function radioIs(radio, value) {
    const want = labelKey(value);
    return labelKey(radioText(radio)) === want || labelKey(radio.getAttribute("value") ?? "") === want;
  }
  function activate(ctx, el) {
    ctx.guard(el);
    const clickable = el;
    if (typeof clickable.click === "function") clickable.click();
    else clickElement(el);
  }
  async function writeButton(ctx, action2) {
    if (!locate(ctx.doc, action2.controlId)) return false;
    const enabled = () => {
      const el = locate(ctx.doc, action2.controlId);
      return el != null && el.getAttribute("aria-disabled") !== "true" && !el.hasAttribute("disabled");
    };
    if (!enabled() && !await until(ctx, enabled)) return false;
    const button = locate(ctx.doc, action2.controlId);
    if (!button) return false;
    ctx.guard(button);
    clickElement(button);
    return true;
  }
  async function writeInvites(ctx, action2) {
    const payload = invitePayload(action2.value);
    const el = locate(ctx.doc, action2.controlId);
    if (!payload || !el) return false;
    const root = widgetOf(el);
    for (const email of payload.emails) {
      if (chipLanded(root, email)) continue;
      setValue(ctx, el, email);
      if (!clickAdd(root, payload.addLabel, ctx.guard)) return false;
      if (!await until(ctx, () => chipLanded(root, email))) return false;
    }
    return payload.emails.every((email) => chipLanded(root, email));
  }
  async function writePricing(ctx, action2) {
    const payload = action2.value;
    const root = scope(ctx.doc, action2);
    if (!await selectModel(ctx, root, payload)) return false;
    const nameInputs = await ensureCount(root, payload.labels.tierName, payload.tiers.length, payload.labels.addTier, ctx.settleMs, ctx.guard);
    if (nameInputs.length < payload.tiers.length) return false;
    for (let index = 0; index < payload.tiers.length; index += 1) {
      const tier = payload.tiers[index];
      const row = rowOf(nameInputs[index]);
      setValue(ctx, nameInputs[index], tier.name);
      const price = inputsByLabel(row, payload.labels.price)[0];
      if (!price) return false;
      setValue(ctx, price, String(tier.price));
      const original = inputsByLabel(row, payload.labels.originalPrice)[0];
      if (original) setValue(ctx, original, tier.originalPrice == null ? "" : String(tier.originalPrice));
      const recommended = checkboxesByLabel(row, payload.labels.recommended)[0];
      if (recommended) await setChecked(ctx, recommended, Boolean(tier.recommended));
    }
    const featureInputs = await ensureCount(root, payload.labels.feature, payload.features.length, payload.labels.addFeature, ctx.settleMs, ctx.guard);
    if (featureInputs.length < payload.features.length) return false;
    for (let index = 0; index < payload.features.length; index += 1) {
      const feature = payload.features[index];
      const row = rowOf(featureInputs[index]);
      setValue(ctx, featureInputs[index], feature.label);
      const tooltip = inputsByLabel(row, payload.labels.tooltip)[0];
      if (tooltip) setValue(ctx, tooltip, feature.tooltip ?? "");
      const cells = inputsByLabel(row, payload.labels.value);
      if (cells.length < feature.values.length) return false;
      feature.values.forEach((value, cell) => setValue(ctx, cells[cell], value));
    }
    return until(ctx, () => pricingMatches(ctx.doc, action2));
  }
  function pricingMatches(doc, action2) {
    const payload = action2.value;
    const root = scope(doc, action2);
    const selected = radiosIn(root).find((radio) => radio.checked);
    if (!selected || !radioMatches(selected, payload.model, payload.labels)) return false;
    const names = inputsByLabel(root, payload.labels.tierName);
    if (names.length < payload.tiers.length) return false;
    for (let index = 0; index < payload.tiers.length; index += 1) {
      const tier = payload.tiers[index];
      const row = rowOf(names[index]);
      if (readValue(names[index]) !== tier.name) return false;
      const price = inputsByLabel(row, payload.labels.price)[0];
      if (!price || readValue(price) !== String(tier.price)) return false;
      const original = inputsByLabel(row, payload.labels.originalPrice)[0];
      if (original && readValue(original) !== (tier.originalPrice == null ? "" : String(tier.originalPrice))) return false;
      const recommended = checkboxesByLabel(row, payload.labels.recommended)[0];
      if (recommended && recommended.checked !== Boolean(tier.recommended)) return false;
    }
    const features = inputsByLabel(root, payload.labels.feature);
    if (features.length < payload.features.length) return false;
    for (let index = 0; index < payload.features.length; index += 1) {
      const feature = payload.features[index];
      const row = rowOf(features[index]);
      if (readValue(features[index]) !== feature.label) return false;
      const cells = inputsByLabel(row, payload.labels.value);
      if (feature.values.some((value, cell) => cells[cell] == null || readValue(cells[cell]) !== value)) return false;
    }
    return true;
  }
  async function selectModel(ctx, root, payload) {
    const match = radiosIn(root).find((radio) => radioMatches(radio, payload.model, payload.labels));
    if (!match) return false;
    return setChecked(ctx, match, true);
  }
  function radioMatches(radio, model, labels) {
    const text = radio.closest("label") ? visibleText(radio.closest("label")) : radio.getAttribute("aria-label") ?? "";
    const wanted = model === "codes" ? labels.codes : labels.licensing;
    return labelKey(radio.getAttribute("value") ?? "") === labelKey(model) || labelKey(text) === labelKey(wanted);
  }
  async function writeFeatures(ctx, action2) {
    const payload = action2.value;
    const root = scope(ctx.doc, action2);
    const header = inputsByLabel(root, payload.labels.header)[0];
    if (!header) return false;
    setValue(ctx, header, payload.sectionHeader);
    const titles = await ensureCount(root, payload.labels.title, payload.stories.length, payload.labels.add, ctx.settleMs, ctx.guard);
    if (titles.length < payload.stories.length) return false;
    for (let index = 0; index < payload.stories.length; index += 1) {
      const story = payload.stories[index];
      setValue(ctx, titles[index], story.title);
      const bullets = inputsByLabel(rowOf(titles[index]), payload.labels.bullets)[0];
      if (!bullets) return false;
      setValue(ctx, bullets, story.bullets.join("\n"));
    }
    return until(ctx, () => featuresMatch(ctx.doc, action2));
  }
  function featuresMatch(doc, action2) {
    const payload = action2.value;
    const root = scope(doc, action2);
    const header = inputsByLabel(root, payload.labels.header)[0];
    if (!header || readValue(header) !== payload.sectionHeader) return false;
    const titles = inputsByLabel(root, payload.labels.title);
    return payload.stories.every((story, index) => {
      const title = titles[index];
      if (!title || readValue(title) !== story.title) return false;
      const bullets = inputsByLabel(rowOf(title), payload.labels.bullets)[0];
      return bullets != null && readValue(bullets) === story.bullets.join("\n");
    });
  }
  async function writeFaq(ctx, action2) {
    const payload = action2.value;
    const root = scope(ctx.doc, action2);
    const questions = await ensureCount(root, payload.labels.question, payload.items.length, payload.labels.add, ctx.settleMs, ctx.guard);
    if (questions.length < payload.items.length) return false;
    for (let index = 0; index < payload.items.length; index += 1) {
      const item = payload.items[index];
      setValue(ctx, questions[index], item.question);
      const answer = inputsByLabel(rowOf(questions[index]), payload.labels.answer)[0];
      if (!answer) return false;
      setValue(ctx, answer, item.answer);
    }
    return until(ctx, () => faqMatches(ctx.doc, action2));
  }
  function faqMatches(doc, action2) {
    const payload = action2.value;
    const root = scope(doc, action2);
    const questions = inputsByLabel(root, payload.labels.question);
    return payload.items.every((item, index) => {
      const question = questions[index];
      if (!question || readValue(question) !== item.question) return false;
      const answer = inputsByLabel(rowOf(question), payload.labels.answer)[0];
      return answer != null && readValue(answer) === item.answer;
    });
  }
  function scope(doc, action2) {
    if (action2.sectionId) return locate(doc, action2.sectionId) ?? doc.documentElement;
    return doc.documentElement;
  }
  function setValue(ctx, el, value) {
    ctx.guard(el);
    if (el.getAttribute("contenteditable") === "true") {
      setRichText(ctx, el, value);
      return;
    }
    const descriptor = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), "value");
    if (descriptor?.set) descriptor.set.call(el, value);
    else el.value = value;
    dispatch(ctx, el, "input");
    dispatch(ctx, el, "change");
  }
  function setChecked(ctx, el, checked) {
    if (isChecked(el) !== checked) activate(ctx, el);
    return until(ctx, () => isChecked(el) === checked);
  }
  function isChecked(el) {
    const role = el.getAttribute("role");
    if (role === "checkbox" || role === "switch" || role === "radio" || role === "menuitemcheckbox") {
      return el.getAttribute("aria-checked") === "true";
    }
    return el.checked === true;
  }
  function readValue(el) {
    if (el.getAttribute("contenteditable") === "true") return readRichText(el);
    return String(el.value ?? "");
  }
  function setRichText(ctx, el, value) {
    const doc = el.ownerDocument;
    if (!doc) return;
    focusAndSelectAll(ctx, el);
    if (deliverByExecCommand(ctx, doc, el, value)) return;
    if (!dispatchInputEvent(ctx, el, "beforeinput", value)) {
      dispatchInputEvent(ctx, el, "input", value);
      return;
    }
    if (dispatchPaste(ctx, el, value)) return;
    if (isLexical(el)) return;
    ctx.guard(el);
    el.textContent = value;
    dispatchInputEvent(ctx, el, "input", value);
  }
  function isLexical(el) {
    return el.closest("[data-lexical-editor='true']") != null;
  }
  function focusAndSelectAll(ctx, el) {
    ctx.guard(el);
    el.focus?.();
    ctx.guard(el);
    const view = el.ownerDocument?.defaultView;
    const selection = view?.getSelection?.();
    const doc = el.ownerDocument;
    if (!selection || !doc?.createRange) return;
    const range = doc.createRange();
    range.selectNodeContents(el);
    ctx.guard(el);
    selection.removeAllRanges();
    ctx.guard(el);
    selection.addRange(range);
  }
  function deliverByExecCommand(ctx, doc, el, value) {
    const exec = doc.execCommand;
    if (typeof exec !== "function") return false;
    let reached = false;
    const seen = () => {
      reached = true;
    };
    el.addEventListener("beforeinput", seen);
    el.addEventListener("input", seen);
    let ok = false;
    ctx.guard(el);
    try {
      ok = exec.call(doc, "insertText", false, value) === true;
    } catch {
      ok = false;
    } finally {
      el.removeEventListener("beforeinput", seen);
      el.removeEventListener("input", seen);
    }
    return ok && reached;
  }
  function dispatchInputEvent(ctx, el, type, data) {
    ctx.guard(el);
    const view = el.ownerDocument?.defaultView;
    const InputCtor = view?.InputEvent;
    const init = { bubbles: true, cancelable: type === "beforeinput", inputType: "insertText", data };
    let event;
    if (typeof InputCtor === "function") {
      event = new InputCtor(type, init);
    } else {
      const EventCtor = view?.Event ?? Event;
      event = new EventCtor(type, init);
      Object.defineProperty(event, "inputType", { value: init.inputType });
      Object.defineProperty(event, "data", { value: data });
    }
    return el.dispatchEvent(event);
  }
  function dispatchPaste(ctx, el, text) {
    const view = el.ownerDocument?.defaultView;
    if (!view || typeof view.DataTransfer !== "function" || typeof view.ClipboardEvent !== "function") return false;
    ctx.guard(el);
    try {
      const data = new view.DataTransfer();
      data.setData("text/plain", text);
      const event = new view.ClipboardEvent("paste", { clipboardData: data, bubbles: true, cancelable: true });
      return !el.dispatchEvent(event);
    } catch {
      return false;
    }
  }
  var BLOCK = /^(P|DIV|H[1-6]|LI|BLOCKQUOTE|PRE)$/;
  function readRichText(el) {
    let out = "";
    const walk = (node) => {
      for (const child of Array.from(node.childNodes)) {
        if (child.nodeType === 3) {
          out += child.nodeValue ?? "";
          continue;
        }
        if (child.nodeType !== 1) continue;
        const tag = child.tagName;
        if (tag === "BR") {
          out += "\n";
          continue;
        }
        const block = BLOCK.test(tag);
        if (block && out && !out.endsWith("\n")) out += "\n";
        walk(child);
      }
    };
    walk(el);
    return out.replace(/\n+$/, "");
  }
  function dispatch(ctx, el, type) {
    ctx.guard(el);
    const view = el.ownerDocument?.defaultView;
    const EventCtor = view?.Event ?? Event;
    el.dispatchEvent(new EventCtor(type, { bubbles: true }));
  }
  function dispatchKey(ctx, el, type, key) {
    ctx.guard(el);
    const view = el.ownerDocument?.defaultView;
    if (view && typeof view.KeyboardEvent === "function") {
      el.dispatchEvent(new view.KeyboardEvent(type, { key, bubbles: true, cancelable: true }));
      return;
    }
    const event = new Event(type, { bubbles: true, cancelable: true });
    Object.defineProperty(event, "key", { value: key });
    el.dispatchEvent(event);
  }
  function optionsOf(input) {
    const listId = input.getAttribute("aria-controls");
    const doc = input.ownerDocument;
    const list = listId && doc ? doc.getElementById(listId) : widgetOf(input).querySelector("[role='listbox']");
    if (!list) return [];
    return Array.from(list.querySelectorAll("[role='option']"));
  }
  function optionElements(el) {
    return Array.from(el.querySelectorAll("option"));
  }
  function optionMatches(option, token) {
    const want = labelKey(token);
    const ids = [option.getAttribute("data-slug"), option.getAttribute("value")];
    const text = (option.textContent ?? "").trim();
    return ids.some((id) => id != null && id !== "" && labelKey(id) === want) || labelKey(text) === want;
  }
  function chipLanded(widget, value) {
    const want = labelKey(value);
    for (const chip of widget.querySelectorAll("[data-tag]")) {
      const tag = labelKey(chip.getAttribute("data-tag") ?? "");
      const text = labelKey(chip.textContent ?? "");
      if (tag === want || text === want) return true;
    }
    return false;
  }
  function landedAll(widget, values) {
    return values.every((value) => chipLanded(widget, value));
  }
  function stringList(value) {
    return Array.isArray(value) ? value.filter((item) => typeof item === "string") : [];
  }
  function linePayload(value) {
    if (!value || typeof value !== "object") return null;
    const record = value;
    if (!Array.isArray(record.lines) || typeof record.label !== "string") return null;
    return {
      lines: record.lines.filter((item) => typeof item === "string"),
      label: record.label,
      addLabel: typeof record.addLabel === "string" ? record.addLabel : void 0
    };
  }
  function invitePayload(value) {
    if (!value || typeof value !== "object") return null;
    const record = value;
    if (!Array.isArray(record.emails) || typeof record.addLabel !== "string") return null;
    return {
      emails: record.emails.filter((item) => typeof item === "string"),
      addLabel: record.addLabel
    };
  }

  // src/validate.ts
  function validateField(field, value, maxLength = field.maxLength) {
    const issues = [];
    if (typeof value === "string") {
      checkString(field, value, maxLength, issues);
      return issues;
    }
    if (typeof value === "number") {
      if (field.minimum != null && value < field.minimum) {
        issues.push(issue("error", field.id, "min", `${field.labels[0]} must be at least ${field.minimum}.`));
      }
      if (field.maximum != null && value > field.maximum) {
        issues.push(issue("error", field.id, "max", `${field.labels[0]} must be at most ${field.maximum}.`));
      }
      return issues;
    }
    if (Array.isArray(value)) {
      const items = value.filter((item) => typeof item === "string");
      if (items.length !== value.length) {
        issues.push(issue("error", field.id, "type", `${field.labels[0]} must be a list of text.`));
        return issues;
      }
      if (field.minItems != null && items.length < field.minItems) {
        issues.push(issue("error", field.id, "min-items", `${field.labels[0]} needs at least ${field.minItems}.`));
      }
      if (field.maxItems != null && items.length > field.maxItems) {
        issues.push(issue("error", field.id, "max-items", `${field.labels[0]} allows at most ${field.maxItems}.`));
      }
      items.forEach((item, index) => {
        if (field.itemMaxLength != null && charLength(item) > field.itemMaxLength) {
          issues.push(issue("error", field.id, "item-length", `${field.labels[0]} item ${index + 1} is over ${field.itemMaxLength} characters.`));
        }
        if (field.itemMinWords != null && wordCount(item) < field.itemMinWords) {
          issues.push(issue("error", field.id, "item-words", `${field.labels[0]} item ${index + 1} needs at least ${field.itemMinWords} words.`));
        }
        if (field.format === "url" && !isHttpUrl(item)) {
          issues.push(issue("error", field.id, "url", `${field.labels[0]} item ${index + 1} must be an http(s) URL.`));
        }
        if (field.format === "email" && !isEmail(item)) {
          issues.push(issue("error", field.id, "email", `${field.labels[0]} item ${index + 1} must be an email address.`));
        }
      });
    }
    return issues;
  }
  function checkString(field, value, maxLength, issues) {
    const length = charLength(value);
    if (field.minLength != null && length < field.minLength) {
      issues.push(issue("error", field.id, "min-length", `${field.labels[0]} must be at least ${field.minLength} characters.`));
    }
    if (maxLength != null && length > maxLength) {
      issues.push(issue("error", field.id, "max-length", `${field.labels[0]} must be at most ${maxLength} characters.`));
    }
    if (field.enum && !field.enum.includes(value)) {
      issues.push(issue("error", field.id, "enum", `${field.labels[0]} must be one of: ${field.enum.join(", ")}.`));
    }
    if (field.pattern && !new RegExp(field.pattern).test(value)) {
      issues.push(issue("error", field.id, "pattern", `${field.labels[0]} does not match the expected format.`));
    }
    if ((field.format === "url" || field.control === "url") && !isHttpUrl(value)) {
      issues.push(issue("error", field.id, "url", `${field.labels[0]} must be an http(s) URL.`));
    }
    if (field.format === "email" && !isEmail(value)) {
      issues.push(issue("error", field.id, "email", `${field.labels[0]} must be an email address.`));
    }
    if (field.format === "date" && !isFullDay(value)) {
      issues.push(issue("error", field.id, "date", `${field.labels[0]} must be a full day, YYYY-MM-DD.`));
    }
    if (field.format === "video" && !isDevpostVideo(value)) {
      issues.push(issue("error", field.id, "video", `${field.labels[0]} must be a public https YouTube, Vimeo, or Youku URL.`));
    }
  }
  function effectiveMax(field, domMax) {
    if (field.maxLength != null && domMax != null) return Math.min(field.maxLength, domMax);
    return field.maxLength ?? domMax ?? void 0;
  }
  function asStringList(value) {
    if (typeof value === "string") return value.trim() ? [value.trim()] : [];
    if (Array.isArray(value) && value.every((item) => typeof item === "string")) {
      return value.map((item) => item.trim()).filter(Boolean);
    }
    return null;
  }
  function isBlank(value) {
    if (value == null) return true;
    if (typeof value === "string") return value.trim().length === 0;
    if (Array.isArray(value)) return value.length === 0;
    return false;
  }

  // src/plan.ts
  function buildPlan(input) {
    const draft = {
      schema: input.schema,
      page: bindPage(input.document),
      pack: input.pack,
      actions: [],
      errors: [],
      warnings: [],
      gates: [],
      deferred: [],
      notes: [],
      matched: /* @__PURE__ */ new Set(),
      scopes: /* @__PURE__ */ new Map(),
      fences: []
    };
    for (const item of input.extraIssues ?? []) {
      if (item.level === "error") draft.errors.push(item);
      else draft.warnings.push(item);
    }
    if (draft.page.password) {
      draft.errors.push(issue("error", "page", "sign-in", "Sign in yourself, then run the shim on the open submission form."));
      return finish(input, draft);
    }
    const refusals = (input.guard?.(draft.page) ?? []).filter((item) => item.level === "error");
    if (refusals.length) {
      draft.errors.push(...refusals);
      return finish(input, draft);
    }
    if (draft.page.captcha) {
      draft.gates.push({
        code: "captcha",
        message: "Solve the captcha on the page. The shim leaves it for you."
      });
    }
    resolveScopes(draft);
    for (const field of input.schema.fields) planField(draft, field);
    for (const control of draft.page.controls) {
      if (draft.matched.has(control.id)) continue;
      if (isButtonControl(control) || control.type === "hidden") continue;
      if (control.type === "radio" && !control.required) continue;
      input.onUnmapped?.(control, draft);
    }
    input.after?.(draft);
    return finish(input, draft);
  }
  function planField(draft, field) {
    if (field.control === "pricing" || field.control === "features" || field.control === "faq") {
      planSection(draft, field);
      return;
    }
    if (field.control === "file") {
      planFile(draft, field);
      return;
    }
    if (field.control === "choice") {
      planChoice(draft, field);
      return;
    }
    const control = findControl(draft, field);
    if (!control) {
      draft.deferred.push(field.id);
      return;
    }
    draft.matched.add(control.id);
    const enablesAfterDraft = field.control === "button" && field.phase === "commit" && !control.element.hasAttribute("disabled");
    if (control.disabled && !enablesAfterDraft) {
      draft.warnings.push(issue("warning", field.id, "locked", `${field.labels[0]} is locked on this page and was left alone.`));
      return;
    }
    if (field.control === "checkbox" || field.control === "button") {
      planCommitControl(draft, field, control);
      return;
    }
    if (field.control === "invites") {
      planInvites(draft, field, control);
      return;
    }
    const value = getPath(draft.pack, field.path);
    if (isBlank(value)) {
      if (field.required) draft.errors.push(issue("error", field.id, "required", `${field.labels[0]} is required on this page.`));
      return;
    }
    const prepared = prepareValue(field, value);
    const problems = validateField(field, prepared, effectiveMax(field, control.maxLength));
    problems.forEach((problem) => (problem.level === "error" ? draft.errors : draft.warnings).push(problem));
    if (problems.some((problem) => problem.level === "error")) return;
    if (field.control === "tokens" && field.taxonomy) {
      const missing = missingTokens(control, asStringList(prepared) ?? []);
      if (missing.length) {
        draft.errors.push(issue("error", field.id, "taxonomy-miss", `${field.labels[0]} has no option for ${missing.join(", ")}.`));
        return;
      }
    }
    if (field.control === "select" && typeof prepared === "string" && !selectHas(control, prepared)) {
      draft.errors.push(issue("error", field.id, "option-miss", `${field.labels[0]} has no option for ${prepared}.`));
      return;
    }
    if (blocked(draft, field.id)) return;
    const kind = field.control;
    if (kind === "lines") {
      const lines = asStringList(prepared) ?? [];
      draft.actions.push(action({
        id: field.id,
        phase: "draft",
        kind,
        label: field.labels[0] ?? field.id,
        controlId: control.id,
        value: { lines, label: matchedLabel(control, field), addLabel: field.addLabel }
      }));
      return;
    }
    draft.actions.push(action({
      id: field.id,
      phase: field.phase === "commit" ? "commit" : "draft",
      kind,
      label: matchedLabel(control, field),
      controlId: control.id,
      value: prepared
    }));
  }
  function planCommitControl(draft, field, control) {
    const value = getPath(draft.pack, field.path);
    if (value === true && !blocked(draft, field.id)) {
      draft.actions.push(action({
        id: field.id,
        phase: "commit",
        kind: field.control,
        label: matchedLabel(control, field),
        controlId: control.id,
        value: true
      }));
      return;
    }
    if (field.required) {
      draft.errors.push(issue("error", field.id, "required", `${field.labels[0]} is required before submit.`));
    }
  }
  function planInvites(draft, field, control) {
    const emails = asStringList(getPath(draft.pack, field.path)) ?? [];
    if (!emails.length) return;
    const problems = validateField(field, emails);
    problems.forEach((problem) => (problem.level === "error" ? draft.errors : draft.warnings).push(problem));
    if (problems.some((problem) => problem.level === "error") || blocked(draft, field.id)) return;
    draft.actions.push(action({
      id: field.id,
      phase: "commit",
      kind: "invites",
      label: field.labels[0] ?? "Teammates",
      controlId: control.id,
      value: { emails, addLabel: field.addLabel ?? "Invite" }
    }));
  }
  function planChoice(draft, field) {
    const scope2 = scopeOf(draft, field);
    if (scope2 === null) {
      draft.deferred.push(field.id);
      return;
    }
    const group = findSection(draft.page.document, field.labels, scope2);
    const radios = group ? radiosIn(group) : [];
    if (!group || !radios.length) {
      draft.deferred.push(field.id);
      return;
    }
    const groupId = ensureId(group, `pp-${field.id}`);
    claim(draft, group);
    const value = getPath(draft.pack, field.path);
    if (isBlank(value)) {
      if (field.required) draft.errors.push(issue("error", field.id, "required", `${field.labels[0]} is required on this page.`));
      return;
    }
    if (typeof value !== "string") {
      draft.errors.push(issue("error", field.id, "type", `${field.labels[0]} must be one option, as text.`));
      return;
    }
    const wanted = value.trim();
    const problems = validateField(field, wanted);
    problems.forEach((problem) => (problem.level === "error" ? draft.errors : draft.warnings).push(problem));
    if (problems.some((problem) => problem.level === "error")) return;
    const offered = radios.some(
      (radio) => labelKey(radioText(radio)) === labelKey(wanted) || labelKey(radio.getAttribute("value") ?? "") === labelKey(wanted)
    );
    if (!offered) {
      draft.errors.push(issue("error", field.id, "option-miss", `${field.labels[0]} has no option for ${wanted}.`));
      return;
    }
    if (blocked(draft, field.id)) return;
    draft.actions.push(action({
      id: field.id,
      phase: field.phase === "commit" ? "commit" : "draft",
      kind: "choice",
      label: field.labels[0] ?? field.id,
      controlId: groupId,
      sectionId: groupId,
      value: wanted
    }));
  }
  function planFile(draft, field) {
    const control = findControl(draft, field);
    if (!control) {
      draft.deferred.push(field.id);
      return;
    }
    draft.matched.add(control.id);
    if (field.required) {
      draft.gates.push({
        code: "file",
        fieldId: field.id,
        controlId: control.id,
        message: `Attach ${field.labels[0]} before submit.`
      });
    } else {
      draft.notes.push(`${field.labels[0]}: attach the file yourself`);
    }
  }
  function planSection(draft, field) {
    const section = findSection(draft.page.document, field.labels);
    if (!section) {
      draft.deferred.push(field.id);
      return;
    }
    const sectionId = ensureId(section, `pp-${field.id}`);
    claim(draft, section);
    if (blocked(draft, field.id)) return;
    const value = getPath(draft.pack, field.path);
    if (value == null) {
      if (field.required) draft.errors.push(issue("error", field.id, "required", `${field.labels[0]} is required on this page.`));
      return;
    }
    if (field.control === "pricing") {
      const payload2 = pricingPayload(draft.schema, value);
      if (!payload2) {
        draft.errors.push(issue("error", field.id, "shape", "Pricing needs a model, tiers, and feature rows."));
        return;
      }
      draft.actions.push(action({
        id: field.id,
        phase: "draft",
        kind: "pricing",
        label: field.labels[0] ?? "Pricing",
        controlId: sectionId,
        sectionId,
        value: payload2
      }));
      return;
    }
    if (field.control === "features") {
      const payload2 = featurePayload(draft.schema, value);
      if (!payload2) {
        draft.errors.push(issue("error", field.id, "shape", "Highlighted features need a header and stories."));
        return;
      }
      draft.actions.push(action({
        id: field.id,
        phase: "draft",
        kind: "features",
        label: field.labels[0] ?? "Highlighted features",
        controlId: sectionId,
        sectionId,
        value: payload2
      }));
      return;
    }
    const payload = faqPayload(draft.schema, value);
    if (!payload) {
      draft.errors.push(issue("error", field.id, "shape", "FAQ needs question and answer pairs."));
      return;
    }
    draft.actions.push(action({
      id: field.id,
      phase: "draft",
      kind: "faq",
      label: field.labels[0] ?? "FAQ",
      controlId: sectionId,
      sectionId,
      value: payload
    }));
  }
  var planSequence = 0;
  function finish(input, draft) {
    if (planSequence >= Number.MAX_SAFE_INTEGER) throw new Error("Plan instance limit reached; reload the extension.");
    const sequence = ++planSequence;
    const marker = "data-pagepush-plan-sequence";
    const previous = Number(input.document.documentElement.getAttribute(marker) ?? "0");
    if (!Number.isSafeInteger(previous) || previous < 0 || previous >= Number.MAX_SAFE_INTEGER) throw new Error("Invalid plan sequence; reload the page.");
    const documentSequence = previous + 1;
    input.document.documentElement.setAttribute(marker, String(documentSequence));
    const instance = `${input.document.defaultView?.performance.timeOrigin ?? 0}:${documentSequence}:${sequence}`;
    const preview = [...draft.actions.map((item) => item.preview), ...draft.notes];
    const planHash = sha256({
      ...input.offer ? { offer: input.offer } : {},
      platform: input.schema.id,
      pageUrl: input.pageUrl,
      notes: draft.notes,
      actions: draft.actions.map((item) => ({
        id: item.id,
        phase: item.phase,
        kind: item.kind,
        label: item.label,
        value: item.value,
        preview: item.preview
      }))
    });
    const plan = {
      platform: input.schema.id,
      offer: input.offer ?? input.schema.offer,
      pageUrl: input.pageUrl,
      actions: draft.actions,
      deferred: draft.deferred,
      errors: draft.errors,
      warnings: draft.warnings,
      gates: draft.gates,
      preview,
      planHash
    };
    bindPlanIdentity(plan, input.document, instance);
    return plan;
  }
  var identities = /* @__PURE__ */ new WeakMap();
  function bindPlanIdentity(plan, doc, instance) {
    const targets = /* @__PURE__ */ new Map();
    for (const action2 of plan.actions) {
      const element = locate(doc, action2.controlId);
      let scope2 = element;
      if (element && ["tokens", "tags", "invites"].includes(action2.kind)) scope2 = widgetOf(element);
      if (action2.kind === "lines") scope2 = doc.documentElement;
      const labels = /* @__PURE__ */ new Map();
      const payload = action2.value && typeof action2.value === "object" ? action2.value : {};
      const labelValues = action2.kind === "lines" ? [payload.label] : ["pricing", "features", "faq"].includes(action2.kind) && payload.labels && typeof payload.labels === "object" ? Object.values(payload.labels) : [];
      if (scope2) for (const label of labelValues) {
        if (typeof label === "string") labels.set(label, inputsByLabel(scope2, label));
      }
      const radios = ["choice", "pricing"].includes(action2.kind) && element ? radiosIn(element) : [];
      const buttons = scope2 ? Array.from(scope2.querySelectorAll("button")) : [];
      const listId = element?.getAttribute("aria-controls");
      const list = listId ? doc.getElementById(listId) : scope2?.querySelector("[role='listbox']");
      const options = action2.kind === "tokens" && list ? Array.from(list.querySelectorAll("[role='option']")) : [];
      targets.set(action2, { element, scope: scope2, labels, radios, buttons, options });
    }
    const gates = /* @__PURE__ */ new Map();
    for (const gate of plan.gates) if (gate.controlId) gates.set(gate.controlId, locate(doc, gate.controlId));
    identities.set(plan, { instance, doc, documentUrl: doc.defaultView?.location.href, targets, gates });
  }
  function planInstanceId(plan) {
    return identities.get(plan)?.instance;
  }
  function planTargetValid(doc, plan, action2, target) {
    const identity = identities.get(plan);
    if (!identity || identity.doc !== doc || identity.documentUrl !== doc.defaultView?.location.href) return false;
    if (!action2) return true;
    const binding = identity.targets.get(action2);
    const original = binding?.element;
    if (!binding || !original || !original.isConnected || locate(doc, action2.controlId) !== original) return false;
    if (binding.scope && !binding.scope.isConnected) return false;
    for (const [label, originals] of binding.labels) {
      const current = inputsByLabel(binding.scope, label);
      if (originals.some((el, index) => current[index] !== el)) return false;
    }
    if (binding.radios.length) {
      const current = radiosIn(original);
      if (binding.radios.some((el, index) => current[index] !== el)) return false;
    }
    if (!target) return true;
    if (target.ownerDocument !== doc || !target.isConnected) return false;
    if (target === original) return true;
    if (target.tagName === "BUTTON") return binding.buttons.includes(target) && binding.scope?.contains(target) === true;
    if (action2.kind === "tokens" && target.getAttribute("role") === "option") {
      const listId = original.getAttribute("aria-controls");
      const list = listId ? doc.getElementById(listId) : binding.scope?.querySelector("[role='listbox']");
      if (!list?.contains(target)) return false;
      const keys = [target.getAttribute("data-slug"), target.getAttribute("value"), target.textContent].filter((value) => Boolean(value)).map(labelKey);
      const prior = binding.options.filter((option) => [option.getAttribute("data-slug"), option.getAttribute("value"), option.textContent].some((value) => value && keys.includes(labelKey(value))));
      return prior.length === 0 || prior.includes(target);
    }
    return binding.scope?.contains(target) === true;
  }
  function planGateValid(doc, plan, id) {
    const identity = identities.get(plan);
    const original = identity?.gates.get(id);
    return planTargetValid(doc, plan) && original != null && original.isConnected && locate(doc, id) === original;
  }
  function claim(draft, root) {
    for (const control of draft.page.controls) {
      if (root.contains(control.element)) draft.matched.add(control.id);
    }
  }
  function blocked(draft, fieldId) {
    return draft.errors.some((item) => item.fieldId === fieldId && item.level === "error");
  }
  function resolveScopes(draft) {
    for (const field of draft.schema.fields) {
      if (!field.within?.length) continue;
      const section = findSection(draft.page.document, field.within);
      draft.scopes.set(field.id, section);
      if (section && !draft.fences.includes(section)) draft.fences.push(section);
    }
  }
  function scopeOf(draft, field) {
    if (!field.within?.length) return void 0;
    return draft.scopes.get(field.id) ?? null;
  }
  function findControl(draft, field) {
    const scope2 = scopeOf(draft, field);
    if (scope2 === null) return void 0;
    const candidates = draft.page.controls.filter((control) => {
      if (!fits(control, field.control)) return false;
      if (scope2) return scope2.contains(control.element);
      return !draft.fences.some((fence) => fence.contains(control.element));
    });
    const exact = candidates.filter((control) => labelMatches(control, field.labels, "exact"));
    const pool = exact.length ? exact : candidates.filter((control) => labelMatches(control, field.labels, field.match ?? "exact", field.words));
    if (!pool.length) return void 0;
    return field.pick === "last" ? pool[pool.length - 1] : pool[0];
  }
  function fits(control, kind) {
    switch (kind) {
      case "checkbox":
        return control.type === "checkbox";
      case "file":
        return control.type === "file";
      case "button":
        return isButtonControl(control);
      case "select":
        return control.tag === "SELECT";
      case "textarea":
        return control.tag === "TEXTAREA" || control.editable;
      case "tags":
      case "tokens":
      case "lines":
      case "invites":
      case "text":
      case "url":
      case "email":
      case "date":
        return isTextual(control);
      default:
        return false;
    }
  }
  function isTextual(control) {
    if (control.editable || control.role === "combobox") return true;
    if (control.tag === "TEXTAREA") return true;
    if (control.tag !== "INPUT") return false;
    return !["checkbox", "radio", "file", "password", "hidden", "submit", "button"].includes(control.type);
  }
  function prepareValue(field, value) {
    if (field.control === "lines" || field.control === "tags" || field.control === "tokens" || field.control === "invites") {
      return asStringList(value) ?? value;
    }
    if (typeof value === "string") return value.trim();
    return value;
  }
  function matchedLabel(control, field) {
    const exact = control.rawLabels.find((raw) => field.labels.some((label) => labelKey(label) === labelKey(raw)));
    return exact ?? control.rawLabels[0] ?? field.labels[0] ?? field.id;
  }
  function missingTokens(control, tokens) {
    const options = listedOptions(control);
    if (!options.length) return [];
    const widget = widgetOf(control.element);
    return tokens.filter((token) => !tokenLanded(widget, token) && !options.some((option) => optionMatchesToken(option, token)));
  }
  function listedOptions(control) {
    const listId = control.element.getAttribute("aria-controls");
    const doc = control.element.ownerDocument;
    const list = listId && doc ? doc.getElementById(listId) : null;
    if (!list) return [];
    return Array.from(list.querySelectorAll("[role='option']"));
  }
  function optionMatchesToken(option, token) {
    const want = labelKey(token);
    const ids = [option.getAttribute("data-slug"), option.getAttribute("value")];
    const text = (option.textContent ?? "").trim();
    return ids.some((id) => id != null && id !== "" && labelKey(id) === want) || labelKey(text) === want;
  }
  function selectHas(control, value) {
    return Array.from(control.element.querySelectorAll("option")).some((option) => {
      const optionValue = option.getAttribute("value") ?? "";
      const text = (option.textContent ?? "").trim();
      return labelKey(optionValue) === labelKey(value) || labelKey(text) === labelKey(value);
    });
  }
  function action(partial) {
    return { ...partial, preview: previewLine(partial) };
  }
  function previewLine(partial) {
    if (partial.kind === "invites") {
      const emails = partial.value.emails ?? [];
      return `Confirm: invite ${emails.join(", ")}`;
    }
    if (partial.phase === "commit" && partial.kind === "checkbox") return `Confirm: check ${partial.label}`;
    if (partial.phase === "commit" && partial.kind === "button") return `Confirm: ${partial.label}`;
    if (partial.kind === "lines") {
      const lines = partial.value.lines ?? [];
      return `${partial.label}: ${clip(lines.join(" / "))}`;
    }
    if (partial.kind === "pricing") {
      const pricing = partial.value;
      const tiers = pricing.tiers?.map((tier) => `${tier.name} $${tier.price}`).join(", ") ?? "";
      return `${partial.label}: ${pricing.model ?? ""} ${tiers}`.trim();
    }
    if (partial.kind === "features") {
      const features = partial.value;
      return `${partial.label}: ${clip(features.sectionHeader ?? "")}`;
    }
    if (partial.kind === "faq") {
      const items = partial.value.items ?? [];
      return `${partial.label}: ${items.length} questions`;
    }
    if (Array.isArray(partial.value)) return `${partial.label}: ${clip(partial.value.join(", "))}`;
    if (typeof partial.value === "string") return `${partial.label}: ${clip(partial.value)}`;
    return partial.label;
  }
  function pricingPayload(schema, value) {
    const labels = objectRule(schema, "pricing");
    if (!labels || !value || typeof value !== "object") return null;
    const record = value;
    if (typeof record.model !== "string" || !Array.isArray(record.tiers) || !Array.isArray(record.features)) return null;
    return {
      model: record.model,
      tiers: record.tiers,
      features: record.features,
      labels: { ...labels, codes: "Codes", licensing: "Licensing" }
    };
  }
  function featurePayload(schema, value) {
    const labels = objectRule(schema, "features");
    if (!labels || !value || typeof value !== "object") return null;
    const record = value;
    if (typeof record.sectionHeader !== "string" || !Array.isArray(record.stories)) return null;
    return { sectionHeader: record.sectionHeader, stories: record.stories, labels };
  }
  function faqPayload(schema, value) {
    const labels = objectRule(schema, "faq");
    if (!labels || !Array.isArray(value)) return null;
    const items = value.filter((item) => item && typeof item === "object");
    if (items.length !== value.length) return null;
    return { items, labels };
  }
  function objectRule(schema, key) {
    const value = schema.rules?.[key];
    return value && typeof value === "object" ? value : null;
  }

  // src/execute.ts
  var CommitRefused = class extends Error {
    code;
    /** Commit actions that already wrote before this refusal. Invites in this list were sent. */
    applied;
    constructor(code, message, applied = []) {
      super(message);
      this.name = "CommitRefused";
      this.code = code;
      this.applied = applied;
    }
  };
  var UnsafeMutation = class extends Error {
  };
  function contextValid(doc, plan, options) {
    return planTargetValid(doc, plan) && (!options.currentUrl || options.currentUrl() === plan.pageUrl) && (!options.isCurrent || options.isCurrent());
  }
  function approve(plan, at = /* @__PURE__ */ new Date()) {
    return { planHash: plan.planHash, approvedAt: at.toISOString(), instanceId: planInstanceId(plan) };
  }
  async function executeDraft(doc, plan, options = {}) {
    const applied = [];
    const unconfirmed = [];
    const actions = plan.actions.filter((action2) => action2.phase === "draft");
    for (let index = 0; index < actions.length; index += 1) {
      const action2 = actions[index];
      const guard = (target) => {
        if (!contextValid(doc, plan, options) || !planTargetValid(doc, plan, action2, target)) throw new UnsafeMutation();
      };
      let wrote = false;
      try {
        wrote = await writeAction(doc, action2, options.settleMs, guard);
        guard();
      } catch (error) {
        if (error instanceof UnsafeMutation) {
          unconfirmed.push(...actions.slice(index).map((item) => item.id));
          options.trace?.({ phase: "draft", code: "stale", actionId: action2.id });
          break;
        }
        options.trace?.({ phase: "draft", code: "threw", actionId: action2.id });
      }
      if (wrote) {
        applied.push(action2.id);
        options.trace?.({ phase: "draft", code: "applied", actionId: action2.id });
      } else {
        unconfirmed.push(action2.id);
        options.trace?.({ phase: "draft", code: "unconfirmed", actionId: action2.id });
      }
    }
    return { applied, unconfirmed };
  }
  function checkDrift(doc, plan, ids) {
    const wanted = ids ? new Set(ids) : null;
    const drifted = [];
    for (const action2 of plan.actions) {
      if (action2.phase !== "draft" || wanted && !wanted.has(action2.id)) continue;
      let ok = false;
      try {
        ok = planTargetValid(doc, plan, action2) && matchesAction(doc, action2);
      } catch {
        ok = false;
      }
      if (!ok) drifted.push(action2.id);
    }
    return drifted;
  }
  async function executeCommit(doc, plan, token, options = {}) {
    const refuse = (code, message, applied2 = [], actionId) => {
      options.trace?.({ phase: "commit", code, actionId });
      throw new CommitRefused(code, message, applied2);
    };
    const instance = planInstanceId(plan);
    if (!token || instance == null || token.planHash !== plan.planHash || token.instanceId !== instance) {
      refuse("confirm", "Phone confirm does not match this plan.");
    }
    if (!contextValid(doc, plan, options)) refuse("stale", "The page changed since this plan. Plan this view again.");
    if (plan.errors.length) refuse("blocked", plan.errors.map((item) => item.message).join(" "));
    for (const action2 of plan.actions) {
      if (action2.phase !== "draft") continue;
      if (!planTargetValid(doc, plan, action2) || !matchesAction(doc, action2)) {
        refuse("stale", `${action2.label} no longer matches the confirmed plan.`, [], action2.id);
      }
    }
    if (!captchaCleared(doc)) {
      const gate = plan.gates.find((item) => item.code === "captcha");
      refuse("captcha", gate?.message ?? "Solve the captcha on the page yourself, then click Approve & Commit again.");
    }
    for (const gate of plan.gates) {
      if (gate.code !== "file") continue;
      const el = gate.controlId && planGateValid(doc, plan, gate.controlId) ? locate(doc, gate.controlId) : null;
      if (fileCount(el) < (gate.minFiles ?? 1)) refuse("file", gate.message, [], gate.fieldId);
    }
    const applied = [];
    for (const action2 of plan.actions) {
      if (action2.phase !== "commit") continue;
      const guard = (target) => {
        if (!contextValid(doc, plan, options) || !planTargetValid(doc, plan, action2, target) || !captchaCleared(doc)) throw new UnsafeMutation();
        for (const gate of plan.gates) {
          if (gate.code !== "file") continue;
          const el = gate.controlId && planGateValid(doc, plan, gate.controlId) ? locate(doc, gate.controlId) : null;
          if (fileCount(el) < (gate.minFiles ?? 1)) throw new UnsafeMutation();
        }
      };
      let wrote = false;
      try {
        wrote = await writeAction(doc, action2, options.settleMs, guard);
        guard();
      } catch {
        wrote = false;
      }
      if (!wrote) {
        const earlier = applied.length ? ` Already written: ${applied.join(", ")}.` : "";
        refuse("unconfirmed", `${action2.label} did not stick or the page changed; it may have already been activated. Plan again.${earlier}`, applied, action2.id);
      }
      applied.push(action2.id);
      options.trace?.({ phase: "commit", code: "applied", actionId: action2.id });
    }
  }

  // schemas/schema_facebook.json
  var schema_facebook_default = {
    id: "facebook",
    version: "2026-11-25",
    title: "Facebook Business Page setup",
    offer: {
      name: "Facebook Business Page Setup Sprint",
      priceUsd: 15,
      promise: "Your Business Page details, drafted into the Facebook setup and settings forms you already have open. You read the plan in the side panel and click Approve & Commit before anything is created, saved, or posted."
    },
    sources: [
      {
        title: "Facebook Help Center",
        url: "https://www.facebook.com/help/"
      },
      {
        title: "Meta Business Help Center",
        url: "https://www.facebook.com/business/help"
      }
    ],
    rules: {
      status: "Phase 5 (2026-11-25) verified the Business Dashboard, the /post/create composer, the Page About editors (Intro bio, Category, Links, Contact info, Details address), and the Add action button dialog against a logged-in Business Page; see docs/research/facebook-dom.md and test/fixtures/facebook/. The Page creation view (/pages/creation/) was verified from the personal profile the same day; it refuses while acting as a Page. Hours stay unverified: Facebook locks them until an address is saved.",
      binding: "Controls are found by visible label, aria-label, or placeholder. Facebook does not publish input names and its class names change, so the shim never depends on either.",
      scope: `Business Pages only. Outside the Page creation view, the page must name the pack's Page (as a heading, the dashboard greeting "Hi <Page>", or the composer prompt "What's on your mind, <Page>?") and show at least one Page-admin signal, or the plan refuses with no actions.`,
      commit: "Create Page, Save, the action-button Save, and Post are commit actions. They run only after Approve & Commit for this exact plan hash.",
      media: "Profile picture and cover photo are attached by the person. The shim tracks them as a checklist and, when the pack marks one required, blocks commit until the file input has a file.",
      secrets: "Packs never carry passwords, two-factor codes, or access tokens. A sign-in page is refused.",
      pageSignals: ["Business Dashboard", "Manage Page", "Professional dashboard", "Meta Business Suite", "Edit Page", "Page settings", "Ad Center", "Boost post", "Switch into Page", "Insights"],
      createPaths: ["/pages/create", "/pages/creation"],
      hoursModes: ["No hours available", "Always open", "Open on selected hours"],
      tiers: {
        essentials: {
          name: "Facebook Business Page Setup Sprint: Essentials",
          priceUsd: 5,
          promise: "Page name, category, bio, and the main contact details, drafted into the Page form you have open. Nothing is created or saved until you click Approve & Commit.",
          fields: ["pageName", "categories", "bio", "website", "phone", "email", "profilePicture", "coverPhoto", "createPage", "saveChanges"]
        },
        standard: {
          name: "Facebook Business Page Setup Sprint: Standard Business",
          priceUsd: 15,
          promise: "Everything in Essentials plus address, hours, and the action button, drafted into the Page forms you have open. Nothing is saved until you click Approve & Commit.",
          fields: ["pageName", "categories", "bio", "website", "phone", "email", "address", "city", "zip", "hoursMode", "ctaType", "ctaUrl", "ctaSave", "profilePicture", "coverPhoto", "createPage", "saveChanges"]
        },
        launch: {
          name: "Facebook Business Page Setup Sprint: Full Launch + Post",
          priceUsd: 50,
          promise: "Everything in Standard Business plus a launch post drafted into the Page composer. Nothing is saved or posted until you click Approve & Commit.",
          fields: ["pageName", "categories", "bio", "website", "phone", "email", "address", "city", "zip", "hoursMode", "ctaType", "ctaUrl", "ctaSave", "launchPost", "publishPost", "profilePicture", "coverPhoto", "createPage", "saveChanges"]
        }
      }
    },
    fields: [
      {
        id: "pageName",
        labels: ["Page name", "Page name (required)", "Name of your Page"],
        path: "page.name",
        control: "text",
        required: true,
        maxLength: 75,
        step: "create",
        phase: "draft",
        notes: 'Verified at /pages/creation/: a <label> "Page name" wrapping input[type=text] inside role=form "Pages". No maxlength attribute, so the 75 cap stays unverified. Facebook reviews name changes on existing Pages.'
      },
      {
        id: "categories",
        labels: ["Categories", "Search category", "Category", "Category (required)"],
        path: "page.categories",
        control: "tokens",
        taxonomy: true,
        required: true,
        minItems: 1,
        maxItems: 3,
        step: "create",
        phase: "draft",
        notes: 'Verified: input[role=combobox][aria-label=Categories] with aria-controls to a role=listbox of role=option rows; chips sit in span[role=list][aria-label="Selected values"] with "Remove <name>" buttons; the editor counts "n/3 categories". Each value must be an option Facebook lists; the shim clicks it and never invents one. On /pages/creation/ the same combobox is labelled "Search category" (one category, plus two extra), beside "Popular categories" buttons.'
      },
      {
        id: "bio",
        labels: ["Introduce yourself", "Bio", "Bio (optional)", "Intro"],
        path: "page.bio",
        control: "textarea",
        maxLength: 255,
        step: "create",
        phase: "draft",
        notes: `Verified on About > Intro > Edit bio: a <label> "Introduce yourself" wrapping <textarea maxlength=255>. Any view's own maxlength still tightens the cap when lower. The /pages/creation/ step has no bio field; the bio is set afterwards in the About editor.`
      },
      {
        id: "website",
        labels: ["Website", "Website URL", "Link"],
        path: "contact.website",
        control: "url",
        format: "url",
        step: "contact",
        phase: "draft",
        notes: 'Verified: About > Links > "Websites, blogs, portfolios" opens a <label> "Link" wrapping input[type=text], beside "Link description" (maxlength 150) and an "Add link" button.'
      },
      {
        id: "phone",
        labels: ["Phone number", "Phone"],
        path: "contact.phone",
        control: "text",
        pattern: "^\\+?[0-9][0-9 ().-]{5,22}$",
        step: "contact",
        phase: "draft",
        notes: `Verified: <label> "Phone number" wrapping input[type=text], next to a separate country-code menu button (aria-label "Country code, US+1"). When the pack number starts with the picker's code, the shim drops the code and says so in the plan.`
      },
      {
        id: "email",
        labels: ["Email", "Email address"],
        path: "contact.email",
        control: "email",
        format: "email",
        step: "contact",
        phase: "draft",
        notes: 'Verified: <label> "Email" wrapping input[type=text] (not type=email).'
      },
      {
        id: "address",
        labels: ["Address", "Street address"],
        path: "contact.address",
        control: "text",
        maxLength: 200,
        step: "location",
        phase: "draft",
        notes: 'Verified: <label> "Address" wrapping input[type=text] in About > Details > Address. Hours stay locked until an address is saved.'
      },
      {
        id: "city",
        labels: ["City/Town", "City"],
        path: "contact.city",
        control: "text",
        step: "location",
        phase: "draft",
        notes: "Verified: City/Town is input[role=combobox][type=search], a typeahead that only counts a picked suggestion. The shim never types into it; the city is listed for the person to pick."
      },
      {
        id: "zip",
        labels: ["ZIP code", "Postal code", "ZIP"],
        path: "contact.zip",
        control: "text",
        maxLength: 12,
        step: "location",
        phase: "draft",
        notes: 'Verified: <label> "ZIP" wrapping input[type=text][maxlength=12].'
      },
      {
        id: "hoursMode",
        labels: ["Hours", "Business hours"],
        path: "hours.mode",
        control: "choice",
        step: "hours",
        phase: "draft",
        notes: "Radio group. Per-day opening times stay manual in v1 and are listed in the preview."
      },
      {
        id: "ctaType",
        labels: ["Choose an option", "Choose a button", "Which button do you want people to see?"],
        within: ["Action button", "Add action button", "Edit action button", "Add button"],
        path: "cta.type",
        control: "choice",
        step: "cta",
        phase: "draft",
        notes: 'Verified: profile "..." menu > Add action button > Try It opens the dialog "Action button" with 15 div[role=radio] rows (title plus description), each holding an inner role=radio aria-labelledby its title: Book now, Sign up, Start order, Get tickets, Send message, Send WhatsApp message, Call now, Send email, Contact us, Learn more, Watch now, Visit group, Play game, Buy now, Reserve. It is a two-step wizard: the person clicks Next, and Page Push re-plans the link step.'
      },
      {
        id: "ctaUrl",
        labels: ["Add website link", "Website", "Website URL", "Link"],
        within: ["Action button", "Add action button", "Edit action button", "Add button"],
        path: "cta.url",
        control: "url",
        format: "url",
        step: "cta",
        phase: "draft",
        notes: 'Verified: step two of the Action button dialog is a <label> "Add website link" wrapping input[type=text]; Save stays aria-disabled until it has a value.'
      },
      {
        id: "ctaSave",
        labels: ["Save"],
        within: ["Action button", "Add action button", "Edit action button", "Add button"],
        path: "commit.saveActionButton",
        control: "button",
        step: "cta",
        phase: "commit"
      },
      {
        id: "launchPost",
        labels: ["What's on your mind?", "Create a public post…", "Write something..."],
        within: ["Create post"],
        path: "launchPost.text",
        control: "textarea",
        maxLength: 63206,
        step: "post",
        phase: "draft",
        notes: `Verified at /post/create: div[role=textbox][contenteditable][data-lexical-editor] labelled "What's on your mind, <Page name>?" (the shim adds that label from the pack) inside role=form "Posts", in a role=main region whose title text is "Create post" (no heading element). No maxlength attribute, so the cap stays Facebook's published limit. Written through the browser input pipeline, never by setting DOM text.`
      },
      {
        id: "publishPost",
        labels: ["Post"],
        within: ["Create post"],
        path: "commit.publishLaunchPost",
        control: "button",
        step: "post",
        phase: "commit",
        notes: "Verified: div[role=button][aria-label=Post], aria-disabled until the composer has text; commit waits for it to enable. The Boost post and Add AI label switches beside it are never touched."
      },
      {
        id: "profilePicture",
        labels: ["Add profile picture", "Profile picture"],
        path: "media.profilePicture",
        control: "file",
        step: "customize",
        phase: "draft"
      },
      {
        id: "coverPhoto",
        labels: ["Add cover photo", "Cover photo"],
        path: "media.coverPhoto",
        control: "file",
        step: "customize",
        phase: "draft"
      },
      {
        id: "createPage",
        labels: ["Create a Page", "Create Page"],
        path: "commit.createPage",
        control: "button",
        step: "create",
        phase: "commit",
        notes: 'Verified: div[role=button][aria-label="Create a Page"], aria-disabled until the name and a category are set; commit waits for it to enable.'
      },
      {
        id: "saveChanges",
        labels: ["Save", "Save changes"],
        path: "commit.saveChanges",
        control: "button",
        pick: "last",
        step: "contact",
        phase: "commit",
        notes: "Verified: each About editor ends in div[role=button][aria-label=Save], aria-disabled until something changed, beside Cancel."
      }
    ]
  };

  // src/schema.ts
  var facebookSchema = schema_facebook_default;

  // src/shims/facebook.ts
  var WEEK = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"];
  var SECRET_KEY = /^(pass(word)?|passcode|token|access[_-]?token|secret|otp|2fa|two[_-]?factor|cookie|session)$/i;
  var SECRET_VALUE = /private key|begin [a-z ]*private|EAA[A-Za-z0-9]{20,}|sk_live_|api[_ -]?key|password\s*[:=]/i;
  function facebookTiers(schema = facebookSchema) {
    return schema.rules?.tiers ?? {};
  }
  function tierOffer(tier) {
    const rule = facebookTiers()[tier];
    return rule ? { name: rule.name, priceUsd: rule.priceUsd, promise: rule.promise } : null;
  }
  function prepareFacebookPack(pack) {
    const issues = [];
    const next = structuredClone(pack);
    const rule = facebookTiers()[next.tier];
    if (!rule) {
      issues.push(issue("error", "tier", "tier", `Unknown tier "${String(next.tier)}". Use essentials, standard, or launch.`));
    }
    next.page.name = (next.page.name ?? "").trim();
    next.page.categories = dedupe((next.page.categories ?? []).map((item) => item.trim()).filter(Boolean));
    if (next.page.bio != null) next.page.bio = next.page.bio.trim();
    if (next.contact) {
      for (const key of Object.keys(next.contact)) {
        const value = next.contact[key];
        if (typeof value === "string") next.contact[key] = value.trim();
      }
    }
    if (next.hours && (typeof next.hours.mode !== "string" || !next.hours.mode.trim())) delete next.hours;
    else if (next.hours) next.hours.mode = next.hours.mode.trim();
    if (next.cta) {
      next.cta.type = next.cta.type.trim();
      if (next.cta.url != null) next.cta.url = next.cta.url.trim();
    }
    if (next.launchPost) next.launchPost.text = next.launchPost.text.trim();
    next.commit = {
      createPage: next.commit?.createPage ?? true,
      saveChanges: next.commit?.saveChanges ?? true,
      saveActionButton: next.commit?.saveActionButton ?? Boolean(next.cta?.type),
      publishLaunchPost: next.commit?.publishLaunchPost ?? Boolean(next.launchPost?.text)
    };
    if (rule) {
      for (const field of facebookSchema.fields) {
        if (rule.fields.includes(field.id)) continue;
        const value = getPath(next, field.path);
        if (isBlank(value) || value === false) continue;
        unsetPath(next, field.path);
        if (field.phase === "commit") continue;
        issues.push(issue(
          "warning",
          field.id,
          "out-of-tier",
          `${field.labels[0]} is not part of the ${rule.name.split(": ").pop()} tier and was left out.`
        ));
      }
    }
    return { pack: next, issues };
  }
  function assessFacebook(pack) {
    const issues = [];
    for (const path of secretPaths(pack)) {
      issues.push(issue("error", path, "secret", `The pack holds something that looks like a credential at ${path}. Remove it; do not enter sign-in details in a pack.`));
    }
    if (!pack.page?.name?.trim()) issues.push(issue("error", "pageName", "required", "The pack needs the Page name."));
    const categories = asStringList(pack.page?.categories) ?? [];
    if (!categories.length) issues.push(issue("error", "categories", "required", "The pack needs at least one Page category."));
    const modes = facebookSchema.rules?.hoursModes ?? [];
    const hoursMode = typeof pack.hours?.mode === "string" ? pack.hours.mode.trim() : "";
    if (hoursMode && !modes.some((mode) => labelKey(mode) === labelKey(hoursMode))) {
      issues.push(issue("error", "hoursMode", "enum", `Hours must be one of: ${modes.join(", ")}.`));
    }
    if (pack.hours?.schedule && labelKey(hoursMode) !== labelKey("Open on selected hours")) {
      issues.push(issue("warning", "hoursMode", "schedule-ignored", 'Opening times only apply to "Open on selected hours".'));
    }
    if (pack.cta && !pack.cta.url && !/call|message|email/i.test(pack.cta.type)) {
      issues.push(issue("warning", "ctaUrl", "cta-url", `The "${pack.cta.type}" button usually needs a link.`));
    }
    return issues;
  }
  function planFacebook(doc, pack, pageUrl) {
    const prepared = prepareFacebookPack(pack);
    const offer = tierOffer(prepared.pack.tier) ?? void 0;
    const phoneIssues = fitPhoneToPicker(doc, prepared.pack);
    return buildPlan({
      schema: schemaFor(prepared.pack),
      document: doc,
      pack: prepared.pack,
      pageUrl,
      offer,
      extraIssues: [...prepared.issues, ...phoneIssues, ...assessFacebook(pack)],
      guard: (page) => guardFacebook(page, prepared.pack, pageUrl),
      onUnmapped: (control, draft) => onFacebookUnmapped(control, draft),
      after: (draft) => facebookAfter(draft, prepared.pack)
    });
  }
  function composerPrompt(pageName) {
    return `What's on your mind, ${pageName}?`;
  }
  function schemaFor(pack) {
    const name = pack.page?.name?.trim();
    if (!name) return facebookSchema;
    return {
      ...facebookSchema,
      fields: facebookSchema.fields.map(
        (field) => field.id === "launchPost" ? { ...field, labels: [composerPrompt(name), ...field.labels] } : field
      )
    };
  }
  function fitPhoneToPicker(doc, pack) {
    const phone = pack.contact?.phone;
    if (!phone || !phone.startsWith("+")) return [];
    const picker = Array.from(doc.querySelectorAll("[aria-label]")).find((el) => /^country code\b/i.test(el.getAttribute("aria-label") ?? ""));
    const code = /\+(\d{1,4})\s*$/.exec(picker?.getAttribute("aria-label") ?? "")?.[1];
    if (!code) return [];
    const match = new RegExp(`^\\+${code}(?![0-9])[\\s.-]*`).exec(phone);
    if (!match) {
      return [issue("warning", "phone", "country-code", `Facebook's country picker shows +${code}, but the phone number starts with a different code. Pick the country yourself before saving.`)];
    }
    pack.contact.phone = phone.slice(match[0].length);
    return [issue("warning", "phone", "country-code", `Facebook's country picker already shows +${code}, so the number is drafted as "${pack.contact.phone}".`)];
  }
  function facebookContext(pageUrl) {
    let url;
    try {
      url = new URL(pageUrl);
    } catch {
      return "off-site";
    }
    const host = url.hostname.toLowerCase();
    if (url.protocol !== "https:" || !(host === "facebook.com" || host.endsWith(".facebook.com"))) return "off-site";
    const createPaths = facebookSchema.rules?.createPaths ?? [];
    return createPaths.some((path) => url.pathname === path || url.pathname.startsWith(`${path}/`)) ? "create" : "page";
  }
  function guardFacebook(page, pack, pageUrl) {
    const context = facebookContext(pageUrl);
    if (context === "off-site") {
      return [issue("error", "page", "not-facebook", "Open the Facebook Business Page view in this tab. Page Push only runs on https://facebook.com.")];
    }
    if (context === "create") return [];
    const doc = page.document;
    const rawName = (pack.page?.name ?? "").trim();
    const name = labelKey(rawName);
    const headingNames = /* @__PURE__ */ new Set([name, labelKey(`Hi ${rawName}`)]);
    const headings = Array.from(doc.querySelectorAll("h1, h2, [role='heading']"));
    const prompt = labelKey(composerPrompt(rawName));
    const named = name !== "" && (headings.some((heading) => headingNames.has(labelKey(heading.textContent ?? ""))) || Array.from(doc.querySelectorAll("[role='textbox'][aria-label]")).some((box) => labelKey(box.getAttribute("aria-label") ?? "") === prompt));
    if (!named) {
      return [issue(
        "error",
        "page",
        "page-identity",
        `This view does not show the Page "${pack.page?.name ?? ""}". Switch into that Business Page, open its settings or composer, and plan again.`
      )];
    }
    const signals = (facebookSchema.rules?.pageSignals ?? []).map((signal) => labelKey(signal));
    const signalNodes = doc.querySelectorAll(
      "a, button, [role='button'], [role='link'], [role='tab'], [role='menuitem'], h1, h2, h3, [role='heading']"
    );
    const admin = Array.from(signalNodes).some((node) => {
      const texts = [visibleText(node), node.getAttribute("aria-label") ?? ""];
      return texts.some((text) => text && signals.includes(labelKey(text)));
    });
    if (!admin) {
      return [issue(
        "error",
        "page",
        "not-business-page",
        "This looks like a personal profile or a Page you are not managing. Page Push only fills Business Pages you administer."
      )];
    }
    return [];
  }
  function facebookAfter(draft, pack) {
    for (const id of ["profilePicture", "coverPhoto"]) {
      if (pack.media?.[id] !== "required") continue;
      const field = facebookSchema.fields.find((item) => item.id === id);
      const control = fileControl(draft.page.controls, field);
      if (!control) continue;
      draft.notes = draft.notes.filter((note) => !note.startsWith(`${field.labels[0]}:`));
      draft.gates.push({
        code: "file",
        fieldId: id,
        controlId: control.id,
        message: `Attach the ${id === "profilePicture" ? "profile picture" : "cover photo"} yourself before commit.`
      });
    }
    const city = draft.actions.find((action2) => action2.id === "city");
    const cityEl = city ? draft.page.document.getElementById(city.controlId) : null;
    if (city && cityEl?.getAttribute("role") === "combobox") {
      draft.actions = draft.actions.filter((action2) => action2 !== city);
      draft.notes.push(`City/Town: pick "${String(city.value)}" from Facebook's suggestions yourself`);
    }
    const hoursPlanned = draft.actions.some((action2) => action2.id === "hoursMode");
    const schedule = pack.hours?.schedule;
    if (hoursPlanned && schedule && labelKey(pack.hours.mode) === labelKey("Open on selected hours")) {
      const days = WEEK.filter((day) => schedule[day]?.trim()).map((day) => `${day.slice(0, 3)} ${schedule[day].trim()}`);
      if (days.length) draft.notes.push(`Opening times: set by hand (${days.join(", ")})`);
    }
  }
  function onFacebookUnmapped(control, draft) {
    if (control.disabled || isButtonControl(control) || !control.required) return;
    const prompt = control.rawLabels[0];
    if (!prompt) return;
    draft.warnings.push(issue("warning", `custom:${labelKey(prompt)}`, "unmapped", `Left "${prompt}" alone. Fill it yourself if Facebook asks for it.`));
  }
  function fileControl(controls, field) {
    return controls.find((control) => control.type === "file" && labelMatches(control, field.labels, "exact"));
  }
  function secretPaths(value, path = "") {
    if (typeof value === "string") return SECRET_VALUE.test(value) ? [path || "pack"] : [];
    if (Array.isArray(value)) return value.flatMap((item, index) => secretPaths(item, `${path}[${index}]`));
    if (!value || typeof value !== "object") return [];
    return Object.entries(value).flatMap(([key, item]) => {
      const next = path ? `${path}.${key}` : key;
      return SECRET_KEY.test(key) ? [next] : secretPaths(item, next);
    });
  }
  function unsetPath(root, path) {
    const keys = path.split(".");
    const last = keys.pop();
    let current = root;
    for (const key of keys) {
      if (current == null || typeof current !== "object") return;
      current = current[key];
    }
    if (last && current && typeof current === "object") delete current[last];
  }

  // src/extension/controller.ts
  function createController(deps) {
    const doc = deps.document;
    const isUserEdit = deps.isUserEdit ?? ((event) => event.isTrusted);
    let active = null;
    let drafted = false;
    let drift = /* @__PURE__ */ new Set();
    let lastUrl = deps.location.href;
    let working = false;
    let disposed = false;
    const onEdit = (event) => {
      if (!active || !drafted || !isUserEdit(event)) return;
      const target = event.target;
      if (!target) return;
      const hit = active.actions.filter((action2) => {
        if (action2.phase !== "draft") return false;
        const control = doc.getElementById(action2.controlId);
        return control != null && (control === target || control.contains(target));
      });
      if (!hit.length) return;
      const changed = checkDrift(doc, active, hit.map((action2) => action2.id));
      const fresh = changed.filter((id) => !drift.has(id));
      for (const id of changed) drift.add(id);
      if (fresh.length) deps.notify({ type: "pagepush:drift", url: deps.location.href, planHash: active.planHash, fields: fresh });
    };
    doc.addEventListener("input", onEdit, true);
    doc.addEventListener("change", onEdit, true);
    const view = doc.defaultView;
    const Observer = view?.MutationObserver ?? globalThis.MutationObserver;
    let observer = null;
    let dialogs = dialogCount();
    if ((deps.watchDialogs ?? true) && typeof Observer === "function") {
      observer = new Observer(() => {
        const count = dialogCount();
        if (deps.location.href !== lastUrl) {
          lastUrl = deps.location.href;
          dialogs = count;
          deps.notify({ type: "pagepush:view-changed", url: lastUrl, reason: "navigated" });
          return;
        }
        if (count !== dialogs) {
          dialogs = count;
          deps.notify({ type: "pagepush:view-changed", url: lastUrl, reason: "dialog" });
        }
      });
      observer.observe(doc.documentElement, { childList: true, subtree: true });
    }
    function dialogCount() {
      return doc.querySelectorAll("[role='dialog']").length;
    }
    function state() {
      return active ? { plan: active, drafted, drift: [...drift] } : {};
    }
    function current(planHash) {
      const url = deps.location.href;
      if (!active) return { ok: false, url, code: "no-plan", message: "This tab has no plan. Plan the page again." };
      if (active.planHash !== planHash) {
        return { ok: false, url, code: "confirm", message: "The side panel is showing a different plan. Plan the page again." };
      }
      if (active.pageUrl !== url) {
        return { ok: false, url, code: "context", message: "The page changed since this plan. Plan this view again." };
      }
      return active;
    }
    async function handle(request) {
      const url = deps.location.href;
      if (working && (request.type === "pagepush:draft" || request.type === "pagepush:commit" || request.type === "pagepush:plan")) {
        return { ok: false, url, code: "busy", message: "Page Push is still writing to this page. Wait for it to finish." };
      }
      try {
        switch (request.type) {
          case "pagepush:status":
            if (active && active.pageUrl !== url) {
              active = null;
              drafted = false;
              drift = /* @__PURE__ */ new Set();
            }
            return { ok: true, url, ...state() };
          case "pagepush:plan":
            active = planFacebook(doc, request.pack, url);
            active.planHash = sha256({ contentHash: active.planHash, instance: planInstanceId(active) });
            drafted = false;
            drift = /* @__PURE__ */ new Set();
            dialogs = dialogCount();
            lastUrl = url;
            return { ok: true, url, ...state() };
          case "pagepush:draft": {
            const plan = current(request.planHash);
            if ("ok" in plan) return plan;
            if (plan.errors.length) return { ok: false, url, code: "blocked", message: plan.errors.map((item) => item.message).join(" ") };
            working = true;
            let draft;
            try {
              draft = await executeDraft(doc, plan, { settleMs: deps.settleMs, currentUrl: () => deps.location.href, isCurrent: () => !disposed && active === plan });
            } finally {
              working = false;
            }
            if (disposed || active !== plan || deps.location.href !== plan.pageUrl) {
              if (active === plan) active = null;
              return { ok: false, url: deps.location.href, code: "context", message: "The page changed while drafting. Plan this view again." };
            }
            drafted = true;
            drift = /* @__PURE__ */ new Set();
            return { ok: true, url, draft, ...state() };
          }
          case "pagepush:verify": {
            const plan = current(request.planHash);
            if ("ok" in plan) return plan;
            if (drafted) for (const id of checkDrift(doc, plan)) drift.add(id);
            return { ok: true, url, ...state() };
          }
          case "pagepush:commit": {
            const plan = current(request.planHash);
            if ("ok" in plan) return plan;
            if (drift.size) {
              return { ok: false, url, code: "drift", message: `Changed on the page after drafting: ${[...drift].join(", ")}. Plan again.` };
            }
            active = null;
            drafted = false;
            working = true;
            try {
              await executeCommit(doc, plan, approve(plan), {
                settleMs: deps.settleMs,
                currentUrl: () => deps.location.href,
                isCurrent: () => !disposed
              });
            } catch (error) {
              if (error instanceof CommitRefused && error.applied.length === 0 && ["captcha", "file", "blocked"].includes(error.code) && !disposed && deps.location.href === plan.pageUrl) {
                active = plan;
                drafted = true;
              }
              throw error;
            } finally {
              working = false;
            }
            if (disposed || deps.location.href !== plan.pageUrl) {
              return { ok: false, url: deps.location.href, code: "context", message: "The page changed during commit. Do not retry without reviewing the page." };
            }
            return { ok: true, url: deps.location.href, plan, committed: true };
          }
        }
      } catch (error) {
        if (error instanceof CommitRefused) {
          return { ok: false, url: deps.location.href, code: error.code, message: error.message, applied: [...error.applied] };
        }
        return { ok: false, url: deps.location.href, code: "error", message: error instanceof Error ? error.message : String(error) };
      }
    }
    return {
      handle,
      dispose() {
        disposed = true;
        active = null;
        doc.removeEventListener("input", onEdit, true);
        doc.removeEventListener("change", onEdit, true);
        observer?.disconnect();
      }
    };
  }

  // src/extension/messages.ts
  function isPanelRequest(value) {
    if (!value || typeof value !== "object") return false;
    const type = value.type;
    return typeof type === "string" && ["pagepush:plan", "pagepush:draft", "pagepush:verify", "pagepush:commit", "pagepush:status"].includes(type);
  }

  // src/extension/content.ts
  var controller = createController({
    document,
    location,
    notify(event) {
      chrome.runtime.sendMessage(event).catch(() => void 0);
    }
  });
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!isPanelRequest(message)) return void 0;
    void controller.handle(message).then(sendResponse, (error) => {
      sendResponse({ ok: false, code: "error", message: error instanceof Error ? error.message : String(error) });
    });
    return true;
  });
})();
