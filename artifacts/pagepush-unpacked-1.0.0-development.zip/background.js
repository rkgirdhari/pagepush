"use strict";
(() => {
  // src/extension/background.ts
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch((error) => {
    console.error("Page Push could not set the side panel behaviour", error);
  });
})();
