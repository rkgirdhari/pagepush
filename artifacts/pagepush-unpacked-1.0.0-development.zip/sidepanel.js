"use strict";
(() => {
  // src/sha256.ts
  var K = new Uint32Array([
    1116352408,
    1899447441,
    3049323471,
    3921009573,
    961987163,
    1508970993,
    2453635748,
    2870763221,
    3624381080,
    310598401,
    607225278,
    1426881987,
    1925078388,
    2162078206,
    2614888103,
    3248222580,
    3835390401,
    4022224774,
    264347078,
    604807628,
    770255983,
    1249150122,
    1555081692,
    1996064986,
    2554220882,
    2821834349,
    2952996808,
    3210313671,
    3336571891,
    3584528711,
    113926993,
    338241895,
    666307205,
    773529912,
    1294757372,
    1396182291,
    1695183700,
    1986661051,
    2177026350,
    2456956037,
    2730485921,
    2820302411,
    3259730800,
    3345764771,
    3516065817,
    3600352804,
    4094571909,
    275423344,
    430227734,
    506948616,
    659060556,
    883997877,
    958139571,
    1322822218,
    1537002063,
    1747873779,
    1955562222,
    2024104815,
    2227730452,
    2361852424,
    2428436474,
    2756734187,
    3204031479,
    3329325298
  ]);
  var INITIAL = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225];
  var encoder = new TextEncoder();
  function sha256Hex(input) {
    const bytes = typeof input === "string" ? encoder.encode(input) : input;
    const bitLength = bytes.length * 8;
    const padded = new Uint8Array(Math.ceil((bytes.length + 9) / 64) * 64);
    padded.set(bytes);
    padded[bytes.length] = 128;
    const view = new DataView(padded.buffer);
    view.setUint32(padded.length - 8, Math.floor(bitLength / 4294967296), false);
    view.setUint32(padded.length - 4, bitLength >>> 0, false);
    const h = Uint32Array.from(INITIAL);
    const w = new Uint32Array(64);
    for (let offset = 0; offset < padded.length; offset += 64) {
      for (let i = 0; i < 16; i += 1) w[i] = view.getUint32(offset + i * 4, false);
      for (let i = 16; i < 64; i += 1) {
        const a2 = w[i - 15];
        const b2 = w[i - 2];
        const s0 = rotr(a2, 7) ^ rotr(a2, 18) ^ a2 >>> 3;
        const s1 = rotr(b2, 17) ^ rotr(b2, 19) ^ b2 >>> 10;
        w[i] = w[i - 16] + s0 + w[i - 7] + s1 >>> 0;
      }
      let a = h[0], b = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], k = h[7];
      for (let i = 0; i < 64; i += 1) {
        const t1 = k + (rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)) + (e & f ^ ~e & g) + K[i] + w[i] >>> 0;
        const t2 = (rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)) + (a & b ^ a & c ^ b & c) >>> 0;
        k = g;
        g = f;
        f = e;
        e = d + t1 >>> 0;
        d = c;
        c = b;
        b = a;
        a = t1 + t2 >>> 0;
      }
      h[0] = h[0] + a >>> 0;
      h[1] = h[1] + b >>> 0;
      h[2] = h[2] + c >>> 0;
      h[3] = h[3] + d >>> 0;
      h[4] = h[4] + e >>> 0;
      h[5] = h[5] + f >>> 0;
      h[6] = h[6] + g >>> 0;
      h[7] = h[7] + k >>> 0;
    }
    let hex = "";
    for (const word of h) hex += word.toString(16).padStart(8, "0");
    return hex;
  }
  function rotr(value, bits) {
    return value >>> bits | value << 32 - bits;
  }

  // src/util.ts
  function issue(level, fieldId, code, message) {
    return { level, fieldId, code, message };
  }
  function normalize(value) {
    return value.replace(/\s+/g, " ").trim().toLowerCase();
  }
  function labelKey(value) {
    return normalize(value).replace(/[*]\s*$/, "").replace(/\s*\(required\)$/, "").trim();
  }
  function charLength(value) {
    return Array.from(value).length;
  }
  function wordCount(value) {
    return value.trim().split(/\s+/).filter(Boolean).length;
  }
  function getPath(root, path) {
    let current = root;
    for (const key of path.split(".")) {
      if (current == null || typeof current !== "object") return void 0;
      current = current[key];
    }
    return current;
  }
  function isHttpUrl(value) {
    try {
      const url = new URL(value);
      return url.protocol === "https:" || url.protocol === "http:";
    } catch {
      return false;
    }
  }
  function isEmail(value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  }
  function isFullDay(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const [year, month, day] = value.split("-").map(Number);
    if (year == null || month == null || day == null) return false;
    const date = new Date(Date.UTC(year, month - 1, day));
    return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
  }
  var VIDEO_HOSTS = ["youtube.com", "youtu.be", "vimeo.com", "youku.com"];
  function isDevpostVideo(value) {
    if (!isHttpUrl(value)) return false;
    const url = new URL(value);
    if (url.protocol !== "https:") return false;
    const host = url.hostname.toLowerCase().replace(/^www\./, "").replace(/^m\./, "");
    return VIDEO_HOSTS.some((allowed) => host === allowed || host.endsWith(`.${allowed}`));
  }
  function stableStringify(value) {
    if (value === null || typeof value !== "object") return JSON.stringify(value);
    if (Array.isArray(value)) return `[${value.map((item) => stableStringify(item)).join(",")}]`;
    const record = value;
    return `{${Object.keys(record).sort().map((key) => `${JSON.stringify(key)}:${stableStringify(record[key])}`).join(",")}}`;
  }
  function sha256(value) {
    return sha256Hex(stableStringify(value));
  }
  function dedupe(values) {
    const seen = /* @__PURE__ */ new Set();
    const result = [];
    for (const value of values) {
      const key = value.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      result.push(value);
    }
    return result;
  }

  // src/validate.ts
  function validateField(field, value, maxLength = field.maxLength) {
    const issues = [];
    if (typeof value === "string") {
      checkString(field, value, maxLength, issues);
      return issues;
    }
    if (typeof value === "number") {
      if (field.minimum != null && value < field.minimum) {
        issues.push(issue("error", field.id, "min", `${field.labels[0]} must be at least ${field.minimum}.`));
      }
      if (field.maximum != null && value > field.maximum) {
        issues.push(issue("error", field.id, "max", `${field.labels[0]} must be at most ${field.maximum}.`));
      }
      return issues;
    }
    if (Array.isArray(value)) {
      const items = value.filter((item) => typeof item === "string");
      if (items.length !== value.length) {
        issues.push(issue("error", field.id, "type", `${field.labels[0]} must be a list of text.`));
        return issues;
      }
      if (field.minItems != null && items.length < field.minItems) {
        issues.push(issue("error", field.id, "min-items", `${field.labels[0]} needs at least ${field.minItems}.`));
      }
      if (field.maxItems != null && items.length > field.maxItems) {
        issues.push(issue("error", field.id, "max-items", `${field.labels[0]} allows at most ${field.maxItems}.`));
      }
      items.forEach((item, index) => {
        if (field.itemMaxLength != null && charLength(item) > field.itemMaxLength) {
          issues.push(issue("error", field.id, "item-length", `${field.labels[0]} item ${index + 1} is over ${field.itemMaxLength} characters.`));
        }
        if (field.itemMinWords != null && wordCount(item) < field.itemMinWords) {
          issues.push(issue("error", field.id, "item-words", `${field.labels[0]} item ${index + 1} needs at least ${field.itemMinWords} words.`));
        }
        if (field.format === "url" && !isHttpUrl(item)) {
          issues.push(issue("error", field.id, "url", `${field.labels[0]} item ${index + 1} must be an http(s) URL.`));
        }
        if (field.format === "email" && !isEmail(item)) {
          issues.push(issue("error", field.id, "email", `${field.labels[0]} item ${index + 1} must be an email address.`));
        }
      });
    }
    return issues;
  }
  function checkString(field, value, maxLength, issues) {
    const length = charLength(value);
    if (field.minLength != null && length < field.minLength) {
      issues.push(issue("error", field.id, "min-length", `${field.labels[0]} must be at least ${field.minLength} characters.`));
    }
    if (maxLength != null && length > maxLength) {
      issues.push(issue("error", field.id, "max-length", `${field.labels[0]} must be at most ${maxLength} characters.`));
    }
    if (field.enum && !field.enum.includes(value)) {
      issues.push(issue("error", field.id, "enum", `${field.labels[0]} must be one of: ${field.enum.join(", ")}.`));
    }
    if (field.pattern && !new RegExp(field.pattern).test(value)) {
      issues.push(issue("error", field.id, "pattern", `${field.labels[0]} does not match the expected format.`));
    }
    if ((field.format === "url" || field.control === "url") && !isHttpUrl(value)) {
      issues.push(issue("error", field.id, "url", `${field.labels[0]} must be an http(s) URL.`));
    }
    if (field.format === "email" && !isEmail(value)) {
      issues.push(issue("error", field.id, "email", `${field.labels[0]} must be an email address.`));
    }
    if (field.format === "date" && !isFullDay(value)) {
      issues.push(issue("error", field.id, "date", `${field.labels[0]} must be a full day, YYYY-MM-DD.`));
    }
    if (field.format === "video" && !isDevpostVideo(value)) {
      issues.push(issue("error", field.id, "video", `${field.labels[0]} must be a public https YouTube, Vimeo, or Youku URL.`));
    }
  }
  function asStringList(value) {
    if (typeof value === "string") return value.trim() ? [value.trim()] : [];
    if (Array.isArray(value) && value.every((item) => typeof item === "string")) {
      return value.map((item) => item.trim()).filter(Boolean);
    }
    return null;
  }
  function isBlank(value) {
    if (value == null) return true;
    if (typeof value === "string") return value.trim().length === 0;
    if (Array.isArray(value)) return value.length === 0;
    return false;
  }

  // schemas/schema_appsumo.json
  var schema_appsumo_default = {
    id: "appsumo",
    version: "2026-10-28",
    title: "AppSumo partner listing",
    offer: {
      name: "AppSumo Application Service",
      priceUsd: 200,
      promise: "A finished listing draft in the partner editor, from your product facts. You read it and confirm on your phone before it is submitted for review."
    },
    sources: [
      {
        title: "AppSumo listing brief",
        url: "https://partners.appsumo.com/docs/listing-brief.md"
      },
      {
        title: "Connect an agent to AppSumo",
        url: "https://partners.appsumo.com/docs/agent-setup.md"
      }
    ],
    rules: {
      binding: "The listing brief says every field name matches a labelled field in the partner editor. This shim binds those labels. Searchable values must be chosen from the options on the page.",
      officialApi: "AppSumo also ships an MCP at https://appsumo.com/mcp/ with update_submission. writesTo is the path that tool expects. This package fills the open editor; it does not call the MCP.",
      submit: "submit_for_review waits until the partner has read the draft. The phone confirm is that approval.",
      trustSignals: "Stripe ARR, LinkedIn company page, G2, and Capterra stay manual. The shim never writes them.",
      secrets: "Licensing private keys and redemption code files stay out of the pack. Codes are attached in the editor by the partner.",
      voice: {
        banned: [
          "seamless",
          "robust",
          "revolutionary",
          "cutting-edge",
          "game-changing",
          "world-class",
          "leverage",
          "unlock",
          "empower",
          "elevate",
          "showcasing",
          "enhancing",
          "streamlining"
        ]
      },
      enums: {
        teamSize: ["1-10", "11-50", "51-200", "201-500", "501+"],
        stage: ["Startup", "Growth", "Expansion", "Established"],
        funding: ["Bootstrapped", "Pre-Seed", "Seed", "Series A", "Series B", "Series C+", "Public Company", "Acquired"]
      },
      pricing: {
        addTier: "Add tier",
        addFeature: "Add feature",
        tierName: "Tier name",
        price: "Price",
        originalPrice: "Original price",
        recommended: "Mark as Recommended",
        feature: "Feature",
        tooltip: "Tooltip",
        value: "Value"
      },
      features: {
        add: "Add story",
        header: "Section header",
        title: "Title",
        bullets: "Bullets"
      },
      faq: {
        add: "Add FAQ",
        question: "Question",
        answer: "Answer"
      }
    },
    fields: [
      {
        id: "productName",
        labels: ["Product name"],
        path: "product.name",
        control: "text",
        required: true,
        minLength: 3,
        maxLength: 50,
        step: "basics",
        phase: "draft",
        writesTo: "product.name"
      },
      {
        id: "category",
        labels: ["Category"],
        path: "product.category",
        control: "tokens",
        taxonomy: true,
        required: true,
        minItems: 1,
        maxItems: 1,
        step: "basics",
        phase: "draft",
        writesTo: "product.attributes.category",
        notes: "Send the option slug. product.categories is a display name and does not drive the picker."
      },
      {
        id: "subcategory",
        labels: ["Subcategory"],
        path: "product.subcategory",
        control: "tokens",
        taxonomy: true,
        required: true,
        minItems: 1,
        maxItems: 1,
        step: "basics",
        phase: "draft",
        writesTo: "product.attributes.subcategory"
      },
      {
        id: "tagline",
        labels: ["Tagline"],
        path: "story.tagline",
        control: "text",
        required: true,
        minLength: 3,
        maxLength: 100,
        step: "basics",
        phase: "draft",
        writesTo: "story.subheader"
      },
      {
        id: "usp",
        labels: ["Unique selling proposition"],
        path: "story.usp",
        control: "text",
        required: true,
        minLength: 15,
        maxLength: 40,
        step: "basics",
        phase: "draft",
        writesTo: "story.value_prop"
      },
      {
        id: "intro",
        labels: ["Intro sentence"],
        path: "story.intro",
        control: "textarea",
        required: true,
        maxLength: 205,
        step: "basics",
        phase: "draft",
        writesTo: "story.tldr_overview"
      },
      {
        id: "tldr",
        labels: ["TL;DR"],
        path: "story.tldr",
        control: "lines",
        addLabel: "Add TL;DR",
        required: true,
        minItems: 2,
        maxItems: 2,
        itemMaxLength: 128,
        itemMinWords: 3,
        step: "basics",
        phase: "draft",
        writesTo: "story.highlights[].highlight"
      },
      {
        id: "alternativeTo",
        labels: ["Alternative to"],
        path: "product.alternativeTo",
        control: "tokens",
        taxonomy: true,
        required: true,
        minItems: 1,
        maxItems: 3,
        step: "basics",
        phase: "draft",
        writesTo: "product.attributes.alternative_to"
      },
      {
        id: "integrations",
        labels: ["Integrations"],
        path: "product.integrations",
        control: "tokens",
        taxonomy: true,
        maxItems: 5,
        step: "basics",
        phase: "draft",
        writesTo: "product.attributes.integrations"
      },
      {
        id: "bestFor",
        labels: ["Best for"],
        path: "product.bestFor",
        control: "tokens",
        taxonomy: true,
        required: true,
        minItems: 1,
        maxItems: 3,
        step: "basics",
        phase: "draft",
        writesTo: "product.attributes.best_for"
      },
      {
        id: "icon",
        labels: ["Icon"],
        path: "media.icon",
        control: "file",
        required: true,
        step: "media",
        phase: "draft",
        writesTo: "assets.logos.logo",
        notes: "PNG or JPG under 5MB. Shortest side at least 50px. Logo mark only."
      },
      {
        id: "logo",
        labels: ["Logo"],
        path: "media.logo",
        control: "file",
        step: "media",
        phase: "draft",
        writesTo: "assets.logos.logo_long",
        notes: "Required for Launchpad and Select, optional for Radar. Use the real logo."
      },
      {
        id: "hero",
        labels: ["Hero image"],
        path: "media.hero",
        control: "file",
        required: true,
        step: "media",
        phase: "draft",
        writesTo: "assets.main_image",
        notes: "At least 960x540, under 5MB. Alt text up to 255 characters."
      },
      {
        id: "screenshots",
        labels: ["Product screenshots", "Screenshots"],
        path: "media.screenshots",
        control: "file",
        required: true,
        step: "media",
        phase: "draft",
        writesTo: "assets.additional_images",
        notes: "Up to 4 images, one per feature story, same order."
      },
      {
        id: "features",
        labels: ["Highlighted features"],
        path: "story.features",
        control: "features",
        required: true,
        step: "features",
        phase: "draft",
        writesTo: "story.features"
      },
      {
        id: "pricing",
        labels: ["Pricing"],
        path: "pricing",
        control: "pricing",
        required: true,
        step: "pricing",
        phase: "draft",
        writesTo: "plans[]"
      },
      {
        id: "headline",
        labels: ["Headline"],
        path: "company.headline",
        control: "text",
        required: true,
        maxLength: 64,
        step: "story",
        phase: "draft",
        writesTo: "company.founder_posts[].title"
      },
      {
        id: "narrative",
        labels: ["Founder narrative"],
        path: "company.narrative",
        control: "textarea",
        required: true,
        step: "story",
        phase: "draft",
        writesTo: "company.founder_posts[].message",
        notes: "At least two paragraphs. Each paragraph up to 3000 characters."
      },
      {
        id: "founderName",
        labels: ["Founder name", "Name"],
        path: "company.founder.name",
        control: "text",
        required: true,
        maxLength: 120,
        step: "story",
        phase: "draft",
        writesTo: "contacts[].name"
      },
      {
        id: "founderRole",
        labels: ["Role"],
        path: "company.founder.role",
        control: "text",
        maxLength: 120,
        step: "story",
        phase: "draft",
        writesTo: "contacts[].title"
      },
      {
        id: "founderLinkedIn",
        labels: ["Founder LinkedIn", "LinkedIn URL"],
        path: "company.founder.linkedinUrl",
        control: "url",
        format: "url",
        maxLength: 500,
        step: "story",
        phase: "draft",
        writesTo: "contacts[].linkedin_url",
        notes: "The founder's profile. The company LinkedIn page is a trust signal and is not this field."
      },
      {
        id: "founded",
        labels: ["Founded"],
        path: "company.founded",
        control: "date",
        format: "date",
        required: true,
        step: "story",
        phase: "draft",
        writesTo: "founders_data.founded_at",
        notes: "A full day, YYYY-MM-DD. A year on its own is not stored."
      },
      {
        id: "headquarters",
        labels: ["Headquarters"],
        path: "company.headquarters",
        control: "tokens",
        taxonomy: true,
        required: true,
        minItems: 1,
        maxItems: 1,
        step: "story",
        phase: "draft",
        writesTo: "founders_data.headquarters",
        notes: "City or country from the list. Not Remote."
      },
      {
        id: "teamSize",
        labels: ["Team size"],
        path: "company.teamSize",
        control: "select",
        required: true,
        enum: ["1-10", "11-50", "51-200", "201-500", "501+"],
        step: "story",
        phase: "draft",
        writesTo: "founders_data.company_size"
      },
      {
        id: "stage",
        labels: ["Stage"],
        path: "company.stage",
        control: "select",
        required: true,
        enum: ["Startup", "Growth", "Expansion", "Established"],
        step: "story",
        phase: "draft",
        writesTo: "founders_data.product_stage"
      },
      {
        id: "funding",
        labels: ["Funding"],
        path: "company.funding",
        control: "select",
        required: true,
        enum: ["Bootstrapped", "Pre-Seed", "Seed", "Series A", "Series B", "Series C+", "Public Company", "Acquired"],
        step: "story",
        phase: "draft",
        writesTo: "founders_data.financial_stage"
      },
      {
        id: "faqs",
        labels: ["FAQ"],
        path: "faqs",
        control: "faq",
        required: true,
        minItems: 1,
        step: "faq",
        phase: "draft",
        writesTo: "faqs[].question / faqs[].answer",
        notes: "At least one pair. Six to eight is what the brief recommends. Question up to 255 characters. Answer under two sentences."
      },
      {
        id: "supportEmail",
        labels: ["Support email"],
        path: "fulfillment.supportEmail",
        control: "email",
        format: "email",
        required: true,
        step: "redemption",
        phase: "draft"
      },
      {
        id: "redemptionInstructions",
        labels: ["Redemption instructions"],
        path: "fulfillment.instructions",
        control: "textarea",
        required: true,
        step: "redemption",
        phase: "draft",
        notes: "The steps a buyer follows after purchase. Pass an array of steps; the shim numbers them."
      },
      {
        id: "redeemUrl",
        labels: ["Redemption URL"],
        path: "fulfillment.redeemUrl",
        control: "url",
        format: "url",
        step: "redemption",
        phase: "draft",
        notes: "Codes deals. Where a buyer redeems a code."
      },
      {
        id: "webhookUrl",
        labels: ["Webhook URL"],
        path: "fulfillment.webhookUrl",
        control: "url",
        format: "url",
        step: "redemption",
        phase: "draft",
        notes: "Licensing deals. Public https URL that accepts the license event JSON. The private key is never a field here."
      },
      {
        id: "redirectUrl",
        labels: ["Redirect URL"],
        path: "fulfillment.redirectUrl",
        control: "url",
        format: "url",
        step: "redemption",
        phase: "draft",
        notes: "Licensing deals. Where buyers land after granting license access."
      },
      {
        id: "submitForReview",
        labels: ["Submit for review"],
        path: "attestations.submitForReview",
        control: "button",
        pick: "last",
        step: "submit",
        phase: "commit"
      }
    ]
  };

  // schemas/schema_facebook.json
  var schema_facebook_default = {
    id: "facebook",
    version: "2026-11-25",
    title: "Facebook Business Page setup",
    offer: {
      name: "Facebook Business Page Setup Sprint",
      priceUsd: 15,
      promise: "Your Business Page details, drafted into the Facebook setup and settings forms you already have open. You read the plan in the side panel and click Approve & Commit before anything is created, saved, or posted."
    },
    sources: [
      {
        title: "Facebook Help Center",
        url: "https://www.facebook.com/help/"
      },
      {
        title: "Meta Business Help Center",
        url: "https://www.facebook.com/business/help"
      }
    ],
    rules: {
      status: "Phase 5 (2026-11-25) verified the Business Dashboard, the /post/create composer, the Page About editors (Intro bio, Category, Links, Contact info, Details address), and the Add action button dialog against a logged-in Business Page; see docs/research/facebook-dom.md and test/fixtures/facebook/. The Page creation view (/pages/creation/) was verified from the personal profile the same day; it refuses while acting as a Page. Hours stay unverified: Facebook locks them until an address is saved.",
      binding: "Controls are found by visible label, aria-label, or placeholder. Facebook does not publish input names and its class names change, so the shim never depends on either.",
      scope: `Business Pages only. Outside the Page creation view, the page must name the pack's Page (as a heading, the dashboard greeting "Hi <Page>", or the composer prompt "What's on your mind, <Page>?") and show at least one Page-admin signal, or the plan refuses with no actions.`,
      commit: "Create Page, Save, the action-button Save, and Post are commit actions. They run only after Approve & Commit for this exact plan hash.",
      media: "Profile picture and cover photo are attached by the person. The shim tracks them as a checklist and, when the pack marks one required, blocks commit until the file input has a file.",
      secrets: "Packs never carry passwords, two-factor codes, or access tokens. A sign-in page is refused.",
      pageSignals: ["Business Dashboard", "Manage Page", "Professional dashboard", "Meta Business Suite", "Edit Page", "Page settings", "Ad Center", "Boost post", "Switch into Page", "Insights"],
      createPaths: ["/pages/create", "/pages/creation"],
      hoursModes: ["No hours available", "Always open", "Open on selected hours"],
      tiers: {
        essentials: {
          name: "Facebook Business Page Setup Sprint: Essentials",
          priceUsd: 5,
          promise: "Page name, category, bio, and the main contact details, drafted into the Page form you have open. Nothing is created or saved until you click Approve & Commit.",
          fields: ["pageName", "categories", "bio", "website", "phone", "email", "profilePicture", "coverPhoto", "createPage", "saveChanges"]
        },
        standard: {
          name: "Facebook Business Page Setup Sprint: Standard Business",
          priceUsd: 15,
          promise: "Everything in Essentials plus address, hours, and the action button, drafted into the Page forms you have open. Nothing is saved until you click Approve & Commit.",
          fields: ["pageName", "categories", "bio", "website", "phone", "email", "address", "city", "zip", "hoursMode", "ctaType", "ctaUrl", "ctaSave", "profilePicture", "coverPhoto", "createPage", "saveChanges"]
        },
        launch: {
          name: "Facebook Business Page Setup Sprint: Full Launch + Post",
          priceUsd: 50,
          promise: "Everything in Standard Business plus a launch post drafted into the Page composer. Nothing is saved or posted until you click Approve & Commit.",
          fields: ["pageName", "categories", "bio", "website", "phone", "email", "address", "city", "zip", "hoursMode", "ctaType", "ctaUrl", "ctaSave", "launchPost", "publishPost", "profilePicture", "coverPhoto", "createPage", "saveChanges"]
        }
      }
    },
    fields: [
      {
        id: "pageName",
        labels: ["Page name", "Page name (required)", "Name of your Page"],
        path: "page.name",
        control: "text",
        required: true,
        maxLength: 75,
        step: "create",
        phase: "draft",
        notes: 'Verified at /pages/creation/: a <label> "Page name" wrapping input[type=text] inside role=form "Pages". No maxlength attribute, so the 75 cap stays unverified. Facebook reviews name changes on existing Pages.'
      },
      {
        id: "categories",
        labels: ["Categories", "Search category", "Category", "Category (required)"],
        path: "page.categories",
        control: "tokens",
        taxonomy: true,
        required: true,
        minItems: 1,
        maxItems: 3,
        step: "create",
        phase: "draft",
        notes: 'Verified: input[role=combobox][aria-label=Categories] with aria-controls to a role=listbox of role=option rows; chips sit in span[role=list][aria-label="Selected values"] with "Remove <name>" buttons; the editor counts "n/3 categories". Each value must be an option Facebook lists; the shim clicks it and never invents one. On /pages/creation/ the same combobox is labelled "Search category" (one category, plus two extra), beside "Popular categories" buttons.'
      },
      {
        id: "bio",
        labels: ["Introduce yourself", "Bio", "Bio (optional)", "Intro"],
        path: "page.bio",
        control: "textarea",
        maxLength: 255,
        step: "create",
        phase: "draft",
        notes: `Verified on About > Intro > Edit bio: a <label> "Introduce yourself" wrapping <textarea maxlength=255>. Any view's own maxlength still tightens the cap when lower. The /pages/creation/ step has no bio field; the bio is set afterwards in the About editor.`
      },
      {
        id: "website",
        labels: ["Website", "Website URL", "Link"],
        path: "contact.website",
        control: "url",
        format: "url",
        step: "contact",
        phase: "draft",
        notes: 'Verified: About > Links > "Websites, blogs, portfolios" opens a <label> "Link" wrapping input[type=text], beside "Link description" (maxlength 150) and an "Add link" button.'
      },
      {
        id: "phone",
        labels: ["Phone number", "Phone"],
        path: "contact.phone",
        control: "text",
        pattern: "^\\+?[0-9][0-9 ().-]{5,22}$",
        step: "contact",
        phase: "draft",
        notes: `Verified: <label> "Phone number" wrapping input[type=text], next to a separate country-code menu button (aria-label "Country code, US+1"). When the pack number starts with the picker's code, the shim drops the code and says so in the plan.`
      },
      {
        id: "email",
        labels: ["Email", "Email address"],
        path: "contact.email",
        control: "email",
        format: "email",
        step: "contact",
        phase: "draft",
        notes: 'Verified: <label> "Email" wrapping input[type=text] (not type=email).'
      },
      {
        id: "address",
        labels: ["Address", "Street address"],
        path: "contact.address",
        control: "text",
        maxLength: 200,
        step: "location",
        phase: "draft",
        notes: 'Verified: <label> "Address" wrapping input[type=text] in About > Details > Address. Hours stay locked until an address is saved.'
      },
      {
        id: "city",
        labels: ["City/Town", "City"],
        path: "contact.city",
        control: "text",
        step: "location",
        phase: "draft",
        notes: "Verified: City/Town is input[role=combobox][type=search], a typeahead that only counts a picked suggestion. The shim never types into it; the city is listed for the person to pick."
      },
      {
        id: "zip",
        labels: ["ZIP code", "Postal code", "ZIP"],
        path: "contact.zip",
        control: "text",
        maxLength: 12,
        step: "location",
        phase: "draft",
        notes: 'Verified: <label> "ZIP" wrapping input[type=text][maxlength=12].'
      },
      {
        id: "hoursMode",
        labels: ["Hours", "Business hours"],
        path: "hours.mode",
        control: "choice",
        step: "hours",
        phase: "draft",
        notes: "Radio group. Per-day opening times stay manual in v1 and are listed in the preview."
      },
      {
        id: "ctaType",
        labels: ["Choose an option", "Choose a button", "Which button do you want people to see?"],
        within: ["Action button", "Add action button", "Edit action button", "Add button"],
        path: "cta.type",
        control: "choice",
        step: "cta",
        phase: "draft",
        notes: 'Verified: profile "..." menu > Add action button > Try It opens the dialog "Action button" with 15 div[role=radio] rows (title plus description), each holding an inner role=radio aria-labelledby its title: Book now, Sign up, Start order, Get tickets, Send message, Send WhatsApp message, Call now, Send email, Contact us, Learn more, Watch now, Visit group, Play game, Buy now, Reserve. It is a two-step wizard: the person clicks Next, and Page Push re-plans the link step.'
      },
      {
        id: "ctaUrl",
        labels: ["Add website link", "Website", "Website URL", "Link"],
        within: ["Action button", "Add action button", "Edit action button", "Add button"],
        path: "cta.url",
        control: "url",
        format: "url",
        step: "cta",
        phase: "draft",
        notes: 'Verified: step two of the Action button dialog is a <label> "Add website link" wrapping input[type=text]; Save stays aria-disabled until it has a value.'
      },
      {
        id: "ctaSave",
        labels: ["Save"],
        within: ["Action button", "Add action button", "Edit action button", "Add button"],
        path: "commit.saveActionButton",
        control: "button",
        step: "cta",
        phase: "commit"
      },
      {
        id: "launchPost",
        labels: ["What's on your mind?", "Create a public post…", "Write something..."],
        within: ["Create post"],
        path: "launchPost.text",
        control: "textarea",
        maxLength: 63206,
        step: "post",
        phase: "draft",
        notes: `Verified at /post/create: div[role=textbox][contenteditable][data-lexical-editor] labelled "What's on your mind, <Page name>?" (the shim adds that label from the pack) inside role=form "Posts", in a role=main region whose title text is "Create post" (no heading element). No maxlength attribute, so the cap stays Facebook's published limit. Written through the browser input pipeline, never by setting DOM text.`
      },
      {
        id: "publishPost",
        labels: ["Post"],
        within: ["Create post"],
        path: "commit.publishLaunchPost",
        control: "button",
        step: "post",
        phase: "commit",
        notes: "Verified: div[role=button][aria-label=Post], aria-disabled until the composer has text; commit waits for it to enable. The Boost post and Add AI label switches beside it are never touched."
      },
      {
        id: "profilePicture",
        labels: ["Add profile picture", "Profile picture"],
        path: "media.profilePicture",
        control: "file",
        step: "customize",
        phase: "draft"
      },
      {
        id: "coverPhoto",
        labels: ["Add cover photo", "Cover photo"],
        path: "media.coverPhoto",
        control: "file",
        step: "customize",
        phase: "draft"
      },
      {
        id: "createPage",
        labels: ["Create a Page", "Create Page"],
        path: "commit.createPage",
        control: "button",
        step: "create",
        phase: "commit",
        notes: 'Verified: div[role=button][aria-label="Create a Page"], aria-disabled until the name and a category are set; commit waits for it to enable.'
      },
      {
        id: "saveChanges",
        labels: ["Save", "Save changes"],
        path: "commit.saveChanges",
        control: "button",
        pick: "last",
        step: "contact",
        phase: "commit",
        notes: "Verified: each About editor ends in div[role=button][aria-label=Save], aria-disabled until something changed, beside Cancel."
      }
    ]
  };

  // src/schema.ts
  var appsumoSchema = schema_appsumo_default;
  var facebookSchema = schema_facebook_default;

  // src/shims/facebook.ts
  var SECRET_KEY = /^(pass(word)?|passcode|token|access[_-]?token|secret|otp|2fa|two[_-]?factor|cookie|session)$/i;
  var SECRET_VALUE = /private key|begin [a-z ]*private|EAA[A-Za-z0-9]{20,}|sk_live_|api[_ -]?key|password\s*[:=]/i;
  function facebookTiers(schema = facebookSchema) {
    return schema.rules?.tiers ?? {};
  }
  function tierOffer(tier) {
    const rule = facebookTiers()[tier];
    return rule ? { name: rule.name, priceUsd: rule.priceUsd, promise: rule.promise } : null;
  }
  function prepareFacebookPack(pack) {
    const issues = [];
    const next = structuredClone(pack);
    const rule = facebookTiers()[next.tier];
    if (!rule) {
      issues.push(issue("error", "tier", "tier", `Unknown tier "${String(next.tier)}". Use essentials, standard, or launch.`));
    }
    next.page.name = (next.page.name ?? "").trim();
    next.page.categories = dedupe((next.page.categories ?? []).map((item) => item.trim()).filter(Boolean));
    if (next.page.bio != null) next.page.bio = next.page.bio.trim();
    if (next.contact) {
      for (const key of Object.keys(next.contact)) {
        const value = next.contact[key];
        if (typeof value === "string") next.contact[key] = value.trim();
      }
    }
    if (next.hours && (typeof next.hours.mode !== "string" || !next.hours.mode.trim())) delete next.hours;
    else if (next.hours) next.hours.mode = next.hours.mode.trim();
    if (next.cta) {
      next.cta.type = next.cta.type.trim();
      if (next.cta.url != null) next.cta.url = next.cta.url.trim();
    }
    if (next.launchPost) next.launchPost.text = next.launchPost.text.trim();
    next.commit = {
      createPage: next.commit?.createPage ?? true,
      saveChanges: next.commit?.saveChanges ?? true,
      saveActionButton: next.commit?.saveActionButton ?? Boolean(next.cta?.type),
      publishLaunchPost: next.commit?.publishLaunchPost ?? Boolean(next.launchPost?.text)
    };
    if (rule) {
      for (const field of facebookSchema.fields) {
        if (rule.fields.includes(field.id)) continue;
        const value = getPath(next, field.path);
        if (isBlank(value) || value === false) continue;
        unsetPath(next, field.path);
        if (field.phase === "commit") continue;
        issues.push(issue(
          "warning",
          field.id,
          "out-of-tier",
          `${field.labels[0]} is not part of the ${rule.name.split(": ").pop()} tier and was left out.`
        ));
      }
    }
    return { pack: next, issues };
  }
  function assessFacebook(pack) {
    const issues = [];
    for (const path of secretPaths(pack)) {
      issues.push(issue("error", path, "secret", `The pack holds something that looks like a credential at ${path}. Remove it; do not enter sign-in details in a pack.`));
    }
    if (!pack.page?.name?.trim()) issues.push(issue("error", "pageName", "required", "The pack needs the Page name."));
    const categories = asStringList(pack.page?.categories) ?? [];
    if (!categories.length) issues.push(issue("error", "categories", "required", "The pack needs at least one Page category."));
    const modes = facebookSchema.rules?.hoursModes ?? [];
    const hoursMode = typeof pack.hours?.mode === "string" ? pack.hours.mode.trim() : "";
    if (hoursMode && !modes.some((mode) => labelKey(mode) === labelKey(hoursMode))) {
      issues.push(issue("error", "hoursMode", "enum", `Hours must be one of: ${modes.join(", ")}.`));
    }
    if (pack.hours?.schedule && labelKey(hoursMode) !== labelKey("Open on selected hours")) {
      issues.push(issue("warning", "hoursMode", "schedule-ignored", 'Opening times only apply to "Open on selected hours".'));
    }
    if (pack.cta && !pack.cta.url && !/call|message|email/i.test(pack.cta.type)) {
      issues.push(issue("warning", "ctaUrl", "cta-url", `The "${pack.cta.type}" button usually needs a link.`));
    }
    return issues;
  }
  function facebookContext(pageUrl) {
    let url;
    try {
      url = new URL(pageUrl);
    } catch {
      return "off-site";
    }
    const host = url.hostname.toLowerCase();
    if (url.protocol !== "https:" || !(host === "facebook.com" || host.endsWith(".facebook.com"))) return "off-site";
    const createPaths = facebookSchema.rules?.createPaths ?? [];
    return createPaths.some((path) => url.pathname === path || url.pathname.startsWith(`${path}/`)) ? "create" : "page";
  }
  function secretPaths(value, path = "") {
    if (typeof value === "string") return SECRET_VALUE.test(value) ? [path || "pack"] : [];
    if (Array.isArray(value)) return value.flatMap((item, index) => secretPaths(item, `${path}[${index}]`));
    if (!value || typeof value !== "object") return [];
    return Object.entries(value).flatMap(([key, item]) => {
      const next = path ? `${path}.${key}` : key;
      return SECRET_KEY.test(key) ? [next] : secretPaths(item, next);
    });
  }
  function unsetPath(root, path) {
    const keys = path.split(".");
    const last = keys.pop();
    let current = root;
    for (const key of keys) {
      if (current == null || typeof current !== "object") return;
      current = current[key];
    }
    if (last && current && typeof current === "object") delete current[last];
  }

  // src/draft/copy.ts
  function banned() {
    return appsumoSchema.rules?.voice?.banned ?? [];
  }
  function acceptField(platform, facts, field, candidate) {
    if (field.items) {
      if (!Array.isArray(candidate) || candidate.length !== field.items || candidate.some((item) => typeof item !== "string")) {
        return { ok: false, reason: "shape" };
      }
      const cap = field.itemMaxLength ?? field.maxLength;
      const items = candidate.map((item) => clipWords(item, cap));
      for (const item of items) {
        const reason2 = rejectText(platform, facts, item, 1, cap, field.minWords);
        if (reason2) return { ok: false, reason: reason2 };
      }
      return { ok: true, value: items };
    }
    if (typeof candidate !== "string") return { ok: false, reason: "shape" };
    const text = clipWords(candidate, field.maxLength);
    const reason = rejectText(platform, facts, text, field.minLength ?? 1, field.maxLength, field.minWords);
    if (reason) return { ok: false, reason };
    return { ok: true, value: text };
  }
  function rejectText(platform, facts, text, minLength, maxLength, minWords) {
    if (!text.trim()) return "empty";
    if (charLength(text) < minLength || charLength(text) > maxLength) return "length";
    if (minWords != null && wordCount(text) < minWords) return "words";
    const leak = leaked(text, facts);
    if (leak) return leak;
    if (ungrounded(text, facts, platform === "facebook" ? FACEBOOK_VOCABULARY : void 0)) return "grounding";
    if (platform === "appsumo") {
      if (text.includes("—") || text.includes("!") || new RegExp("\\p{Extended_Pictographic}", "u").test(text)) return "voice";
      for (const word of banned()) {
        if (new RegExp(`\\b${word}\\b`, "i").test(text)) return "voice";
      }
    }
    return null;
  }
  var STOP_WORDS = /* @__PURE__ */ new Set([
    "a",
    "an",
    "the",
    "and",
    "or",
    "for",
    "to",
    "of",
    "in",
    "on",
    "with",
    "before",
    "after",
    "from",
    "by",
    "at",
    "is",
    "are",
    "it",
    "its",
    "as",
    "that",
    "this",
    "these",
    "those"
  ]);
  function contentWords(text) {
    return text.toLowerCase().split(/[^a-z0-9]+/).filter((word) => word.length > 2 && !STOP_WORDS.has(word));
  }
  var FACEBOOK_VOCABULARY = [
    "welcome",
    "official",
    "page",
    "follow",
    "visit",
    "learn",
    "more",
    "now",
    "open",
    "today",
    "here",
    "news",
    "updates",
    "contact",
    "message",
    "call",
    "book",
    "see",
    "find",
    "get",
    "touch",
    "hello",
    "launch",
    "launching",
    "glad",
    "thanks",
    "you",
    "your",
    "our",
    "can",
    "will",
    "what",
    "how",
    "who",
    "why",
    "about",
    "new",
    "soon",
    "back",
    "every",
    "week",
    "questions",
    "help",
    "helps"
  ];
  function ungrounded(text, facts, extra) {
    const allowed = /* @__PURE__ */ new Set([...contentWords(facts), ...extra ?? []]);
    const used = contentWords(text);
    return used.length === 0 || used.some((word) => !allowed.has(word));
  }
  function leaked(text, facts) {
    for (const url of text.match(/https?:\/\/[^\s)"']+/g) ?? []) {
      if (!facts.includes(url.replace(/[.,]$/, ""))) return "url";
    }
    for (const email of text.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi) ?? []) {
      if (!facts.toLowerCase().includes(email.toLowerCase())) return "email";
    }
    for (const date of text.match(/\d{4}-\d{2}-\d{2}/g) ?? []) {
      if (!facts.includes(date)) return "date";
    }
    for (const money of text.match(/\$\s?\d[\d,]*/g) ?? []) {
      const digits = money.replace(/[^\d]/g, "");
      if (!facts.includes(digits)) return "price";
    }
    return null;
  }
  function clipWords(value, max) {
    const flat = value.replace(/\s+/g, " ").trim();
    if (charLength(flat) <= max) return flat;
    const cut = Array.from(flat).slice(0, max).join("");
    const boundary = cut.lastIndexOf(" ");
    return (boundary > 0 ? cut.slice(0, boundary) : cut).trim();
  }
  function extractObject(text) {
    const start2 = text.indexOf("{");
    if (start2 < 0) return null;
    let depth = 0;
    let inString = false;
    let escape = false;
    for (let index = start2; index < text.length; index += 1) {
      const ch = text[index];
      if (inString) {
        if (escape) escape = false;
        else if (ch === "\\") escape = true;
        else if (ch === '"') inString = false;
        continue;
      }
      if (ch === '"') inString = true;
      else if (ch === "{") depth += 1;
      else if (ch === "}") {
        depth -= 1;
        if (depth === 0) {
          try {
            const parsed = JSON.parse(text.slice(start2, index + 1));
            if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) return parsed;
          } catch {
            return null;
          }
        }
      }
    }
    return null;
  }

  // src/draft/facebook-copy.ts
  var LAUNCH_POST_DRAFT_MAX = 600;
  function bioLimit() {
    return facebookSchema.fields.find((field) => field.id === "bio")?.maxLength ?? 255;
  }
  function facebookCopyFields(pack) {
    const fields = [{ id: "bio", maxLength: bioLimit(), minLength: 20 }];
    if (pack.tier === "launch") fields.push({ id: "launchPost", maxLength: LAUNCH_POST_DRAFT_MAX, minLength: 40 });
    return fields;
  }
  function facebookFacts(pack) {
    const lines = [];
    const add = (label, value) => {
      const text = value?.replace(/\s+/g, " ").trim();
      if (text) lines.push(`${label}: ${text}`);
    };
    add("Page name", pack.page?.name);
    add("Categories", (pack.page?.categories ?? []).filter(Boolean).join(", "));
    add("About", pack.page?.bio);
    add("Launch notes", pack.launchPost?.text);
    add("Website", pack.contact?.website);
    add("City", pack.contact?.city);
    if (pack.cta?.type) add("Action button", [pack.cta.type, pack.cta.url].filter(Boolean).join(" "));
    add("Hours", pack.hours?.mode);
    return lines.join("\n");
  }
  function offlineFacebookCopy(pack) {
    const name = pack.page?.name?.trim() ?? "";
    const categories = (pack.page?.categories ?? []).map((item) => item.trim()).filter(Boolean);
    const city = pack.contact?.city?.trim();
    const website = pack.contact?.website?.trim();
    let bio = pack.page?.bio?.trim();
    if (!bio && name) {
      const what = categories.length ? `: ${joinList(categories)}` : "";
      const where = city ? ` in ${city}` : "";
      bio = `${name}${what}${where}.${website ? ` ${website}` : ""}`;
    }
    const out = {};
    if (bio) out.bio = clipWords2(bio, bioLimit());
    if (pack.tier === "launch") {
      let post = pack.launchPost?.text?.trim();
      if (!post && name) {
        const link = pack.cta?.url?.trim() || website;
        const action = pack.cta?.type?.trim();
        const parts = [`${name} is now on Facebook.`];
        if (out.bio && out.bio !== name) parts.push(out.bio);
        if (link) parts.push(action ? `${action}: ${link}` : link);
        post = parts.join("\n\n");
      }
      if (post) out.launchPost = clipParagraphs(post, LAUNCH_POST_DRAFT_MAX);
    }
    return out;
  }
  async function draftFacebookCopy(pack, runner) {
    const offline = offlineFacebookCopy(pack);
    const issues = [];
    const trace = [];
    const fields = facebookCopyFields(pack);
    const facts = facebookFacts(pack);
    if (!runner) return { source: "offline", ...offline, issues, trace };
    if (!pack.page?.name?.trim()) {
      issues.push(issue("warning", "pageName", "facts", "Add the Page name before drafting with the local model. The offline draft is shown instead."));
      return { source: "offline", ...offline, issues, trace };
    }
    if (assessFacebook(pack).some((item) => item.code === "secret")) {
      issues.push(issue("error", "pack", "secret", "The pack holds something that looks like a credential. Nothing was sent to the local model."));
      trace.push({ phase: "model", code: "secret" });
      return { source: "offline", ...offline, issues, trace };
    }
    let text = "";
    try {
      const result = await runner.complete({ system: systemPrompt(), user: userPrompt(facts, fields), maxTokens: 160 + fields.length * 220 });
      if (result.ok) {
        text = result.text;
        trace.push({ phase: "model", code: "answered" });
      } else {
        issues.push(issue("warning", "model", result.code, `${result.message} Drafted from the pack facts instead.`));
        trace.push({ phase: "model", code: result.code });
      }
    } catch {
      issues.push(issue("warning", "model", "runtime", "The local model did not answer. Drafted from the pack facts instead."));
      trace.push({ phase: "model", code: "runtime" });
    }
    const parsed = text ? extractObject(text) : null;
    if (text && !parsed) {
      issues.push(issue("warning", "model", "protocol", "The local model did not return JSON. Drafted from the pack facts instead."));
      trace.push({ phase: "model", code: "protocol" });
    }
    const out = { source: "offline", issues, trace };
    let fromModel = 0;
    let fromFacts = 0;
    for (const field of fields) {
      const key = field.id;
      const candidate = parsed?.[key];
      const accepted = candidate === void 0 ? null : acceptField("facebook", facts, field, normalizeParagraphs(candidate));
      if (accepted?.ok && typeof accepted.value === "string") {
        out[key] = key === "launchPost" ? restoreParagraphs(candidate, accepted.value) : accepted.value;
        fromModel += 1;
        trace.push({ phase: "model", code: "accepted", fieldId: key });
        continue;
      }
      if (accepted && !accepted.ok) {
        issues.push(issue("warning", key, "model-rejected", `The local model's ${key === "bio" ? "bio" : "launch post"} was set aside (${accepted.reason}); the offline draft is shown.`));
        trace.push({ phase: "model", code: "rejected", fieldId: key });
      }
      if (offline[key]) {
        out[key] = offline[key];
        fromFacts += 1;
        trace.push({ phase: "model", code: "fallback", fieldId: key });
      }
    }
    out.source = fromModel > 0 && fromFacts > 0 ? "mixed" : fromModel > 0 ? "ollama" : "offline";
    return out;
  }
  function systemPrompt() {
    return [
      "You write Facebook Business Page copy that a person reads and edits before anything is posted.",
      "Reply with one JSON object and no markdown.",
      "Use only the facts. Do not add cities, dates, prices, emails, URLs, awards, or services that are not written in the facts.",
      "Plain, friendly, specific. No hashtags, no emoji, no em dash."
    ].join(" ");
  }
  function userPrompt(facts, fields) {
    const lines = fields.map((field) => field.id === "bio" ? `- bio: one string, ${field.minLength} to ${field.maxLength} characters, for the Page's Intro` : `- launchPost: one string, ${field.minLength} to ${field.maxLength} characters, the Page's first post; short paragraphs separated by a blank line`);
    return `Facts (the only source of names, places, and links):
${facts}

Return a JSON object with these keys:
${lines.join("\n")}`;
  }
  function normalizeParagraphs(candidate) {
    return typeof candidate === "string" ? candidate.replace(/\s+/g, " ").trim() : candidate;
  }
  function restoreParagraphs(original, accepted) {
    const paragraphs = original.split(/\n\s*\n/).map((part) => part.replace(/\s+/g, " ").trim()).filter(Boolean).join("\n\n");
    return charLength(paragraphs) <= LAUNCH_POST_DRAFT_MAX && paragraphs.replace(/\s+/g, " ") === accepted ? paragraphs : accepted;
  }
  function joinList(items) {
    if (items.length <= 1) return items.join("");
    return `${items.slice(0, -1).join(", ")} and ${items[items.length - 1]}`;
  }
  function clipWords2(value, max) {
    const flat = value.replace(/\s+/g, " ").trim();
    if (charLength(flat) <= max) return flat;
    const cut = Array.from(flat).slice(0, max).join("");
    const boundary = cut.lastIndexOf(" ");
    return (boundary > 0 ? cut.slice(0, boundary) : cut).trim();
  }
  function clipParagraphs(value, max) {
    const kept = [];
    for (const paragraph of value.split(/\n\s*\n/).map((part) => part.trim()).filter(Boolean)) {
      const next = [...kept, paragraph].join("\n\n");
      if (charLength(next) <= max) {
        kept.push(paragraph);
        continue;
      }
      if (!kept.length) kept.push(clipWords2(paragraph, max));
      break;
    }
    return kept.join("\n\n");
  }

  // src/draft/ollama.ts
  var OLLAMA_URL = "http://localhost:11434";
  var DEFAULT_OLLAMA_MODEL = "qwen3";
  var OLLAMA_ORIGINS_HELP = 'Ollama refused this extension (HTTP 403). On Windows run: setx OLLAMA_ORIGINS "chrome-extension://*" , then quit Ollama from the tray and start it again.';
  function modelMatches(installed, wanted) {
    const want = wanted.trim().toLowerCase();
    const have = installed.trim().toLowerCase();
    if (!want) return false;
    if (want.includes(":")) return have === want;
    return have === want || have.startsWith(`${want}:`);
  }
  async function ollamaStatus(model, options) {
    const base = options.baseUrl ?? OLLAMA_URL;
    const version = await call(options, `${base}/api/version`, { method: "GET" }, options.timeoutMs ?? 4e3);
    if (!version.ok) return version;
    const tags = await call(options, `${base}/api/tags`, { method: "GET" }, options.timeoutMs ?? 4e3);
    if (!tags.ok) return tags;
    const models = Array.isArray(tags.json.models) ? tags.json.models.map((entry) => String(entry.name ?? entry.model ?? "")).filter(Boolean) : [];
    const match = models.find((name) => modelMatches(name, model)) ?? null;
    return { ok: true, version: String(version.json.version ?? "unknown"), models, match };
  }
  async function pullModel(model, options) {
    const base = options.baseUrl ?? OLLAMA_URL;
    let response;
    try {
      response = await options.fetch(`${base}/api/pull`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model, stream: true }),
        signal: options.signal
      });
    } catch (error) {
      return failureFrom(error);
    }
    if (!response.ok) return httpFailure(response.status, await safeText(response));
    let last = null;
    const handle = (line) => {
      if (!line.trim()) return null;
      let parsed;
      try {
        parsed = JSON.parse(line);
      } catch {
        return null;
      }
      if (parsed.error) return { ok: false, code: "http", message: String(parsed.error) };
      last = {
        status: String(parsed.status ?? ""),
        completed: typeof parsed.completed === "number" ? parsed.completed : void 0,
        total: typeof parsed.total === "number" ? parsed.total : void 0
      };
      options.onProgress?.(last);
      return null;
    };
    try {
      if (response.body && typeof response.body.getReader === "function") {
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        for (; ; ) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          let newline = buffer.indexOf("\n");
          while (newline >= 0) {
            const failed2 = handle(buffer.slice(0, newline));
            if (failed2) return failed2;
            buffer = buffer.slice(newline + 1);
            newline = buffer.indexOf("\n");
          }
        }
        const failed = handle(buffer);
        if (failed) return failed;
      } else {
        for (const line of (await response.text()).split("\n")) {
          const failed = handle(line);
          if (failed) return failed;
        }
      }
    } catch (error) {
      return failureFrom(error);
    }
    const final = last;
    return final?.status === "success" ? { ok: true } : { ok: false, code: "protocol", message: "Ollama ended the download without reporting success." };
  }
  async function warmModel(model, options) {
    const base = options.baseUrl ?? OLLAMA_URL;
    const result = await call(options, `${base}/api/generate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ model, prompt: "", stream: false, keep_alive: options.keepAlive ?? "10m" })
    }, options.timeoutMs ?? 12e4);
    return result.ok ? { ok: true } : result;
  }
  async function checkAndLoad(model, options) {
    options.onStep?.("checking");
    const status = await ollamaStatus(model, options);
    if (!status.ok) return status;
    let current = status;
    if (!current.match) {
      options.onStep?.("pulling", model);
      const pulled = await pullModel(model, options);
      if (!pulled.ok) return pulled;
      const after = await ollamaStatus(model, options);
      if (!after.ok) return after;
      current = after.match ? after : { ...after, match: model };
    }
    options.onStep?.("warming", current.match ?? model);
    const warmed = await warmModel(current.match ?? model, options);
    if (!warmed.ok) return warmed;
    options.onStep?.("ready", current.match ?? model);
    return current;
  }
  function ollamaRunner(model, options) {
    const base = options.baseUrl ?? OLLAMA_URL;
    return {
      async complete(input) {
        const result = await call(options, `${base}/api/chat`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            model,
            stream: false,
            format: "json",
            think: false,
            messages: [
              { role: "system", content: input.system },
              { role: "user", content: input.user }
            ],
            options: { temperature: 0.2, num_predict: input.maxTokens }
          })
        }, options.draftTimeoutMs ?? 9e4);
        if (!result.ok) {
          return { ok: false, code: result.code === "timeout" ? "timeout" : result.code === "protocol" ? "protocol" : "runtime", message: result.message };
        }
        const content = result.json.message?.content;
        if (typeof content !== "string") return { ok: false, code: "protocol", message: "Ollama answered without message content." };
        return { ok: true, text: content.replace(/<think>[\s\S]*?<\/think>/g, "").trim() };
      }
    };
  }
  async function call(options, url, init, timeoutMs) {
    const controller = typeof AbortController === "function" ? new AbortController() : null;
    const timer = controller ? setTimeout(() => controller.abort(), timeoutMs) : null;
    try {
      const response = await options.fetch(url, { ...init, signal: controller?.signal });
      if (!response.ok) return httpFailure(response.status, await safeText(response));
      try {
        return { ok: true, json: await response.json() };
      } catch {
        return { ok: false, code: "protocol", message: "Ollama answered with something that is not JSON." };
      }
    } catch (error) {
      return failureFrom(error);
    } finally {
      if (timer) clearTimeout(timer);
    }
  }
  function httpFailure(status, body) {
    if (status === 403) return { ok: false, code: "forbidden", message: OLLAMA_ORIGINS_HELP };
    const detail = body.trim().slice(0, 200);
    return { ok: false, code: "http", message: `Ollama answered HTTP ${status}${detail ? `: ${detail}` : ""}.` };
  }
  function failureFrom(error) {
    if (error?.name === "AbortError") {
      return { ok: false, code: "timeout", message: "Ollama took too long to answer." };
    }
    return { ok: false, code: "unreachable", message: `Ollama is not reachable at ${OLLAMA_URL}. Start Ollama, or keep using the offline draft.` };
  }
  async function safeText(response) {
    try {
      return await response.text();
    } catch {
      return "";
    }
  }

  // src/extension/messages.ts
  function isContentEvent(value) {
    if (!value || typeof value !== "object") return false;
    const type = value.type;
    return type === "pagepush:drift" || type === "pagepush:view-changed";
  }

  // src/extension/packs.ts
  var TIERS = ["essentials", "standard", "launch"];
  var WEEKDAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"];
  var HOURS_MODES = facebookSchema.rules?.hoursModes ?? [];
  var CTA_SUGGESTIONS = [
    "Book now",
    "Contact us",
    "Learn more",
    "Shop now",
    "Sign up",
    "Send message",
    "Call now",
    "Send email",
    "Watch video"
  ];
  function tierFields(tier) {
    return new Set(facebookTiers()[tier]?.fields ?? []);
  }
  function fieldById(id) {
    const field = facebookSchema.fields.find((item) => item.id === id);
    if (!field) throw new Error(`Unknown Facebook field ${id}`);
    return field;
  }
  function starterPack(tier) {
    const pack = {
      tier,
      page: { name: "", categories: [], bio: "" },
      contact: { website: "", phone: "", email: "" },
      media: { profilePicture: "required", coverPhoto: tier === "essentials" ? "optional" : "required" }
    };
    if (tier !== "essentials") {
      pack.contact = { ...pack.contact, address: "", city: "", zip: "" };
      pack.hours = { mode: "" };
      pack.cta = { type: "", url: "" };
    }
    if (tier === "launch") pack.launchPost = { text: "" };
    return pack;
  }
  function setPath(root, path, value) {
    const keys = path.split(".");
    let current = root;
    keys.forEach((key, index) => {
      const last = index === keys.length - 1;
      if (last) {
        current[key] = value;
        return;
      }
      const nextIsIndex = /^\d+$/.test(keys[index + 1]);
      if (current[key] == null || typeof current[key] !== "object") current[key] = nextIsIndex ? [] : {};
      current = current[key];
    });
    return root;
  }
  function readPath(root, path) {
    return getPath(root, path);
  }
  function cleanPack(pack) {
    const walk = (value) => {
      if (typeof value === "string") {
        const trimmed = value.trim();
        return trimmed === "" ? void 0 : trimmed;
      }
      if (Array.isArray(value)) {
        const items = value.map(walk).filter((item) => item !== void 0);
        return items;
      }
      if (value && typeof value === "object") {
        const out = {};
        for (const [key, item] of Object.entries(value)) {
          const next = walk(item);
          if (next === void 0) continue;
          if (next && typeof next === "object" && !Array.isArray(next) && Object.keys(next).length === 0) continue;
          out[key] = next;
        }
        return out;
      }
      return value;
    };
    const cleaned = walk(structuredClone(pack)) ?? {};
    cleaned.tier = pack.tier;
    cleaned.page = { ...cleaned.page ?? { name: "" }, categories: cleaned.page?.categories ?? [] };
    if (cleaned.page.name == null) cleaned.page.name = "";
    if (Array.isArray(cleaned.launchPost)) delete cleaned.launchPost;
    return cleaned;
  }
  function packFingerprint(pack) {
    return sha256(cleanPack(pack));
  }
  var KNOWN = {
    "": ["tier", "page", "contact", "hours", "cta", "launchPost", "media", "commit"],
    page: ["name", "categories", "bio"],
    contact: ["website", "phone", "email", "address", "city", "zip"],
    hours: ["mode", "schedule"],
    "hours.schedule": WEEKDAYS,
    cta: ["type", "url"],
    launchPost: ["text"],
    media: ["profilePicture", "coverPhoto"],
    commit: ["createPage", "saveChanges", "saveActionButton", "publishLaunchPost"]
  };
  function checkPack(input) {
    const errors = [];
    const warnings = [];
    const err = (fieldId, code, message) => {
      errors.push({ level: "error", fieldId, code, message });
    };
    if (!input || typeof input !== "object" || Array.isArray(input)) {
      err("pack", "shape", "A pack is a JSON object.");
      return { pack: null, errors, warnings };
    }
    const raw = input;
    for (const [scope, keys] of Object.entries(KNOWN)) {
      const node = scope ? getPath(raw, scope) : raw;
      if (!node || typeof node !== "object" || Array.isArray(node)) continue;
      for (const key of Object.keys(node)) {
        if (!keys.includes(key)) {
          warnings.push({ level: "warning", fieldId: scope ? `${scope}.${key}` : key, code: "unknown-key", message: `"${scope ? `${scope}.` : ""}${key}" is not a Page Push field and is ignored.` });
        }
      }
    }
    if (!TIERS.includes(raw.tier)) err("tier", "tier", "tier must be essentials, standard, or launch.");
    const page = raw.page;
    if (!page || typeof page !== "object") err("page", "shape", "page must be an object with name and categories.");
    if (page && typeof page.name !== "string") err("pageName", "type", "page.name must be text.");
    if (page && !(Array.isArray(page.categories) && page.categories.every((item) => typeof item === "string"))) {
      err("categories", "type", "page.categories must be a list of text.");
    }
    for (const [path, type] of [
      ["page.bio", "string"],
      ["contact", "object"],
      ["hours", "object"],
      ["hours.mode", "string"],
      ["hours.schedule", "object"],
      ["cta", "object"],
      ["cta.type", "string"],
      ["cta.url", "string"],
      ["launchPost", "object"],
      ["launchPost.text", "string"],
      ["media", "object"],
      ["commit", "object"]
    ]) {
      const value = getPath(raw, path);
      if (value !== void 0 && (typeof value !== type || type === "object" && (value === null || Array.isArray(value)))) {
        err(path, "type", `${path} must be ${type === "object" ? "an object" : "text"}.`);
      }
    }
    for (const key of ["profilePicture", "coverPhoto"]) {
      const value = getPath(raw, `media.${key}`);
      if (value !== void 0 && value !== "required" && value !== "optional") err(key, "enum", `media.${key} must be "required" or "optional".`);
    }
    if (errors.length) return { pack: null, errors, warnings };
    const pack = cleanPack(raw);
    for (const field of facebookSchema.fields) {
      if (field.control === "button" || field.control === "file" || field.control === "choice") continue;
      const value = getPath(pack, field.path);
      if (value === void 0 || Array.isArray(value) && value.length === 0) continue;
      for (const problem of validateField(field, value)) (problem.level === "error" ? errors : warnings).push(problem);
    }
    for (const problem of assessFacebook(pack)) {
      if (problem.code === "required" && (problem.fieldId === "pageName" || problem.fieldId === "categories")) {
        errors.push(problem);
        continue;
      }
      (problem.level === "error" ? errors : warnings).push(problem);
    }
    warnings.push(...prepareFacebookPack(pack).issues.filter((item) => item.level === "warning"));
    return { pack, errors: dedupeIssues(errors), warnings: dedupeIssues(warnings) };
  }
  function dedupeIssues(items) {
    const seen = /* @__PURE__ */ new Set();
    return items.filter((item) => {
      const key = `${item.fieldId}|${item.code}|${item.message}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }
  function counters(pack) {
    return [
      ["page.name", "pageName"],
      ["page.bio", "bio"],
      ["launchPost.text", "launchPost"]
    ].map(([path, id]) => {
      const field = fieldById(id);
      const value = getPath(pack, path);
      const used = typeof value === "string" ? charLength(value.trim()) : 0;
      const max = field.maxLength ?? 0;
      return { path, label: field.labels[0], used, max, over: max > 0 && used > max };
    });
  }
  function pasteBlocks(pack) {
    const prepared = prepareFacebookPack(cleanPack(pack)).pack;
    const blocks = [];
    const add = (id, label, lines) => {
      const text = lines.filter((line) => typeof line === "string" && line.trim() !== "").join("\n");
      if (text) blocks.push({ id, label, text });
    };
    add("pageName", "Page name", [prepared.page.name]);
    add("categories", "Categories", [prepared.page.categories.join(", ")]);
    add("bio", "Bio", [prepared.page.bio]);
    const contact = prepared.contact ?? {};
    add("contact", "Contact details", [
      contact.website && `Website: ${contact.website}`,
      contact.phone && `Phone: ${contact.phone}`,
      contact.email && `Email: ${contact.email}`
    ]);
    add("address", "Address", [contact.address, [contact.city, contact.zip].filter(Boolean).join(" ")]);
    if (prepared.hours?.mode) {
      const schedule = prepared.hours.schedule ?? {};
      add("hours", "Hours note", [
        `Hours: ${prepared.hours.mode}`,
        ...WEEKDAYS.filter((day) => schedule[day]?.trim()).map((day) => `${day[0].toUpperCase()}${day.slice(1)}: ${schedule[day].trim()}`)
      ]);
    }
    if (prepared.cta?.type) add("cta", "Action button", [`Button: ${prepared.cta.type}`, prepared.cta.url && `Link: ${prepared.cta.url}`]);
    add("launchPost", "Launch post", [prepared.launchPost?.text]);
    return blocks;
  }

  // src/extension/receipt.ts
  var RECEIPT_FORMAT = "pagepush.sprint-receipt";
  var RECEIPT_VERSION = 1;
  var APPROVAL_STATEMENT = "Each entry records a person clicking Approve & Commit for that plan. Dispatched actions are attempts, not proof Facebook saved or published anything. Check Facebook directly; do not retry blindly. Earlier records may have uncertain ownership.";
  function receiptEntry(input) {
    const { session, pack } = input;
    const plan = session.plan;
    const ref = (id) => ({ id, label: plan.actions.find((action) => action.id === id)?.label ?? id });
    const commitIds = plan.actions.filter((action) => action.phase === "commit").map((action) => action.id);
    const ran = input.outcome === "attempted" || input.outcome === "committed" ? commitIds : (input.committedIds ?? []).filter((id) => commitIds.includes(id));
    const drafted = session.drafted?.applied ?? [];
    const offer = tierOffer(pack.tier);
    return {
      planHash: plan.planHash,
      outcome: input.outcome,
      ...input.refusal ? { refusal: input.refusal } : {},
      tier: pack.tier,
      offer: offer ? { name: offer.name, priceUsd: offer.priceUsd } : null,
      pageUrl: redactUrl(session.url),
      view: facebookContext(session.url),
      approvedAt: input.approvedAt.toISOString(),
      draftedAt: session.drafted?.at ?? null,
      finishedAt: input.finishedAt.toISOString(),
      drafted: drafted.map(ref),
      unconfirmed: (session.drafted?.unconfirmed ?? []).map(ref),
      committed: [],
      attempted: input.outcome === "refused" ? [] : [...drafted.map(ref), ...ran.map(ref)],
      checklist: {
        ...input.checklist,
        profilePictureRequired: pack.media?.profilePicture === "required",
        coverPhotoRequired: pack.media?.coverPhoto === "required"
      }
    };
  }
  function buildSprintReceipt(input) {
    const offer = tierOffer(input.pack.tier);
    const entries = input.entries.map((entry) => ({
      ...entry,
      outcome: entry.outcome === "committed" ? "attempted" : entry.outcome,
      attempted: entry.attempted ?? entry.committed ?? [],
      committed: []
    }));
    const body = {
      format: RECEIPT_FORMAT,
      version: RECEIPT_VERSION,
      extension: { name: "Page Push", version: input.extensionVersion },
      schemaVersion: facebookSchema.version,
      generatedAt: (input.now ?? /* @__PURE__ */ new Date()).toISOString(),
      pageName: input.unattributed ? "" : input.pack.page?.name?.trim() ?? "",
      tier: input.unattributed ? null : input.pack.tier,
      offer: !input.unattributed && offer ? { name: offer.name, priceUsd: offer.priceUsd } : null,
      attribution: input.unattributed ? "unknown-may-be-mixed" : "current-pack",
      approvalStatement: APPROVAL_STATEMENT,
      entries,
      totals: {
        approvals: entries.length,
        committed: 0,
        attempted: entries.filter((entry) => entry.outcome === "attempted").length,
        partial: entries.filter((entry) => entry.outcome === "partial").length,
        refused: entries.filter((entry) => entry.outcome === "refused").length,
        fieldsCommitted: 0,
        fieldsAttempted: new Set(entries.flatMap((entry) => (entry.attempted ?? []).map((field) => field.id))).size
      }
    };
    return { ...body, sha256: sha256(body) };
  }
  function receiptFileName(receipt) {
    const slug = receipt.pageName.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 40) || "page";
    return `pagepush-receipt-${slug}-${receipt.generatedAt.slice(0, 10)}.json`;
  }
  function redactUrl(url) {
    try {
      const parsed = new URL(url);
      const keep = new URLSearchParams();
      for (const key of ["id", "sk"]) {
        const value = parsed.searchParams.get(key);
        if (value) keep.set(key, value);
      }
      const query = keep.toString();
      return `${parsed.origin}${parsed.pathname}${query ? `?${query}` : ""}`;
    } catch {
      return "";
    }
  }

  // src/extension/panel-state.ts
  function initialState() {
    return {
      pack: starterPack("standard"),
      checklist: { reviewedPage: false, profilePicture: false, coverPhoto: false },
      progress: [],
      session: null,
      receipts: [],
      versions: []
    };
  }
  function startSession(state2, tabId, plan, submittedPrint = packFingerprint(state2.pack)) {
    return {
      ...state2,
      checklist: { ...state2.checklist, reviewedPage: false },
      session: { tabId, url: plan.pageUrl, plan, packPrint: submittedPrint, drift: [] }
    };
  }
  function invalidate(state2, reason) {
    if (!state2.session || state2.session.stale || state2.session.committedAt) return state2;
    return { ...state2, session: { ...state2.session, stale: reason } };
  }
  function archiveRecords(state2, unverifiedOwner = false) {
    if (!state2.progress.length && !(state2.receipts ?? []).length) return state2;
    const archive = {
      pageName: unverifiedOwner ? "" : state2.pack.page?.name?.trim() ?? "",
      tier: state2.pack.tier,
      progress: structuredClone(state2.progress),
      receipts: structuredClone(state2.receipts ?? []),
      ...unverifiedOwner ? { unverifiedOwner: true } : {}
    };
    return { ...state2, archives: [...state2.archives ?? [], archive], progress: [], receipts: [] };
  }
  function replacePack(state2, pack) {
    return {
      ...archiveRecords(state2),
      pack,
      session: null,
      checklist: { reviewedPage: false, profilePicture: false, coverPhoto: false }
    };
  }
  function editPack(state2, pack) {
    if ((state2.pack.page?.name ?? "").trim() !== (pack.page?.name ?? "").trim()) {
      return replacePack(state2, pack);
    }
    return { ...state2, pack };
  }
  function recordDraft(state2, result, at = /* @__PURE__ */ new Date()) {
    const session = state2.session;
    if (!session) return state2;
    const stamp = at.toISOString();
    const drafted = session.plan.actions.filter((action) => result.applied.includes(action.id));
    return {
      ...state2,
      checklist: { ...state2.checklist, reviewedPage: false },
      session: { ...session, drafted: { at: stamp, applied: [...result.applied], unconfirmed: [...result.unconfirmed] }, drift: [] },
      progress: mergeProgress(state2.progress, drafted.map((action) => ({
        fieldId: action.id,
        label: action.label,
        status: "drafted",
        url: session.url,
        planHash: session.plan.planHash,
        at: stamp
      })))
    };
  }
  function recordDrift(state2, planHash, fields) {
    const session = state2.session;
    if (!session || session.plan.planHash !== planHash || !fields.length) return state2;
    return { ...state2, session: { ...session, drift: [.../* @__PURE__ */ new Set([...session.drift, ...fields])] } };
  }
  function recordCommit(state2, at = /* @__PURE__ */ new Date(), approvedAt = at) {
    const session = state2.session;
    if (!session) return state2;
    const stamp = at.toISOString();
    const done = session.plan.actions.filter((action) => action.phase === "commit" || session.drafted?.applied.includes(action.id));
    const receipt = receiptEntry({ session, pack: state2.pack, checklist: state2.checklist, approvedAt, finishedAt: at, outcome: "attempted" });
    return {
      ...state2,
      receipts: [...state2.receipts ?? [], receipt],
      session: { ...session, committedAt: stamp },
      progress: mergeProgress(state2.progress, done.map((action) => ({
        fieldId: action.id,
        label: action.label,
        status: "attempted",
        url: session.url,
        planHash: session.plan.planHash,
        at: stamp
      })))
    };
  }
  function recordCommitRefused(state2, input) {
    const session = state2.session;
    if (!session) return state2;
    const at = input.at ?? /* @__PURE__ */ new Date();
    const applied = input.applied ?? [];
    const outcome = applied.length || ["unconfirmed", "unknown-dispatch", "error"].includes(input.code) ? "partial" : "refused";
    const receipt = receiptEntry({
      session,
      pack: state2.pack,
      checklist: state2.checklist,
      approvedAt: input.approvedAt,
      finishedAt: at,
      outcome,
      committedIds: applied,
      refusal: { code: input.code, message: input.message }
    });
    const next = { ...state2, receipts: [...state2.receipts ?? [], receipt] };
    if (outcome === "refused") return next;
    const stamp = at.toISOString();
    const done = session.plan.actions.filter((action) => applied.includes(action.id) || session.drafted?.applied.includes(action.id));
    return invalidate({
      ...next,
      progress: mergeProgress(state2.progress, done.map((action) => ({
        fieldId: action.id,
        label: action.label,
        status: "attempted",
        url: session.url,
        planHash: session.plan.planHash,
        at: stamp
      })))
    }, "Part of this commit ran or may have run. Check Facebook before planning again; do not retry blindly.");
  }
  function mergeProgress(existing, updates) {
    const byField = new Map(existing.map((entry) => [entry.fieldId, entry]));
    for (const entry of updates) {
      const prior = byField.get(entry.fieldId);
      if (prior?.status === "committed" && entry.status === "drafted" && prior.planHash !== entry.planHash) {
        byField.set(entry.fieldId, entry);
        continue;
      }
      if (prior?.status === "committed" && entry.status === "drafted") continue;
      byField.set(entry.fieldId, entry);
    }
    return [...byField.values()];
  }
  function sessionBlocks(state2, context) {
    const session = state2.session;
    if (!session) return ["Plan this view first."];
    const reasons = [];
    if (session.committedAt) reasons.push("This plan was already attempted. Check Facebook before planning another view.");
    if (session.stale) reasons.push(session.stale);
    if (context.activeTabId !== session.tabId) reasons.push("Switch back to the Facebook tab you planned, or plan this tab.");
    if (packFingerprint(state2.pack) !== session.packPrint) reasons.push("The pack changed after planning. Plan again.");
    if (session.plan.errors.length) reasons.push("Fix the plan errors first.");
    return reasons;
  }
  function draftReadiness(state2, context) {
    const reasons = sessionBlocks(state2, context);
    if (state2.session && !state2.session.plan.actions.some((action) => action.phase === "draft")) {
      reasons.push("Nothing to draft on this view.");
    }
    return { ok: reasons.length === 0, reasons };
  }
  function commitReadiness(state2, context) {
    const reasons = sessionBlocks(state2, context);
    const session = state2.session;
    if (session && !session.committedAt) {
      const plan = session.plan;
      const hasDraftActions = plan.actions.some((action) => action.phase === "draft");
      if (!plan.actions.some((action) => action.phase === "commit")) {
        reasons.push("No Create Page, Save, or Post button on this view, so there is nothing to commit.");
      }
      if (hasDraftActions && !session.drafted) reasons.push("Draft first, then read the page.");
      if (session.drafted?.unconfirmed.length) {
        reasons.push(`These did not stick, so the page does not match the plan: ${labels(plan, session.drafted.unconfirmed)}. Fix the pack or paste them, then plan again.`);
      }
      if (session.drift.length) {
        reasons.push(`Changed on the page after drafting: ${labels(plan, session.drift)}. Plan again to approve the page as it is now.`);
      }
      if (!state2.checklist.reviewedPage) reasons.push('Tick "I read every drafted field on the page".');
      for (const gate of plan.gates) {
        if (gate.code !== "file") continue;
        if (gate.fieldId === "profilePicture" && !state2.checklist.profilePicture) reasons.push("Upload the profile picture on the page and tick it in the checklist.");
        if (gate.fieldId === "coverPhoto" && !state2.checklist.coverPhoto) reasons.push("Upload the cover photo on the page and tick it in the checklist.");
      }
    }
    return { ok: reasons.length === 0, reasons: [...new Set(reasons)] };
  }
  function labels(plan, ids) {
    return ids.map((id) => plan.actions.find((action) => action.id === id)?.label ?? safeLabel(id)).join(", ");
  }
  function safeLabel(id) {
    try {
      return fieldById(id).labels[0] ?? id;
    } catch {
      return id;
    }
  }
  function bannerFor(code, message) {
    switch (code) {
      case "no-receiver":
        return { tone: "warn", title: "Page Push is not running in this tab yet.", detail: "Reload the Facebook tab (F5), wait for it to finish loading, then try again." };
      case "not-facebook-tab":
        return { tone: "warn", title: "This tab is not Facebook.", detail: "Open your Facebook Business Page (creation, settings, or composer) in this window and focus that tab." };
      case "no-tab":
        return { tone: "warn", title: "No tab to work with.", detail: "Click into the Facebook tab, then try again." };
      case "disconnected":
        return { tone: "warn", title: "The Facebook tab closed or navigated away.", detail: "Open the Page view again and plan it." };
      case "not-facebook":
      case "page-identity":
      case "not-business-page":
      case "sign-in":
        return { tone: "bad", title: "Page Push refused this view.", detail: message };
      case "context":
        return { tone: "warn", title: "The page changed since this plan.", detail: "Plan this view again. The earlier approval no longer applies." };
      case "no-plan":
        return { tone: "warn", title: "The tab lost its plan (it reloaded).", detail: "Plan this view again." };
      case "drift":
        return { tone: "bad", title: "A drafted field changed on the page.", detail: message ?? "Plan again to approve the page as it is now." };
      case "confirm":
        return { tone: "bad", title: "The tab is holding a different plan.", detail: "Plan again so the panel and the page agree." };
      case "captcha":
        return { tone: "warn", title: "Solve the captcha on the page.", detail: "Page Push never solves captchas. Solve it yourself, then Approve & Commit again." };
      case "file":
        return { tone: "warn", title: "A required image is not attached yet.", detail: message };
      case "stale":
        return { tone: "bad", title: "The page no longer matches the approved plan.", detail: message };
      case "unconfirmed":
        return { tone: "bad", title: "A commit step did not stick.", detail: message };
      case "blocked":
        return { tone: "bad", title: "The plan has errors.", detail: message };
      case "busy":
        return { tone: "info", title: "Still writing to the page.", detail: "Wait for the current draft or commit to finish." };
      default:
        return { tone: "bad", title: "Something went wrong.", detail: message };
    }
  }

  // src/extension/storage.ts
  var STORAGE_KEY = "pagepush.v1";
  function toSaved(state2, at = /* @__PURE__ */ new Date()) {
    return {
      version: 1,
      pack: state2.pack,
      checklist: state2.checklist,
      progress: state2.progress,
      session: state2.session,
      receipts: state2.receipts ?? [],
      versions: state2.versions ?? [],
      archives: state2.archives ?? [],
      recordsScoped: true,
      savedAt: at.toISOString()
    };
  }
  async function load(area) {
    try {
      const found = (await area.get(STORAGE_KEY))[STORAGE_KEY];
      if (!found || found.version !== 1 || !found.pack) return null;
      return found;
    } catch {
      return null;
    }
  }
  async function save(area, state2) {
    await area.set({ [STORAGE_KEY]: toSaved(state2) });
  }
  function saver(area, delayMs = 300) {
    let timer = null;
    let pending = null;
    let generation = 0;
    let clearing2 = false;
    let tail = Promise.resolve();
    const enqueue = (work, epoch) => {
      const result = tail.then(async () => {
        if (epoch === generation && !clearing2) await work();
      });
      tail = result.catch(() => void 0);
      return result;
    };
    const flush = () => {
      if (timer !== null) clearTimeout(timer);
      timer = null;
      const snapshot = pending;
      pending = null;
      return snapshot ? enqueue(() => save(area, snapshot), generation) : tail;
    };
    return {
      schedule(state2) {
        if (clearing2) return;
        pending = structuredClone(state2);
        if (timer !== null) clearTimeout(timer);
        timer = setTimeout(() => {
          void flush().catch(() => void 0);
        }, delayMs);
      },
      flush,
      write(items) {
        if (clearing2) return Promise.resolve();
        const snapshot = structuredClone(items);
        return enqueue(() => area.set(snapshot), generation);
      },
      async clear() {
        if (clearing2) return tail;
        clearing2 = true;
        generation += 1;
        if (timer !== null) clearTimeout(timer);
        timer = null;
        pending = null;
        const result = tail.then(() => area.clear());
        tail = result.catch(() => void 0);
        try {
          await result;
        } finally {
          clearing2 = false;
        }
      }
    };
  }

  // src/extension/copy-panel.ts
  var OLLAMA_SETTINGS_KEY = "pagepush.ollama.v1";
  function wireCopyPanel(deps) {
    const el = (id) => {
      const found = deps.doc.getElementById(id);
      if (!found) throw new Error(`Missing #${id} in sidepanel.html`);
      return found;
    };
    const modelInput = el("ollama-model");
    const modelList = el("ollama-models");
    const status = el("ollama-status");
    const loadButton = el("ollama-load");
    const draftButton2 = el("ollama-draft");
    const offlineButton = el("offline-draft");
    const undoButton = el("copy-undo");
    let ready = null;
    let working = Promise.resolve();
    let controller = null;
    let epoch = 0;
    let undo = null;
    const model = () => modelInput.value.trim() || DEFAULT_OLLAMA_MODEL;
    const say = (text, tone = "info") => {
      status.textContent = text;
      status.dataset.tone = tone;
    };
    const busy2 = (on) => {
      draftButton2.disabled = on;
      offlineButton.disabled = on;
      modelInput.disabled = on;
    };
    const current = (revision2, token) => deps.available() && deps.revision() === revision2 && epoch === token;
    const failed = (failure2) => {
      ready = null;
      say(failure2.message, failure2.code === "unreachable" ? "warn" : "bad");
      deps.setBanner({ tone: failure2.code === "forbidden" ? "bad" : "warn", title: failure2.code === "forbidden" ? "Ollama refused the extension." : "Local model unavailable.", detail: `${failure2.message} The offline draft still works.` });
    };
    const run = (revision2, token, task) => {
      working = working.then(async () => {
        if (!current(revision2, token)) return;
        const local = new AbortController();
        controller = local;
        busy2(true);
        try {
          await task(local.signal);
        } finally {
          if (controller === local) controller = null;
          if (current(revision2, token)) {
            busy2(false);
            loadButton.textContent = "Check / Load Model";
          }
        }
      }).catch(() => {
        if (current(revision2, token)) {
          busy2(false);
          say("Drafting stopped.", "warn");
        }
      });
    };
    modelInput.value = DEFAULT_OLLAMA_MODEL;
    const settingsRevision = deps.revision();
    const settingsEpoch = epoch;
    void (async () => {
      try {
        const saved = (await deps.storage.get(OLLAMA_SETTINGS_KEY))[OLLAMA_SETTINGS_KEY];
        if (deps.revision() === settingsRevision && epoch === settingsEpoch && typeof saved?.model === "string" && saved.model.trim()) modelInput.value = saved.model;
      } catch {
      }
    })();
    modelInput.addEventListener("change", () => {
      if (!deps.available()) return;
      ready = null;
      void deps.storage.set({ [OLLAMA_SETTINGS_KEY]: { model: model() } }).catch(() => void 0);
    });
    loadButton.addEventListener("click", () => {
      if (!deps.available()) return;
      if (controller) {
        controller.abort();
        return;
      }
      const revision2 = deps.revision(), token = epoch;
      run(revision2, token, async (signal) => {
        loadButton.textContent = "Cancel";
        const wanted = model();
        const result = await checkAndLoad(wanted, {
          fetch: deps.fetch,
          signal,
          onStep: (step, detail) => {
            if (!current(revision2, token)) return;
            if (step === "checking") say(`Checking Ollama at ${OLLAMA_URL}…`);
            if (step === "pulling") say(`Downloading ${detail ?? wanted}. This runs once; you can cancel.`);
            if (step === "warming") say(`Loading ${detail ?? wanted} into memory…`);
          },
          onProgress: (progress) => {
            if (current(revision2, token)) say(progressText(wanted, progress));
          }
        });
        if (!current(revision2, token) || signal.aborted) return;
        if (!result.ok) {
          failed(result);
          return;
        }
        ready = result.match ?? wanted;
        fillModels(modelList, result.models);
        say(`Ready: ${ready} (Ollama ${result.version}).`, "good");
      });
    });
    draftButton2.addEventListener("click", () => {
      if (!deps.available()) return;
      const revision2 = deps.revision(), token = epoch, pack = structuredClone(deps.pack());
      run(revision2, token, async (signal) => {
        let use = ready;
        const fetch = deps.fetch;
        if (!use) {
          say(`Checking Ollama at ${OLLAMA_URL}…`);
          const found = await ollamaStatus(model(), { fetch });
          if (!current(revision2, token) || signal.aborted) return;
          if (!found.ok) {
            failed(found);
            return;
          }
          if (!found.match) {
            say(`${model()} is not downloaded yet. Click Check / Load Model first.`, "warn");
            return;
          }
          use = found.match;
        }
        say(`Drafting with ${use}…`);
        const outcome = await draftFacebookCopy(pack, ollamaRunner(use, { fetch }));
        if (current(revision2, token) && !signal.aborted) apply(outcome, use);
      });
    });
    offlineButton.addEventListener("click", () => {
      if (!deps.available()) return;
      const revision2 = deps.revision(), token = epoch, pack = structuredClone(deps.pack());
      run(revision2, token, async () => {
        const outcome = await draftFacebookCopy(pack);
        if (current(revision2, token)) apply(outcome, null);
      });
    });
    undoButton.addEventListener("click", () => {
      if (!undo || !deps.available() || undo.revision !== deps.revision()) {
        undo = null;
        undoButton.hidden = true;
        return;
      }
      const copy2 = undo.copy;
      undo = null;
      undoButton.hidden = true;
      deps.applyCopy(copy2);
      say("Restored the bio and post from before the draft.");
    });
    function apply(outcome, used) {
      const copy2 = {};
      if (outcome.bio != null) copy2.bio = outcome.bio;
      if (outcome.launchPost != null) copy2.launchPost = outcome.launchPost;
      if (!Object.keys(copy2).length) {
        say("Add the Page name (and categories) first; there is nothing to draft from yet.", "warn");
        return;
      }
      const pack = deps.pack();
      const previous = { bio: pack.page?.bio ?? "", ...copy2.launchPost != null ? { launchPost: pack.launchPost?.text ?? "" } : {} };
      deps.applyCopy(copy2);
      undo = { revision: deps.revision(), copy: previous };
      undoButton.hidden = false;
      const by = outcome.source === "ollama" ? `Drafted with ${used}` : outcome.source === "mixed" ? `Drafted partly with ${used}, partly from the facts` : "Drafted from the pack facts (offline)";
      const warnings = outcome.issues.map((item) => item.message);
      say(warnings.length ? `${by}. ${warnings.join(" ")}` : `${by}.`, outcome.source === "offline" && used ? "warn" : "good");
      deps.setBanner({ tone: "info", title: "Read the drafted copy before planning.", detail: "The bio and launch post in the pack were replaced. Edit them as you like. A later Draft writes values into Facebook before final approval; verify the result there." });
    }
    return {
      idle: () => working,
      invalidate() {
        epoch += 1;
        controller?.abort();
        controller = null;
        ready = null;
        undo = null;
        undoButton.hidden = true;
        busy2(false);
        loadButton.textContent = "Check / Load Model";
        working = Promise.resolve();
      }
    };
  }
  function progressText(model, progress) {
    if (progress.total && progress.completed != null) return `Downloading ${model}: ${Math.floor(progress.completed / progress.total * 100)}% (${progress.status}).`;
    return `Downloading ${model}: ${progress.status}.`;
  }
  function fillModels(list, models) {
    list.replaceChildren(...models.map((name) => {
      const option2 = list.ownerDocument.createElement("option");
      option2.value = name;
      return option2;
    }));
  }

  // src/extension/version-history.ts
  var VERSION_LIMIT = 20;
  function readVersions(value) {
    if (!Array.isArray(value)) return [];
    return value.filter((item) => {
      if (!item || typeof item !== "object") return false;
      const entry = item;
      if (typeof entry.savedAt !== "string" || !Number.isFinite(Date.parse(entry.savedAt))) return false;
      return Boolean(checkPack(entry.pack).pack);
    }).slice(0, VERSION_LIMIT).map((entry) => structuredClone(entry));
  }
  function saveVersion(state2, at = /* @__PURE__ */ new Date()) {
    const versions = state2.versions ?? [];
    if (versions[0] && packFingerprint(versions[0].pack) === packFingerprint(state2.pack)) return state2;
    const snapshot = { savedAt: at.toISOString(), pack: structuredClone(state2.pack) };
    return { ...state2, versions: [snapshot, ...versions].slice(0, VERSION_LIMIT) };
  }
  function restoreVersion(state2, index, at = /* @__PURE__ */ new Date()) {
    const version = state2.versions?.[index];
    if (!version || !checkPack(version.pack).pack) return state2;
    const pack = structuredClone(version.pack);
    const saved = saveVersion(state2, at);
    return replacePack(saved, pack);
  }

  // manifest.json
  var manifest_default = {
    manifest_version: 3,
    name: "Page Push",
    short_name: "Page Push",
    version: "1.0.0",
    minimum_chrome_version: "120",
    description: "Manual-assist form fill for Facebook Business Pages. Review the draft and approve each final action.",
    permissions: [
      "sidePanel",
      "storage"
    ],
    host_permissions: [
      "https://*.facebook.com/*",
      "http://localhost:11434/*",
      "http://127.0.0.1:11434/*"
    ],
    action: {
      default_title: "Open Page Push",
      default_icon: {
        "16": "icons/icon16.png",
        "32": "icons/icon32.png",
        "48": "icons/icon48.png",
        "128": "icons/icon128.png"
      }
    },
    side_panel: {
      default_path: "sidepanel.html"
    },
    background: {
      service_worker: "background.js"
    },
    content_scripts: [
      {
        matches: [
          "https://*.facebook.com/*"
        ],
        js: [
          "content.js"
        ],
        run_at: "document_idle"
      }
    ],
    icons: {
      "16": "icons/icon16.png",
      "32": "icons/icon32.png",
      "48": "icons/icon48.png",
      "128": "icons/icon128.png"
    }
  };

  // src/extension/sidepanel.ts
  var FACEBOOK_TAB = /^https:\/\/([a-z0-9-]+\.)*facebook\.com\//i;
  var RETRIES = 4;
  var RETRY_MS = 600;
  var state = initialState();
  var activeTabId = null;
  var busy = false;
  var clearing = false;
  var starting = true;
  var revision = 0;
  var dataGeneration = 0;
  var copyPanel;
  var available = () => !clearing && !starting;
  var store = saver(chrome.storage.local);
  var $ = (id) => {
    const el = document.getElementById(id);
    if (!el) throw new Error(`Missing #${id}`);
    return el;
  };
  var form = $("pack-form");
  var planButton = $("plan");
  var draftButton = $("draft");
  var commitButton = $("commit");
  function buildStaticControls() {
    const mode = $("hours-mode");
    mode.append(option("", "Not set"));
    for (const item of HOURS_MODES) mode.append(option(item, item));
    const schedule = $("schedule");
    for (const day of WEEKDAYS) {
      const label = document.createElement("label");
      label.htmlFor = `hours-${day}`;
      label.textContent = `${day[0].toUpperCase()}${day.slice(1)}`;
      const input = document.createElement("input");
      input.type = "text";
      input.id = `hours-${day}`;
      input.dataset.path = `hours.schedule.${day}`;
      input.placeholder = "9:00–17:00 or Closed";
      schedule.append(label, input);
    }
    const list = $("cta-types");
    for (const item of CTA_SUGGESTIONS) list.append(option(item, item));
    const summary = $("receipt-summary");
    const oldDescription = summary.nextElementSibling;
    if (oldDescription) oldDescription.textContent = "Receipts include the Page name, Facebook Page address or ID, plan hashes, times, tier, field names and checklist. Refusal messages may include additional page or client information. Review before sharing. Attempts do not confirm Facebook success; the checksum is not a signature.";
    const explanation = document.createElement("p");
    explanation.id = "receipt-safety";
    explanation.className = "muted";
    explanation.textContent = "Actions are attempted, not verified by Facebook. Previous client records are archived locally when switching packs. Clear All targets archives too; see the local-data warning below.";
    summary.after(explanation);
    const archives = document.createElement("div");
    archives.id = "receipt-archives";
    explanation.after(archives);
    const clearRecords = document.createElement("button");
    clearRecords.type = "button";
    clearRecords.id = "receipt-clear";
    clearRecords.textContent = "Clear current progress and receipts";
    archives.after(clearRecords);
    clearRecords.addEventListener("click", () => {
      if (!available() || busy) return;
      if (clearRecords.dataset.armed !== "true") {
        clearRecords.dataset.armed = "true";
        clearRecords.textContent = "Click again to clear current progress and receipts";
        setTimeout(() => {
          clearRecords.dataset.armed = "";
          clearRecords.textContent = "Clear current progress and receipts";
        }, 5e3);
        return;
      }
      clearRecords.dataset.armed = "";
      clearRecords.textContent = "Clear current progress and receipts";
      commitState({ ...state, progress: [], receipts: [] });
      setBanner({ tone: "info", title: "Current progress and receipts cleared.", detail: "Earlier archives and saved pack versions remain. Clear All removes them too." });
    });
  }
  function option(value, text) {
    const el = document.createElement("option");
    el.value = value;
    el.textContent = text;
    return el;
  }
  function commitState(next, options = {}) {
    if (!available()) return;
    const archivesAdded = (next.archives?.length ?? 0) > (state.archives?.length ?? 0);
    if (next.pack !== state.pack) {
      revision += 1;
      copyPanel?.invalidate();
    }
    state = next;
    store.schedule(state);
    render(options);
    if (archivesAdded) setBanner({ tone: "info", title: "Previous client records archived locally.", detail: "The current progress and receipt were reset. Earlier receipts are available under Sprint receipt; Clear All erases archives too." });
  }
  function setBanner(banner) {
    const box = $("banner");
    box.dataset.tone = banner.tone;
    $("banner-title").textContent = banner.title;
    $("banner-detail").textContent = banner.detail ?? "";
  }
  function setTier(tier) {
    const base = starterPack(tier);
    const merged = mergeDefaults(base, state.pack);
    merged.tier = tier;
    commitState(editPack(state, merged), { renderForm: true });
  }
  function mergeDefaults(base, value) {
    if (Array.isArray(value)) return value;
    if (!base || typeof base !== "object" || Array.isArray(base)) return value === void 0 ? base : value;
    if (!value || typeof value !== "object") return structuredClone(base);
    const out = { ...value };
    for (const [key, item] of Object.entries(base)) out[key] = mergeDefaults(item, out[key]);
    return out;
  }
  async function refreshActiveTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    activeTabId = tab?.id ?? null;
    return tab ?? null;
  }
  async function send(request, tabId, allowed = () => true) {
    const tab = await refreshActiveTab();
    if (!allowed()) return { error: "superseded" };
    if (!tab?.id) return { error: "no-tab" };
    if (tabId != null && tab.id !== tabId) return { error: "context", message: "Switch back to the tab you planned." };
    if (!tab.url || !FACEBOOK_TAB.test(tab.url)) return { error: "not-facebook-tab" };
    for (let attempt = 0; ; attempt += 1) {
      try {
        if (!allowed()) return { error: "superseded" };
        const reply = await chrome.tabs.sendMessage(tab.id, request);
        if (!reply) return { error: "no-receiver" };
        return { reply, tabId: tab.id };
      } catch (error) {
        const text = error instanceof Error ? error.message : String(error);
        if (/Receiving end does not exist|Could not establish connection/i.test(text)) {
          if (request.type === "pagepush:plan" || request.type === "pagepush:status") {
            if (attempt < RETRIES - 1) {
              await wait(RETRY_MS);
              continue;
            }
          }
          return { error: "no-receiver" };
        }
        if (/No tab with id|tab was closed|message port closed|back\/forward cache/i.test(text)) return { error: "disconnected" };
        return { error: "error", message: text };
      }
    }
  }
  function wait(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  function failure(result) {
    if ("error" in result) {
      setBanner(bannerFor(result.error, result.message));
      return true;
    }
    if (!result.reply.ok) {
      setBanner(bannerFor(result.reply.code, result.reply.message));
      return true;
    }
    return false;
  }
  async function planView(auto = false) {
    if (busy || !available()) return;
    const check = checkPack(state.pack);
    if (!check.pack) {
      renderPackIssues(check.errors, check.warnings);
      setBanner({ tone: "bad", title: "The pack is not valid yet.", detail: "Fix the pack checks listed above the Plan button, then plan." });
      return;
    }
    const submitted = cleanPack(state.pack);
    const submittedPrint = packFingerprint(submitted);
    const startedRevision = revision, generation = dataGeneration;
    const current = () => available() && revision === startedRevision && dataGeneration === generation;
    busy = true;
    render();
    try {
      const result = await send({ type: "pagepush:plan", pack: submitted }, void 0, current);
      if (!current() || packFingerprint(state.pack) !== submittedPrint) {
        if (dataGeneration === generation && available()) {
          commitState(invalidate(state, "The pack changed while planning. Plan again."));
          setBanner({ tone: "warn", title: "Pack changed while planning.", detail: "The old reply was discarded. Plan again." });
        }
        return;
      }
      if (failure(result) || "error" in result || !result.reply.ok || !result.reply.plan) {
        commitState(invalidate(state, "This view could not be planned. Plan again."));
        return;
      }
      commitState(startSession(state, result.tabId, result.reply.plan, submittedPrint));
      const plan = result.reply.plan;
      if (plan.errors.length) {
        const refusal = plan.errors.find((item) => ["not-facebook", "page-identity", "not-business-page", "sign-in"].includes(item.code));
        setBanner(refusal ? bannerFor(refusal.code, refusal.message) : { tone: "bad", title: "The plan has errors.", detail: "They are listed in the plan inspector." });
      } else if (!plan.actions.length) {
        setBanner({ tone: "info", title: "Nothing to fill on this view.", detail: "Open the next Page screen; it is planned automatically." });
      } else {
        setBanner({
          tone: "good",
          title: auto ? "Planned the new view." : "Planned.",
          detail: `${plan.actions.filter((a) => a.phase === "draft").length} field(s) to draft, ${plan.actions.filter((a) => a.phase === "commit").length} commit step(s). Review, then Draft.`
        });
      }
    } finally {
      busy = false;
      render();
    }
  }
  async function draft() {
    const session = state.session;
    if (!session || busy || !available() || !draftReadiness(state, { activeTabId }).ok) return;
    const startedRevision = revision, generation = dataGeneration;
    const current = () => available() && revision === startedRevision && dataGeneration === generation && state.session === session;
    busy = true;
    render();
    try {
      const result = await send({ type: "pagepush:draft", planHash: session.plan.planHash }, session.tabId, current);
      if (!current()) return;
      if (failure(result) || "error" in result || !result.reply.ok || !result.reply.draft) {
        const code = "error" in result ? result.error : result.reply.ok ? "" : result.reply.code;
        if (["context", "disconnected", "no-plan", "confirm"].includes(code)) {
          commitState(invalidate(state, "The tab no longer holds this plan. Plan again."));
        }
        return;
      }
      commitState(recordDraft(state, result.reply.draft));
      const unconfirmed = result.reply.draft.unconfirmed;
      setBanner(unconfirmed.length ? { tone: "warn", title: "Drafted, but some fields did not stick.", detail: "Use the copy-paste fallback for them, or fix the pack and plan again." } : { tone: "good", title: "Drafted.", detail: "Read every drafted field on the Facebook page, tick the checklist, then Approve & Commit." });
    } finally {
      busy = false;
      render();
    }
  }
  async function approveAndCommit() {
    const session = state.session;
    if (!session || busy || !available() || !commitReadiness(state, { activeTabId }).ok) return;
    const startedRevision = revision, generation = dataGeneration;
    const current = () => available() && revision === startedRevision && dataGeneration === generation && state.session === session && commitReadiness(state, { activeTabId }).ok;
    const approvedAt = /* @__PURE__ */ new Date();
    busy = true;
    render();
    try {
      const verify = await send({ type: "pagepush:verify", planHash: session.plan.planHash }, session.tabId, current);
      if (!current()) return;
      if (failure(verify) || "error" in verify || !verify.reply.ok) return;
      if (verify.reply.drift?.length) {
        commitState(recordDrift(state, session.plan.planHash, verify.reply.drift));
        setBanner(bannerFor("drift"));
        return;
      }
      const result = await send({ type: "pagepush:commit", planHash: session.plan.planHash }, session.tabId, current);
      if (!current()) return;
      if ("error" in result) {
        commitState(recordCommitRefused(state, { code: "unknown-dispatch", message: "The reply was lost; the action may have been dispatched.", approvedAt }));
        setBanner({ tone: "warn", title: "Action outcome unknown.", detail: "Check Facebook before doing anything else. Do not retry blindly." });
        return;
      }
      if (!result.reply.ok) {
        const uncertain = (result.reply.applied?.length ?? 0) > 0 || ["error", "unconfirmed"].includes(result.reply.code);
        commitState(recordCommitRefused(state, { code: result.reply.code, message: result.reply.message, applied: result.reply.applied, approvedAt }));
        if (uncertain) setBanner({ tone: "warn", title: "Action outcome unverified.", detail: "Some actions may have run. Check Facebook directly; do not retry blindly." });
        else failure(result);
        return;
      }
      commitState(recordCommit(state, /* @__PURE__ */ new Date(), approvedAt));
      const steps = session.plan.actions.filter((action) => action.phase === "commit").map((action) => action.label);
      setBanner({ tone: "warn", title: `Attempted: ${steps.join(", ")}.`, detail: "Facebook success is unverified. Check the page directly; do not retry blindly." });
    } finally {
      busy = false;
      render();
    }
  }
  function render(options = {}) {
    const offer = tierOffer(state.pack.tier);
    $("offer").textContent = offer ? `$${offer.priceUsd} · ${offer.name.split(": ").pop()}` : "";
    for (const radio of document.querySelectorAll("input[name='tier']")) radio.checked = radio.value === state.pack.tier;
    if (options.renderForm) renderForm();
    renderTierVisibility();
    renderCounters();
    const check = checkPack(state.pack);
    renderPackIssues(check.errors, check.warnings);
    renderInspector();
    renderChecklist();
    renderProgress();
    renderPaste();
    renderReceipts();
    renderVersions();
    renderControls();
  }
  function renderVersions() {
    const versions = state.versions;
    $("version-status").textContent = versions.length ? `${versions.length} saved version${versions.length === 1 ? "" : "s"}, newest first.` : "No versions saved yet.";
    $("version-list").replaceChildren(...versions.map((version, index) => {
      const item = document.createElement("li");
      const label = document.createElement("span");
      const date = new Date(version.savedAt).toLocaleString();
      label.textContent = `${date} · ${version.pack.page.name || "Unnamed pack"} · ${version.pack.tier} `;
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = "Restore";
      button.setAttribute("aria-label", `Restore ${version.pack.page.name || "unnamed pack"}, saved ${date}`);
      button.addEventListener("click", () => {
        if (!available()) return;
        commitState(restoreVersion(state, index), { renderForm: true });
        setBanner({ tone: "info", title: "Pack version restored.", detail: "Your previous pack was saved in version history; its progress and receipts were archived locally. Plan this view again." });
      });
      item.append(label, button);
      return item;
    }));
  }
  function renderReceipts() {
    const entries = state.receipts ?? [];
    const attempted = entries.filter((entry) => entry.outcome === "attempted" || entry.outcome === "committed").length;
    const other = entries.length - attempted;
    $("receipt-summary").textContent = entries.length ? `${entries.length} approval${entries.length === 1 ? "" : "s"}: ${attempted} attempted / unverified${other ? `, ${other} refused or partial` : ""}.` : "No approvals for this pack yet.";
    $("receipt-download").disabled = entries.length === 0 || !available();
    $("receipt-clear").disabled = busy || !available();
    const host = $("receipt-archives");
    host.replaceChildren(...(state.archives ?? []).map((archive, index) => {
      const row = document.createElement("div");
      const label = archive.unverifiedOwner ? "Earlier records - client unknown (may be mixed)" : archive.pageName || "Unnamed previous pack";
      row.textContent = `${label}: ${archive.receipts.length} approval(s), ${archive.progress.length} progress item(s). `;
      if (archive.progress.length) {
        const details = document.createElement("details");
        const summary = document.createElement("summary");
        summary.textContent = "View archived progress";
        const list = document.createElement("ul");
        list.replaceChildren(...archive.progress.map((entry) => plainItem(`${entry.label} - ${entry.status === "drafted" ? "drafted" : "attempted / unverified"} - ${shortUrl(entry.url)}`)));
        details.append(summary, list);
        row.append(details);
      }
      if (archive.receipts.length) {
        const button = document.createElement("button");
        button.type = "button";
        button.textContent = "Download archived receipt";
        button.disabled = !available();
        button.setAttribute("aria-label", `Download archived receipt for ${label}`);
        button.addEventListener("click", () => {
          if (!available()) return;
          const selected = state.archives?.[index];
          if (selected !== archive) return;
          const pack = starterPack(archive.tier);
          pack.page.name = archive.unverifiedOwner ? "Unattributed earlier records" : archive.pageName;
          const receipt = buildSprintReceipt({ pack, entries: archive.receipts, extensionVersion: manifest_default.version, unattributed: archive.unverifiedOwner });
          downloadJson(receiptFileName(receipt), receipt);
        });
        row.append(button);
      }
      return row;
    }));
  }
  function downloadJson(fileName, value) {
    const link = document.createElement("a");
    link.href = `data:application/json;charset=utf-8,${encodeURIComponent(`${JSON.stringify(value, null, 2)}
`)}`;
    link.download = fileName;
    link.hidden = true;
    document.body.appendChild(link);
    link.click();
    link.remove();
  }
  function renderForm() {
    for (const input of form.querySelectorAll("[data-path]")) {
      const value = readPath(state.pack, input.dataset.path);
      input.value = typeof value === "string" ? value : "";
    }
  }
  function renderTierVisibility() {
    const allowed = tierFields(state.pack.tier);
    for (const group of form.querySelectorAll("fieldset[data-fields]")) {
      group.hidden = !group.dataset.fields.split(",").some((id) => allowed.has(id));
    }
    $("schedule").hidden = state.pack.hours?.mode !== "Open on selected hours";
  }
  function renderCounters() {
    for (const counter of counters(state.pack)) {
      const el = document.querySelector(`[data-counter="${counter.path}"]`);
      if (!el) continue;
      el.textContent = `${counter.used} / ${counter.max}`;
      el.dataset.over = String(counter.over);
    }
  }
  function renderPackIssues(errors, warnings) {
    const list = $("pack-issues");
    list.replaceChildren(
      ...errors.map((item) => issueItem("error", item.message)),
      ...warnings.map((item) => issueItem("warning", item.message))
    );
  }
  function issueItem(level, text) {
    const li = document.createElement("li");
    li.dataset.level = level;
    li.textContent = text;
    return li;
  }
  function renderInspector() {
    const session = state.session;
    const card = $("inspector");
    card.hidden = !session;
    if (!session) return;
    const plan = session.plan;
    const status = session.committedAt ? "attempted / unverified" : session.stale ? `stale — ${session.stale}` : session.drafted ? "drafted" : "planned";
    $("plan-context").textContent = `${shortUrl(plan.pageUrl)} · ${status}`;
    $("plan-issues").replaceChildren(
      ...plan.errors.map((item) => issueItem("error", item.message)),
      ...plan.warnings.map((item) => issueItem("warning", item.message))
    );
    $("plan-actions").replaceChildren(...plan.actions.map((action) => {
      const row = document.createElement("tr");
      const value = action.preview.startsWith(`${action.label}: `) ? action.preview.slice(action.label.length + 2) : action.preview;
      const kind = session.drift.includes(action.id) ? "drift" : session.drafted?.unconfirmed.includes(action.id) ? "unconfirmed" : session.committedAt ? "attempted" : session.drafted?.applied.includes(action.id) ? "applied" : action.phase;
      row.append(cell(action.label), cell(value), badgeCell(kind));
      return row;
    }));
    const gates = plan.gates.map((gate) => gate.message);
    $("plan-gates-wrap").hidden = gates.length === 0;
    $("plan-gates").replaceChildren(...gates.map((text) => issueItem("warning", text)));
    const notes = plan.preview.filter((line) => !plan.actions.some((action) => action.preview === line));
    $("plan-notes-wrap").hidden = notes.length === 0;
    $("plan-notes").replaceChildren(...notes.map((text) => plainItem(text)));
    const deferred = plan.deferred.filter((id) => tierFields(state.pack.tier).has(id));
    $("plan-deferred-wrap").hidden = deferred.length === 0;
    $("plan-deferred").replaceChildren(...deferred.map((id) => {
      const field = fieldById(id);
      return plainItem(`${field.labels[0]} — ${STEP_NAMES[field.step ?? ""] ?? "a later screen"}`);
    }));
    $("plan-hash").textContent = plan.planHash;
  }
  var STEP_NAMES = {
    create: "Page creation form",
    contact: "contact info in Page settings",
    location: "location in Page settings",
    hours: "hours in Page settings",
    cta: "the Add action button dialog",
    post: "the Create post composer",
    customize: "profile and cover photo step"
  };
  function cell(text) {
    const td = document.createElement("td");
    td.textContent = text;
    return td;
  }
  function badgeCell(kind) {
    const td = document.createElement("td");
    const badge = document.createElement("span");
    badge.className = "badge";
    badge.dataset.kind = kind;
    badge.textContent = kind === "draft" ? "Draft" : kind === "commit" ? "On approve" : kind === "attempted" ? "Attempted / unverified" : kind[0].toUpperCase() + kind.slice(1);
    td.append(badge);
    return td;
  }
  function plainItem(text) {
    const li = document.createElement("li");
    li.textContent = text;
    return li;
  }
  function renderChecklist() {
    $("check-reviewed").checked = state.checklist.reviewedPage;
    $("check-profile").checked = state.checklist.profilePicture;
    $("check-cover").checked = state.checklist.coverPhoto;
    $("need-profile").textContent = state.pack.media?.profilePicture === "required" ? "(required)" : "(optional)";
    $("need-cover").textContent = state.pack.media?.coverPhoto === "required" ? "(required)" : "(optional)";
  }
  function renderProgress() {
    $("progress-card").hidden = state.progress.length === 0;
    $("progress").replaceChildren(...state.progress.map((entry) => {
      const row = document.createElement("tr");
      row.append(cell(entry.label), badgeCell(entry.status === "committed" ? "attempted" : entry.status), cell(shortUrl(entry.url)));
      return row;
    }));
  }
  function renderPaste() {
    const blocks = pasteBlocks(state.pack);
    const host = $("paste-blocks");
    if (!blocks.length) {
      host.replaceChildren(plainItem("Fill in the pack to get copy blocks."));
      return;
    }
    host.replaceChildren(...blocks.map((block) => {
      const wrap = document.createElement("div");
      wrap.className = "paste";
      const head = document.createElement("header");
      const title = document.createElement("strong");
      title.textContent = block.label;
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = "Copy";
      button.dataset.copy = block.id;
      button.setAttribute("aria-label", `Copy ${block.label}`);
      button.addEventListener("click", () => {
        void copy(block.text, button);
      });
      head.append(title, button);
      head.style.display = "flex";
      head.style.justifyContent = "space-between";
      const pre = document.createElement("pre");
      pre.textContent = block.text;
      wrap.append(head, pre);
      return wrap;
    }));
  }
  function renderControls() {
    const context = { activeTabId };
    const canDraft = draftReadiness(state, context);
    const canCommit = commitReadiness(state, context);
    planButton.disabled = busy || !available();
    draftButton.disabled = busy || !available() || !canDraft.ok;
    commitButton.disabled = busy || !available() || !canCommit.ok;
    const reasons = state.session ? state.session.drafted ? canCommit.reasons : canDraft.ok ? canCommit.reasons.filter((r) => !r.startsWith("Tick")) : canDraft.reasons : [];
    $("reasons").replaceChildren(...reasons.map((reason) => plainItem(reason)));
  }
  function shortUrl(url) {
    try {
      const parsed = new URL(url);
      return `${parsed.hostname.replace(/^www\./, "")}${parsed.pathname}`;
    } catch {
      return url;
    }
  }
  async function copy(text, button) {
    let ok = false;
    try {
      await navigator.clipboard.writeText(text);
      ok = true;
    } catch {
      const area = document.createElement("textarea");
      area.value = text;
      document.body.append(area);
      area.select();
      ok = document.execCommand?.("copy") ?? false;
      area.remove();
    }
    button.textContent = ok ? "Copied" : "Select and copy";
    setTimeout(() => {
      button.textContent = "Copy";
    }, 1500);
  }
  form.addEventListener("input", (event) => {
    const target = event.target;
    const path = target.dataset?.path;
    if (!path) return;
    const pack = structuredClone(state.pack);
    setPath(pack, path, target.value);
    commitState(editPack(state, pack));
  });
  form.addEventListener("change", (event) => {
    const target = event.target;
    if (target.tagName !== "SELECT" || !target.dataset.path) return;
    const pack = structuredClone(state.pack);
    setPath(pack, target.dataset.path, target.value);
    commitState(editPack(state, pack));
  });
  form.addEventListener("submit", (event) => event.preventDefault());
  for (const radio of document.querySelectorAll("input[name='tier']")) {
    radio.addEventListener("change", () => {
      if (radio.checked) setTier(radio.value);
    });
  }
  $("starter").addEventListener("click", () => {
    if (!available()) return;
    const button = $("starter");
    if (button.dataset.armed !== "true" && cleanPack(state.pack).page.name) {
      button.dataset.armed = "true";
      button.textContent = "Click again to replace the pack";
      setTimeout(() => {
        button.dataset.armed = "";
        button.textContent = "Start a blank pack";
      }, 4e3);
      return;
    }
    button.dataset.armed = "";
    button.textContent = "Start a blank pack";
    commitState(replacePack(state, starterPack(state.pack.tier)), { renderForm: true });
    setBanner({ tone: "info", title: `Blank ${state.pack.tier} pack ready.`, detail: "Previous progress and receipts were archived locally. Fill in the client details, then plan." });
  });
  $("import").addEventListener("click", () => $("import-file").click());
  $("import-file").addEventListener("change", async () => {
    if (!available()) return;
    const startedRevision = revision, generation = dataGeneration;
    const input = $("import-file");
    const file = input.files?.[0];
    input.value = "";
    if (!file) return;
    let parsed;
    try {
      parsed = JSON.parse(await file.text());
    } catch (error) {
      if (!available() || revision !== startedRevision || dataGeneration !== generation) return;
      setBanner({ tone: "bad", title: "That file is not valid JSON.", detail: error.message });
      return;
    }
    if (!available() || revision !== startedRevision || dataGeneration !== generation) return;
    importPack(parsed);
  });
  function importPack(parsed) {
    const check = checkPack(parsed);
    const shapeErrors = check.errors.filter((item) => item.code === "shape" || item.code === "type" || item.code === "tier" || item.code === "enum");
    if (!check.pack || shapeErrors.length) {
      renderPackIssues(check.errors, check.warnings);
      setBanner({ tone: "bad", title: "Import refused.", detail: "The file does not match the Page Push Facebook pack format. Nothing was changed." });
      return;
    }
    const merged = mergeDefaults(starterPack(check.pack.tier), parsed);
    commitState(replacePack(state, merged), { renderForm: true });
    setBanner({ tone: "info", title: "Pack imported; previous records archived locally.", detail: check.errors.length ? "It still has errors; they are listed above the Plan button." : "Open the Facebook view and plan it." });
  }
  $("export").addEventListener("click", () => {
    const pack = cleanPack(state.pack);
    const blob = new Blob([`${JSON.stringify(pack, null, 2)}
`], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    const slug = (pack.page.name || "pack").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "pack";
    link.href = url;
    link.download = `pagepush-${slug}-${pack.tier}.json`;
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  });
  $("version-save").addEventListener("click", () => {
    const next = saveVersion(state);
    if (next === state) {
      setBanner({ tone: "info", title: "This version is already saved.", detail: "Edit the pack before saving another version." });
      return;
    }
    commitState(next);
    setBanner({ tone: "good", title: "Pack version saved locally.", detail: "It stays in this browser until cleared or replaced by the 20-version limit." });
  });
  planButton.addEventListener("click", () => {
    void planView();
  });
  draftButton.addEventListener("click", () => {
    void draft();
  });
  commitButton.addEventListener("click", () => {
    void approveAndCommit();
  });
  $("receipt-download").addEventListener("click", () => {
    if (!available() || !(state.receipts ?? []).length) return;
    const receipt = buildSprintReceipt({ pack: state.pack, entries: state.receipts, extensionVersion: manifest_default.version });
    downloadJson(receiptFileName(receipt), receipt);
    setBanner({ tone: "good", title: "Sprint receipt downloaded.", detail: `${receipt.totals.approvals} approval(s), SHA-256 ${receipt.sha256.slice(0, 12)}…` });
  });
  for (const [id, key] of [["check-reviewed", "reviewedPage"], ["check-profile", "profilePicture"], ["check-cover", "coverPhoto"]]) {
    $(id).addEventListener("change", (event) => {
      commitState({ ...state, checklist: { ...state.checklist, [key]: event.target.checked } });
    });
  }
  $("clear").addEventListener("click", async () => {
    const button = $("clear");
    if (button.dataset.armed !== "true") {
      button.dataset.armed = "true";
      button.textContent = "Click again to erase all Page Push data";
      setTimeout(() => {
        button.dataset.armed = "";
        button.textContent = "Clear All Local Data";
      }, 5e3);
      return;
    }
    if (clearing) return;
    button.dataset.armed = "";
    button.textContent = "Clearing...";
    button.disabled = true;
    clearing = true;
    dataGeneration += 1;
    revision += 1;
    copyPanel?.invalidate();
    try {
      await store.clear();
      state = initialState();
      $("ollama-model").value = "";
      clearing = false;
      starting = false;
      render({ renderForm: true });
      setBanner({ tone: "warn", title: "Local data cleared in this panel.", detail: "Another panel or an already-started write can restore data. Close other panels, recheck and clear again if needed. Downloaded files and Facebook data are not erased. A Facebook action already dispatched may still finish; check Facebook directly." });
    } catch {
      clearing = false;
      starting = false;
      render({ renderForm: true });
      setBanner({ tone: "bad", title: "Could not clear local data.", detail: "Try Clear All again. Some data may remain." });
    } finally {
      button.disabled = false;
      button.textContent = "Clear All Local Data";
    }
  });
  chrome.tabs.onActivated.addListener(() => {
    void refreshActiveTab().then(() => render());
  });
  chrome.tabs.onRemoved.addListener((tabId) => {
    if (state.session?.tabId !== tabId) return;
    commitState(invalidate(state, "The Facebook tab was closed."));
    setBanner(bannerFor("disconnected"));
  });
  chrome.tabs.onUpdated.addListener((tabId, change, tab) => {
    if (state.session?.tabId !== tabId) return;
    if (change.url && change.url !== state.session.url) {
      commitState(invalidate(state, "The page navigated since this plan."));
      setBanner({ tone: "info", title: "Facebook moved to a new view.", detail: "Planning it again; the earlier approval no longer applies." });
    }
    if (change.status === "complete" && tab.url && tab.url !== state.session?.url && tab.active) void planView(true);
  });
  chrome.runtime.onMessage.addListener((message, sender) => {
    if (!available() || !isContentEvent(message)) return void 0;
    if (sender.tab?.id == null || sender.tab.id !== state.session?.tabId) return void 0;
    onContentEvent(message);
    return void 0;
  });
  function onContentEvent(event) {
    const session = state.session;
    if (!session) return;
    if (event.type === "pagepush:drift") {
      commitState(recordDrift(state, event.planHash, event.fields));
      setBanner(bannerFor("drift", `Changed after drafting: ${event.fields.map((id) => fieldById(id).labels[0]).join(", ")}. Plan again to approve the page as it is now.`));
      return;
    }
    if (event.reason === "navigated") {
      commitState(invalidate(state, "The page navigated since this plan."));
      void planView(true);
      return;
    }
    if (!session.drafted && !session.committedAt) {
      void planView(true);
      return;
    }
    setBanner({ tone: "info", title: "A Facebook dialog opened or closed.", detail: "If it has fields from the pack, plan again to include them. Your current draft still stands." });
  }
  copyPanel = wireCopyPanel({
    doc: document,
    fetch: window.fetch.bind(window),
    storage: { get: (key) => chrome.storage.local.get(key), set: (items) => store.write(items), clear: () => store.clear() },
    pack: () => state.pack,
    revision: () => revision,
    available,
    applyCopy(copy2) {
      const pack = structuredClone(state.pack);
      if (copy2.bio != null) setPath(pack, "page.bio", copy2.bio);
      if (copy2.launchPost != null) setPath(pack, "launchPost.text", copy2.launchPost);
      commitState(editPack(state, pack), { renderForm: true });
    },
    setBanner
  });
  async function start() {
    buildStaticControls();
    const generation = dataGeneration;
    const saved = await load(chrome.storage.local);
    if (generation !== dataGeneration) return;
    if (saved) {
      state = { pack: saved.pack, checklist: saved.checklist, progress: saved.progress ?? [], session: saved.session, receipts: saved.receipts ?? [], versions: readVersions(saved.versions), archives: saved.archives ?? [] };
      if (!saved.recordsScoped) {
        const previous = state;
        state = archiveRecords(state, true);
        if (state !== previous) store.schedule(state);
      }
    }
    starting = false;
    await refreshActiveTab();
    if (generation !== dataGeneration) return;
    render({ renderForm: true });
    const session = state.session;
    if (!session || session.committedAt || session.stale) return;
    const startedRevision = revision;
    const current = () => available() && generation === dataGeneration && revision === startedRevision && state.session === session;
    const status = await send({ type: "pagepush:status" }, session.tabId, current);
    if (!current()) return;
    const holds = !("error" in status) && status.reply.ok && status.reply.plan?.planHash === session.plan.planHash;
    if (!holds) {
      commitState(invalidate(state, "The tab no longer holds this plan (it reloaded or navigated). Plan again."));
      return;
    }
    if (!("error" in status) && status.reply.ok && status.reply.drift?.length) {
      commitState(recordDrift(state, session.plan.planHash, status.reply.drift));
    }
    setBanner({ tone: "info", title: "Resumed the last plan.", detail: "The Facebook tab still holds it." });
  }
  void start();
})();
